"use strict";
(() => {
    var e, t, i, s = Object.create,
        r = Object.defineProperty,
        n = Object.getOwnPropertyDescriptor,
        a = Object.getOwnPropertyNames,
        o = Object.getPrototypeOf,
        c = Object.prototype.hasOwnProperty,
        h = (e, t) => () => (t || e((t = {
            exports: {}
        }).exports, t), t.exports),
        l = (e, t) => {
            for (var i in t) r(e, i, {
                get: t[i],
                enumerable: !0
            })
        },
        p = (e, t, i) => (i = null != e ? s(o(e)) : {}, ((e, t, i, s) => {
            if (t && "object" == typeof t || "function" == typeof t)
                for (let o of a(t)) !c.call(e, o) && o !== i && r(e, o, {
                    get: () => t[o],
                    enumerable: !(s = n(t, o)) || s.enumerable
                });
            return e
        })(!t && e && e.__esModule ? i : r(i, "default", {
            value: e,
            enumerable: !0
        }), e)),
        u = (e, t, i) => (((e, t, i) => {
            t in e ? r(e, t, {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: i
            }) : e[t] = i
        })(e, "symbol" != typeof t ? t + "" : t, i), i),
        d = h(((e, t) => {
            function i(e) {
                if ("string" != typeof e) throw new TypeError("Path must be a string. Received " + JSON.stringify(e))
            }

            function s(e, t) {
                for (var i, s = "", r = 0, n = -1, a = 0, o = 0; o <= e.length; ++o) {
                    if (o < e.length) i = e.charCodeAt(o);
                    else {
                        if (47 === i) break;
                        i = 47
                    }
                    if (47 === i) {
                        if (n !== o - 1 && 1 !== a)
                            if (n !== o - 1 && 2 === a) {
                                if (s.length < 2 || 2 !== r || 46 !== s.charCodeAt(s.length - 1) || 46 !== s.charCodeAt(s.length - 2))
                                    if (s.length > 2) {
                                        var c = s.lastIndexOf("/");
                                        if (c !== s.length - 1) {
                                            -1 === c ? (s = "", r = 0) : r = (s = s.slice(0, c)).length - 1 - s.lastIndexOf("/"), n = o, a = 0;
                                            continue
                                        }
                                    } else if (2 === s.length || 1 === s.length) {
                                    s = "", r = 0, n = o, a = 0;
                                    continue
                                }
                                t && (s.length > 0 ? s += "/.." : s = "..", r = 2)
                            } else s.length > 0 ? s += "/" + e.slice(n + 1, o) : s = e.slice(n + 1, o), r = o - n - 1;
                        n = o, a = 0
                    } else 46 === i && -1 !== a ? ++a : a = -1
                }
                return s
            }
            var r = {
                resolve: function() {
                    for (var e, t = "", r = !1, n = arguments.length - 1; n >= -1 && !r; n--) {
                        var a;
                        n >= 0 ? a = arguments[n] : (void 0 === e && (e = process.cwd()), a = e), i(a), 0 !== a.length && (t = a + "/" + t, r = 47 === a.charCodeAt(0))
                    }
                    return t = s(t, !r), r ? t.length > 0 ? "/" + t : "/" : t.length > 0 ? t : "."
                },
                normalize: function(e) {
                    if (i(e), 0 === e.length) return ".";
                    var t = 47 === e.charCodeAt(0),
                        r = 47 === e.charCodeAt(e.length - 1);
                    return 0 === (e = s(e, !t)).length && !t && (e = "."), e.length > 0 && r && (e += "/"), t ? "/" + e : e
                },
                isAbsolute: function(e) {
                    return i(e), e.length > 0 && 47 === e.charCodeAt(0)
                },
                join: function() {
                    if (0 === arguments.length) return ".";
                    for (var e, t = 0; t < arguments.length; ++t) {
                        var s = arguments[t];
                        i(s), s.length > 0 && (void 0 === e ? e = s : e += "/" + s)
                    }
                    return void 0 === e ? "." : r.normalize(e)
                },
                relative: function(e, t) {
                    if (i(e), i(t), e === t || (e = r.resolve(e)) === (t = r.resolve(t))) return "";
                    for (var s = 1; s < e.length && 47 === e.charCodeAt(s); ++s);
                    for (var n = e.length, a = n - s, o = 1; o < t.length && 47 === t.charCodeAt(o); ++o);
                    for (var c = t.length - o, h = a < c ? a : c, l = -1, p = 0; p <= h; ++p) {
                        if (p === h) {
                            if (c > h) {
                                if (47 === t.charCodeAt(o + p)) return t.slice(o + p + 1);
                                if (0 === p) return t.slice(o + p)
                            } else a > h && (47 === e.charCodeAt(s + p) ? l = p : 0 === p && (l = 0));
                            break
                        }
                        var u = e.charCodeAt(s + p);
                        if (u !== t.charCodeAt(o + p)) break;
                        47 === u && (l = p)
                    }
                    var d = "";
                    for (p = s + l + 1; p <= n; ++p)(p === n || 47 === e.charCodeAt(p)) && (0 === d.length ? d += ".." : d += "/..");
                    return d.length > 0 ? d + t.slice(o + l) : (o += l, 47 === t.charCodeAt(o) && ++o, t.slice(o))
                },
                _makeLong: function(e) {
                    return e
                },
                dirname: function(e) {
                    if (i(e), 0 === e.length) return ".";
                    for (var t = e.charCodeAt(0), s = 47 === t, r = -1, n = !0, a = e.length - 1; a >= 1; --a)
                        if (47 === (t = e.charCodeAt(a))) {
                            if (!n) {
                                r = a;
                                break
                            }
                        } else n = !1;
                    return -1 === r ? s ? "/" : "." : s && 1 === r ? "//" : e.slice(0, r)
                },
                basename: function(e, t) {
                    if (void 0 !== t && "string" != typeof t) throw new TypeError('"ext" argument must be a string');
                    i(e);
                    var s, r = 0,
                        n = -1,
                        a = !0;
                    if (void 0 !== t && t.length > 0 && t.length <= e.length) {
                        if (t.length === e.length && t === e) return "";
                        var o = t.length - 1,
                            c = -1;
                        for (s = e.length - 1; s >= 0; --s) {
                            var h = e.charCodeAt(s);
                            if (47 === h) {
                                if (!a) {
                                    r = s + 1;
                                    break
                                }
                            } else -1 === c && (a = !1, c = s + 1), o >= 0 && (h === t.charCodeAt(o) ? -1 == --o && (n = s) : (o = -1, n = c))
                        }
                        return r === n ? n = c : -1 === n && (n = e.length), e.slice(r, n)
                    }
                    for (s = e.length - 1; s >= 0; --s)
                        if (47 === e.charCodeAt(s)) {
                            if (!a) {
                                r = s + 1;
                                break
                            }
                        } else -1 === n && (a = !1, n = s + 1);
                    return -1 === n ? "" : e.slice(r, n)
                },
                extname: function(e) {
                    i(e);
                    for (var t = -1, s = 0, r = -1, n = !0, a = 0, o = e.length - 1; o >= 0; --o) {
                        var c = e.charCodeAt(o);
                        if (47 !== c) - 1 === r && (n = !1, r = o + 1), 46 === c ? -1 === t ? t = o : 1 !== a && (a = 1) : -1 !== t && (a = -1);
                        else if (!n) {
                            s = o + 1;
                            break
                        }
                    }
                    return -1 === t || -1 === r || 0 === a || 1 === a && t === r - 1 && t === s + 1 ? "" : e.slice(t, r)
                },
                format: function(e) {
                    if (null === e || "object" != typeof e) throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + typeof e);
                    return function(e, t) {
                        var i = t.dir || t.root,
                            s = t.base || (t.name || "") + (t.ext || "");
                        return i ? i === t.root ? i + s : i + e + s : s
                    }("/", e)
                },
                parse: function(e) {
                    i(e);
                    var t = {
                        root: "",
                        dir: "",
                        base: "",
                        ext: "",
                        name: ""
                    };
                    if (0 === e.length) return t;
                    var s, r = e.charCodeAt(0),
                        n = 47 === r;
                    n ? (t.root = "/", s = 1) : s = 0;
                    for (var a = -1, o = 0, c = -1, h = !0, l = e.length - 1, p = 0; l >= s; --l)
                        if (47 !== (r = e.charCodeAt(l))) - 1 === c && (h = !1, c = l + 1), 46 === r ? -1 === a ? a = l : 1 !== p && (p = 1) : -1 !== a && (p = -1);
                        else if (!h) {
                        o = l + 1;
                        break
                    }
                    return -1 === a || -1 === c || 0 === p || 1 === p && a === c - 1 && a === o + 1 ? -1 !== c && (t.base = t.name = 0 === o && n ? e.slice(1, c) : e.slice(o, c)) : (0 === o && n ? (t.name = e.slice(1, a), t.base = e.slice(1, c)) : (t.name = e.slice(o, a), t.base = e.slice(o, c)), t.ext = e.slice(a, c)), o > 0 ? t.dir = e.slice(0, o - 1) : n && (t.dir = "/"), t
                },
                sep: "/",
                delimiter: ":",
                win32: null,
                posix: null
            };
            r.posix = r, t.exports = r
        })),
        f = h((e => {
            e.parse = function(e, t) {
                if ("string" != typeof e) throw new TypeError("argument str must be a string");
                for (var i = {}, r = (t || {}).decode || s, a = 0; a < e.length;) {
                    var o = e.indexOf("=", a);
                    if (-1 === o) break;
                    var c = e.indexOf(";", a);
                    if (-1 === c) c = e.length;
                    else if (c < o) {
                        a = e.lastIndexOf(";", o - 1) + 1;
                        continue
                    }
                    var h = e.slice(a, o).trim();
                    if (void 0 === i[h]) {
                        var l = e.slice(o + 1, c).trim();
                        34 === l.charCodeAt(0) && (l = l.slice(1, -1)), i[h] = n(l, r)
                    }
                    a = c + 1
                }
                return i
            }, e.serialize = function(e, s, n) {
                var a = n || {},
                    o = a.encode || r;
                if ("function" != typeof o) throw new TypeError("option encode is invalid");
                if (!i.test(e)) throw new TypeError("argument name is invalid");
                var c = o(s);
                if (c && !i.test(c)) throw new TypeError("argument val is invalid");
                var h = e + "=" + c;
                if (null != a.maxAge) {
                    var l = a.maxAge - 0;
                    if (isNaN(l) || !isFinite(l)) throw new TypeError("option maxAge is invalid");
                    h += "; Max-Age=" + Math.floor(l)
                }
                if (a.domain) {
                    if (!i.test(a.domain)) throw new TypeError("option domain is invalid");
                    h += "; Domain=" + a.domain
                }
                if (a.path) {
                    if (!i.test(a.path)) throw new TypeError("option path is invalid");
                    h += "; Path=" + a.path
                }
                if (a.expires) {
                    var p = a.expires;
                    if (! function(e) {
                            return "[object Date]" === t.call(e) || e instanceof Date
                        }(p) || isNaN(p.valueOf())) throw new TypeError("option expires is invalid");
                    h += "; Expires=" + p.toUTCString()
                }
                if (a.httpOnly && (h += "; HttpOnly"), a.secure && (h += "; Secure"), a.priority) {
                    switch ("string" == typeof a.priority ? a.priority.toLowerCase() : a.priority) {
                        case "low":
                            h += "; Priority=Low";
                            break;
                        case "medium":
                            h += "; Priority=Medium";
                            break;
                        case "high":
                            h += "; Priority=High";
                            break;
                        default:
                            throw new TypeError("option priority is invalid")
                    }
                }
                if (a.sameSite) {
                    switch ("string" == typeof a.sameSite ? a.sameSite.toLowerCase() : a.sameSite) {
                        case !0:
                            h += "; SameSite=Strict";
                            break;
                        case "lax":
                            h += "; SameSite=Lax";
                            break;
                        case "strict":
                            h += "; SameSite=Strict";
                            break;
                        case "none":
                            h += "; SameSite=None";
                            break;
                        default:
                            throw new TypeError("option sameSite is invalid")
                    }
                }
                return h
            };
            var t = Object.prototype.toString,
                i = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;

            function s(e) {
                return -1 !== e.indexOf("%") ? decodeURIComponent(e) : e
            }

            function r(e) {
                return encodeURIComponent(e)
            }

            function n(e, t) {
                try {
                    return t(e)
                } catch {
                    return e
                }
            }
        })),
        m = h(((e, t) => {
            var i = {
                decodeValues: !0,
                map: !1,
                silent: !1
            };

            function s(e) {
                return "string" == typeof e && !!e.trim()
            }

            function r(e, t) {
                var r = e.split(";").filter(s),
                    n = function(e) {
                        var t = "",
                            i = "",
                            s = e.split("=");
                        return s.length > 1 ? (t = s.shift(), i = s.join("=")) : i = e, {
                            name: t,
                            value: i
                        }
                    }(r.shift()),
                    a = n.name,
                    o = n.value;
                t = t ? Object.assign({}, i, t) : i;
                try {
                    o = t.decodeValues ? decodeURIComponent(o) : o
                } catch (e) {
                    console.error("set-cookie-parser encountered an error while decoding a cookie with value '" + o + "'. Set options.decodeValues to false to disable this feature.", e)
                }
                var c = {
                    name: a,
                    value: o
                };
                return r.forEach((function(e) {
                    var t = e.split("="),
                        i = t.shift().trimLeft().toLowerCase(),
                        s = t.join("=");
                    "expires" === i ? c.expires = new Date(s) : "max-age" === i ? c.maxAge = parseInt(s, 10) : "secure" === i ? c.secure = !0 : "httponly" === i ? c.httpOnly = !0 : "samesite" === i ? c.sameSite = s : c[i] = s
                })), c
            }

            function n(e, t) {
                if (t = t ? Object.assign({}, i, t) : i, !e) return t.map ? {} : [];
                if (e.headers)
                    if ("function" == typeof e.headers.getSetCookie) e = e.headers.getSetCookie();
                    else if (e.headers["set-cookie"]) e = e.headers["set-cookie"];
                else {
                    var n = e.headers[Object.keys(e.headers).find((function(e) {
                        return "set-cookie" === e.toLowerCase()
                    }))];
                    !n && e.headers.cookie && !t.silent && console.warn("Warning: set-cookie-parser appears to have been called on a request object. It is designed to parse Set-Cookie headers from responses, not Cookie headers from requests. Set the option {silent: true} to suppress this warning."), e = n
                }
                if (Array.isArray(e) || (e = [e]), (t = t ? Object.assign({}, i, t) : i).map) {
                    return e.filter(s).reduce((function(e, i) {
                        var s = r(i, t);
                        return e[s.name] = s, e
                    }), {})
                }
                return e.filter(s).map((function(e) {
                    return r(e, t)
                }))
            }
            t.exports = n, t.exports.parse = n, t.exports.parseString = r, t.exports.splitCookiesString = function(e) {
                if (Array.isArray(e)) return e;
                if ("string" != typeof e) return [];
                var t, i, s, r, n, a = [],
                    o = 0;

                function c() {
                    for (; o < e.length && /\s/.test(e.charAt(o));) o += 1;
                    return o < e.length
                }
                for (; o < e.length;) {
                    for (t = o, n = !1; c();)
                        if ("," === (i = e.charAt(o))) {
                            for (s = o, o += 1, c(), r = o; o < e.length && "=" !== (i = e.charAt(o)) && ";" !== i && "," !== i;) o += 1;
                            o < e.length && "=" === e.charAt(o) ? (n = !0, o = r, a.push(e.substring(t, s)), t = o) : o = s + 1
                        } else o += 1;
                    (!n || o >= e.length) && a.push(e.substring(t, e.length))
                }
                return a
            }
        })),
        g = p(d()),
        x = {
            "application/ecmascript": {
                source: "apache",
                compressible: !0,
                extensions: ["ecma"]
            },
            "application/gzip": {
                source: "iana",
                compressible: !1,
                extensions: ["gz"]
            },
            "application/http": {
                source: "iana"
            },
            "application/javascript": {
                source: "apache",
                charset: "UTF-8",
                compressible: !0,
                extensions: ["js"]
            },
            "application/json": {
                source: "iana",
                charset: "UTF-8",
                compressible: !0,
                extensions: ["json", "map"]
            },
            "application/manifest+json": {
                source: "iana",
                charset: "UTF-8",
                compressible: !0,
                extensions: ["webmanifest"]
            },
            "application/marc": {
                source: "iana",
                extensions: ["mrc"]
            },
            "application/mp4": {
                source: "iana",
                extensions: ["mp4", "mpg4", "mp4s", "m4p"]
            },
            "application/ogg": {
                source: "iana",
                compressible: !1,
                extensions: ["ogx"]
            },
            "application/sql": {
                source: "iana",
                extensions: ["sql"]
            },
            "application/wasm": {
                source: "iana",
                compressible: !0,
                extensions: ["wasm"]
            },
            "application/x-bittorrent": {
                source: "apache",
                extensions: ["torrent"]
            },
            "application/x-gzip": {
                source: "apache"
            },
            "application/x-javascript": {
                compressible: !0
            },
            "application/x-web-app-manifest+json": {
                compressible: !0,
                extensions: ["webapp"]
            },
            "application/x-www-form-urlencoded": {
                source: "iana",
                compressible: !0
            },
            "application/xhtml+xml": {
                source: "iana",
                compressible: !0,
                extensions: ["xhtml", "xht"]
            },
            "application/xhtml-voice+xml": {
                source: "apache",
                compressible: !0
            },
            "application/xml": {
                source: "iana",
                compressible: !0,
                extensions: ["xml", "xsl", "xsd", "rng"]
            },
            "application/zip": {
                source: "iana",
                compressible: !1,
                extensions: ["zip"]
            },
            "application/zlib": {
                source: "iana"
            },
            "audio/midi": {
                source: "apache",
                extensions: ["mid", "midi", "kar", "rmi"]
            },
            "audio/mp3": {
                compressible: !1,
                extensions: ["mp3"]
            },
            "audio/mp4": {
                source: "iana",
                compressible: !1,
                extensions: ["m4a", "mp4a"]
            },
            "audio/mp4a-latm": {
                source: "iana"
            },
            "audio/mpa": {
                source: "iana"
            },
            "audio/mpa-robust": {
                source: "iana"
            },
            "audio/mpeg": {
                source: "iana",
                compressible: !1,
                extensions: ["mpga", "mp2", "mp2a", "mp3", "m2a", "m3a"]
            },
            "audio/ogg": {
                source: "iana",
                compressible: !1,
                extensions: ["oga", "ogg", "spx", "opus"]
            },
            "audio/red": {
                source: "iana"
            },
            "audio/rtx": {
                source: "iana"
            },
            "audio/scip": {
                source: "iana"
            },
            "audio/silk": {
                source: "apache",
                extensions: ["sil"]
            },
            "audio/smv": {
                source: "iana"
            },
            "audio/wav": {
                compressible: !1,
                extensions: ["wav"]
            },
            "audio/wave": {
                compressible: !1,
                extensions: ["wav"]
            },
            "audio/webm": {
                source: "apache",
                compressible: !1,
                extensions: ["weba"]
            },
            "audio/x-aac": {
                source: "apache",
                compressible: !1,
                extensions: ["aac"]
            },
            "audio/x-aiff": {
                source: "apache",
                extensions: ["aif", "aiff", "aifc"]
            },
            "audio/x-caf": {
                source: "apache",
                compressible: !1,
                extensions: ["caf"]
            },
            "audio/x-flac": {
                source: "apache",
                extensions: ["flac"]
            },
            "audio/x-m4a": {
                source: "nginx",
                extensions: ["m4a"]
            },
            "audio/x-matroska": {
                source: "apache",
                extensions: ["mka"]
            },
            "audio/x-mpegurl": {
                source: "apache",
                extensions: ["m3u"]
            },
            "audio/x-ms-wax": {
                source: "apache",
                extensions: ["wax"]
            },
            "audio/x-ms-wma": {
                source: "apache",
                extensions: ["wma"]
            },
            "audio/x-pn-realaudio": {
                source: "apache",
                extensions: ["ram", "ra"]
            },
            "audio/x-pn-realaudio-plugin": {
                source: "apache",
                extensions: ["rmp"]
            },
            "audio/x-realaudio": {
                source: "nginx",
                extensions: ["ra"]
            },
            "audio/x-tta": {
                source: "apache"
            },
            "audio/x-wav": {
                source: "apache",
                extensions: ["wav"]
            },
            "audio/xm": {
                source: "apache",
                extensions: ["xm"]
            },
            "font/collection": {
                source: "iana",
                extensions: ["ttc"]
            },
            "font/otf": {
                source: "iana",
                compressible: !0,
                extensions: ["otf"]
            },
            "font/sfnt": {
                source: "iana"
            },
            "font/ttf": {
                source: "iana",
                compressible: !0,
                extensions: ["ttf"]
            },
            "font/woff": {
                source: "iana",
                extensions: ["woff"]
            },
            "font/woff2": {
                source: "iana",
                extensions: ["woff2"]
            },
            "image/gif": {
                source: "iana",
                compressible: !1,
                extensions: ["gif"]
            },
            "image/heic": {
                source: "iana",
                extensions: ["heic"]
            },
            "image/heic-sequence": {
                source: "iana",
                extensions: ["heics"]
            },
            "image/heif": {
                source: "iana",
                extensions: ["heif"]
            },
            "image/jpeg": {
                source: "iana",
                compressible: !1,
                extensions: ["jpeg", "jpg", "jpe"]
            },
            "image/png": {
                source: "iana",
                compressible: !1,
                extensions: ["png"]
            },
            "image/svg+xml": {
                source: "iana",
                compressible: !0,
                extensions: ["svg", "svgz"]
            },
            "image/webp": {
                source: "iana",
                extensions: ["webp"]
            },
            "text/coffeescript": {
                extensions: ["coffee", "litcoffee"]
            },
            "text/css": {
                source: "iana",
                charset: "UTF-8",
                compressible: !0,
                extensions: ["css"]
            },
            "text/ecmascript": {
                source: "apache"
            },
            "text/html": {
                source: "iana",
                compressible: !0,
                extensions: ["html", "htm", "shtml"]
            },
            "text/jade": {
                extensions: ["jade"]
            },
            "text/javascript": {
                source: "iana",
                charset: "UTF-8",
                compressible: !0,
                extensions: ["js", "mjs"]
            },
            "text/markdown": {
                source: "iana",
                compressible: !0,
                extensions: ["md", "markdown"]
            }
        },
        y = /^\s*([^;\s]*)(?:;|\s|$)/,
        v = /^text\//i,
        w = {};

    function b(e) {
        if (!e || "string" != typeof e) return !1;
        var t = y.exec(e),
            i = t && x[t[1].toLowerCase()];
        return i && i.charset ? i.charset : !(!t || !v.test(t[1])) && "UTF-8"
    }
    w.charset = b, w.charsets = {
        lookup: b
    }, w.contentType = function(e) {
        if (!e || "string" != typeof e) return !1;
        var t = -1 === e.indexOf("/") ? w.lookup(e) : e;
        if (!t) return !1;
        if (-1 === t.indexOf("charset")) {
            var i = w.charset(t);
            i && (t += "; charset=" + i.toLowerCase())
        }
        return t
    }, w.extension = function(e) {
        if (!e || "string" != typeof e) return !1;
        var t = y.exec(e),
            i = t && w.extensions[t[1].toLowerCase()];
        return !(!i || !i.length) && i[0]
    }, w.extensions = Object.create(null), w.lookup = function(e) {
        if (!e || "string" != typeof e) return !1;
        var t = (0, g.extname)("x." + e).toLowerCase().substr(1);
        return t && w.types[t] || !1
    }, w.types = Object.create(null), e = w.extensions, t = w.types, i = ["nginx", "apache", void 0, "iana"], Object.keys(x).forEach((function(s) {
        var r = x[s],
            n = r.extensions;
        if (n && n.length) {
            e[s] = n;
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                if (t[o]) {
                    var c = i.indexOf(x[t[o]].source),
                        h = i.indexOf(r.source);
                    if ("application/octet-stream" !== t[o] && (c > h || c === h && "application/" === t[o].substr(0, 12))) continue
                }
                t[o] = s
            }
        }
    }));
    var _ = w,
        k = p(d(), 1),
        C = {};
    l(C, {
        deleteDB: () => B,
        openDB: () => M,
        unwrap: () => j,
        wrap: () => D
    });
    var E, S, I = (e, t) => t.some((t => e instanceof t));
    var A = new WeakMap,
        P = new WeakMap,
        N = new WeakMap,
        L = new WeakMap,
        T = new WeakMap;
    var R = {
        get(e, t, i) {
            if (e instanceof IDBTransaction) {
                if ("done" === t) return P.get(e);
                if ("objectStoreNames" === t) return e.objectStoreNames || N.get(e);
                if ("store" === t) return i.objectStoreNames[1] ? void 0 : i.objectStore(i.objectStoreNames[0])
            }
            return D(e[t])
        },
        set: (e, t, i) => (e[t] = i, !0),
        has: (e, t) => e instanceof IDBTransaction && ("done" === t || "store" === t) || t in e
    };

    function V(e) {
        return e !== IDBDatabase.prototype.transaction || "objectStoreNames" in IDBTransaction.prototype ? (S || (S = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])).includes(e) ? function(...t) {
            return e.apply(j(this), t), D(A.get(this))
        } : function(...t) {
            return D(e.apply(j(this), t))
        } : function(t, ...i) {
            let s = e.call(j(this), t, ...i);
            return N.set(s, t.sort ? t.sort() : [t]), D(s)
        }
    }

    function O(e) {
        return "function" == typeof e ? V(e) : (e instanceof IDBTransaction && function(e) {
            if (P.has(e)) return;
            let t = new Promise(((t, i) => {
                let s = () => {
                        e.removeEventListener("complete", r), e.removeEventListener("error", n), e.removeEventListener("abort", n)
                    },
                    r = () => {
                        t(), s()
                    },
                    n = () => {
                        i(e.error || new DOMException("AbortError", "AbortError")), s()
                    };
                e.addEventListener("complete", r), e.addEventListener("error", n), e.addEventListener("abort", n)
            }));
            P.set(e, t)
        }(e), I(e, E || (E = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])) ? new Proxy(e, R) : e)
    }

    function D(e) {
        if (e instanceof IDBRequest) return function(e) {
            let t = new Promise(((t, i) => {
                let s = () => {
                        e.removeEventListener("success", r), e.removeEventListener("error", n)
                    },
                    r = () => {
                        t(D(e.result)), s()
                    },
                    n = () => {
                        i(e.error), s()
                    };
                e.addEventListener("success", r), e.addEventListener("error", n)
            }));
            return t.then((t => {
                t instanceof IDBCursor && A.set(t, e)
            })).catch((() => {})), T.set(t, e), t
        }(e);
        if (L.has(e)) return L.get(e);
        let t = O(e);
        return t !== e && (L.set(e, t), T.set(t, e)), t
    }
    var j = e => T.get(e);

    function M(e, t, {
        blocked: i,
        upgrade: s,
        blocking: r,
        terminated: n
    } = {}) {
        let a = indexedDB.open(e, t),
            o = D(a);
        return s && a.addEventListener("upgradeneeded", (e => {
            s(D(a.result), e.oldVersion, e.newVersion, D(a.transaction), e)
        })), i && a.addEventListener("blocked", (e => i(e.oldVersion, e.newVersion, e))), o.then((e => {
            n && e.addEventListener("close", (() => n())), r && e.addEventListener("versionchange", (e => r(e.oldVersion, e.newVersion, e)))
        })).catch((() => {})), o
    }

    function B(e, {
        blocked: t
    } = {}) {
        let i = indexedDB.deleteDatabase(e);
        return t && i.addEventListener("blocked", (e => t(e.oldVersion, e))), D(i).then((() => {}))
    }
    var U = ["get", "getKey", "getAll", "getAllKeys", "count"],
        $ = ["put", "add", "delete", "clear"],
        F = new Map;

    function H(e, t) {
        if (!(e instanceof IDBDatabase) || t in e || "string" != typeof t) return;
        if (F.get(t)) return F.get(t);
        let i = t.replace(/FromIndex$/, ""),
            s = t !== i,
            r = $.includes(i);
        if (!(i in (s ? IDBIndex : IDBObjectStore).prototype) || !r && !U.includes(i)) return;
        let n = async function(e, ...t) {
            let n = this.transaction(e, r ? "readwrite" : "readonly"),
                a = n.store;
            return s && (a = a.index(t.shift())), (await Promise.all([a[i](...t), r && n.done]))[0]
        };
        return F.set(t, n), n
    }! function(e) {
        R = e(R)
    }((e => ({ ...e,
        get: (t, i, s) => H(t, i) || e.get(t, i, s),
        has: (t, i) => !!H(t, i) || e.has(t, i)
    })));
    var W = [509, 0, 227, 0, 150, 4, 294, 9, 1368, 2, 2, 1, 6, 3, 41, 2, 5, 0, 166, 1, 574, 3, 9, 9, 370, 1, 81, 2, 71, 10, 50, 3, 123, 2, 54, 14, 32, 10, 3, 1, 11, 3, 46, 10, 8, 0, 46, 9, 7, 2, 37, 13, 2, 9, 6, 1, 45, 0, 13, 2, 49, 13, 9, 3, 2, 11, 83, 11, 7, 0, 3, 0, 158, 11, 6, 9, 7, 3, 56, 1, 2, 6, 3, 1, 3, 2, 10, 0, 11, 1, 3, 6, 4, 4, 193, 17, 10, 9, 5, 0, 82, 19, 13, 9, 214, 6, 3, 8, 28, 1, 83, 16, 16, 9, 82, 12, 9, 9, 84, 14, 5, 9, 243, 14, 166, 9, 71, 5, 2, 1, 3, 3, 2, 0, 2, 1, 13, 9, 120, 6, 3, 6, 4, 0, 29, 9, 41, 6, 2, 3, 9, 0, 10, 10, 47, 15, 406, 7, 2, 7, 17, 9, 57, 21, 2, 13, 123, 5, 4, 0, 2, 1, 2, 6, 2, 0, 9, 9, 49, 4, 2, 1, 2, 4, 9, 9, 330, 3, 10, 1, 2, 0, 49, 6, 4, 4, 14, 9, 5351, 0, 7, 14, 13835, 9, 87, 9, 39, 4, 60, 6, 26, 9, 1014, 0, 2, 54, 8, 3, 82, 0, 12, 1, 19628, 1, 4706, 45, 3, 22, 543, 4, 4, 5, 9, 7, 3, 6, 31, 3, 149, 2, 1418, 49, 513, 54, 5, 49, 9, 0, 15, 0, 23, 4, 2, 14, 1361, 6, 2, 16, 3, 6, 2, 1, 2, 4, 101, 0, 161, 6, 10, 9, 357, 0, 62, 13, 499, 13, 983, 6, 110, 6, 6, 9, 4759, 9, 787719, 239],
        q = [0, 11, 2, 25, 2, 18, 2, 1, 2, 14, 3, 13, 35, 122, 70, 52, 268, 28, 4, 48, 48, 31, 14, 29, 6, 37, 11, 29, 3, 35, 5, 7, 2, 4, 43, 157, 19, 35, 5, 35, 5, 39, 9, 51, 13, 10, 2, 14, 2, 6, 2, 1, 2, 10, 2, 14, 2, 6, 2, 1, 68, 310, 10, 21, 11, 7, 25, 5, 2, 41, 2, 8, 70, 5, 3, 0, 2, 43, 2, 1, 4, 0, 3, 22, 11, 22, 10, 30, 66, 18, 2, 1, 11, 21, 11, 25, 71, 55, 7, 1, 65, 0, 16, 3, 2, 2, 2, 28, 43, 28, 4, 28, 36, 7, 2, 27, 28, 53, 11, 21, 11, 18, 14, 17, 111, 72, 56, 50, 14, 50, 14, 35, 349, 41, 7, 1, 79, 28, 11, 0, 9, 21, 43, 17, 47, 20, 28, 22, 13, 52, 58, 1, 3, 0, 14, 44, 33, 24, 27, 35, 30, 0, 3, 0, 9, 34, 4, 0, 13, 47, 15, 3, 22, 0, 2, 0, 36, 17, 2, 24, 20, 1, 64, 6, 2, 0, 2, 3, 2, 14, 2, 9, 8, 46, 39, 7, 3, 1, 3, 21, 2, 6, 2, 1, 2, 4, 4, 0, 19, 0, 13, 4, 159, 52, 19, 3, 21, 2, 31, 47, 21, 1, 2, 0, 185, 46, 42, 3, 37, 47, 21, 0, 60, 42, 14, 0, 72, 26, 38, 6, 186, 43, 117, 63, 32, 7, 3, 0, 3, 7, 2, 1, 2, 23, 16, 0, 2, 0, 95, 7, 3, 38, 17, 0, 2, 0, 29, 0, 11, 39, 8, 0, 22, 0, 12, 45, 20, 0, 19, 72, 264, 8, 2, 36, 18, 0, 50, 29, 113, 6, 2, 1, 2, 37, 22, 0, 26, 5, 2, 1, 2, 31, 15, 0, 328, 18, 16, 0, 2, 12, 2, 33, 125, 0, 80, 921, 103, 110, 18, 195, 2637, 96, 16, 1071, 18, 5, 4026, 582, 8634, 568, 8, 30, 18, 78, 18, 29, 19, 47, 17, 3, 32, 20, 6, 18, 689, 63, 129, 74, 6, 0, 67, 12, 65, 1, 2, 0, 29, 6135, 9, 1237, 43, 8, 8936, 3, 2, 6, 2, 1, 2, 290, 16, 0, 30, 2, 3, 0, 15, 3, 9, 395, 2309, 106, 6, 12, 4, 8, 8, 9, 5991, 84, 2, 70, 2, 1, 3, 0, 3, 1, 3, 3, 2, 11, 2, 0, 2, 6, 2, 64, 2, 3, 3, 7, 2, 6, 2, 27, 2, 3, 2, 4, 2, 0, 4, 6, 2, 339, 3, 24, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 7, 1845, 30, 7, 5, 262, 61, 147, 44, 11, 6, 17, 0, 322, 29, 19, 43, 485, 27, 757, 6, 2, 3, 2, 1, 2, 14, 2, 196, 60, 67, 8, 0, 1205, 3, 2, 26, 2, 1, 2, 0, 3, 0, 2, 9, 2, 3, 2, 0, 2, 0, 7, 0, 5, 0, 2, 0, 2, 0, 2, 2, 2, 1, 2, 0, 3, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 1, 2, 0, 3, 3, 2, 6, 2, 3, 2, 3, 2, 0, 2, 9, 2, 16, 6, 2, 2, 4, 2, 16, 4421, 42719, 33, 4153, 7, 221, 3, 5761, 15, 7472, 3104, 541, 1507, 4938, 6, 4191],
        G = "ªµºÀ-ÖØ-öø-ˁˆ-ˑˠ-ˤˬˮͰ-ʹͶͷͺ-ͽͿΆΈ-ΊΌΎ-ΡΣ-ϵϷ-ҁҊ-ԯԱ-Ֆՙՠ-ֈא-תׯ-ײؠ-يٮٯٱ-ۓەۥۦۮۯۺ-ۼۿܐܒ-ܯݍ-ޥޱߊ-ߪߴߵߺࠀ-ࠕࠚࠤࠨࡀ-ࡘࡠ-ࡪࡰ-ࢇࢉ-ࢎࢠ-ࣉऄ-हऽॐक़-ॡॱ-ঀঅ-ঌএঐও-নপ-রলশ-হঽৎড়ঢ়য়-ৡৰৱৼਅ-ਊਏਐਓ-ਨਪ-ਰਲਲ਼ਵਸ਼ਸਹਖ਼-ੜਫ਼ੲ-ੴઅ-ઍએ-ઑઓ-નપ-રલળવ-હઽૐૠૡૹଅ-ଌଏଐଓ-ନପ-ରଲଳଵ-ହଽଡ଼ଢ଼ୟ-ୡୱஃஅ-ஊஎ-ஐஒ-கஙசஜஞடணதந-பம-ஹௐఅ-ఌఎ-ఐఒ-నప-హఽౘ-ౚౝౠౡಀಅ-ಌಎ-ಐಒ-ನಪ-ಳವ-ಹಽೝೞೠೡೱೲഄ-ഌഎ-ഐഒ-ഺഽൎൔ-ൖൟ-ൡൺ-ൿඅ-ඖක-නඳ-රලව-ෆก-ะาำเ-ๆກຂຄຆ-ຊຌ-ຣລວ-ະາຳຽເ-ໄໆໜ-ໟༀཀ-ཇཉ-ཬྈ-ྌက-ဪဿၐ-ၕၚ-ၝၡၥၦၮ-ၰၵ-ႁႎႠ-ჅჇჍა-ჺჼ-ቈቊ-ቍቐ-ቖቘቚ-ቝበ-ኈኊ-ኍነ-ኰኲ-ኵኸ-ኾዀዂ-ዅወ-ዖዘ-ጐጒ-ጕጘ-ፚᎀ-ᎏᎠ-Ᏽᏸ-ᏽᐁ-ᙬᙯ-ᙿᚁ-ᚚᚠ-ᛪᛮ-ᛸᜀ-ᜑᜟ-ᜱᝀ-ᝑᝠ-ᝬᝮ-ᝰក-ឳៗៜᠠ-ᡸᢀ-ᢨᢪᢰ-ᣵᤀ-ᤞᥐ-ᥭᥰ-ᥴᦀ-ᦫᦰ-ᧉᨀ-ᨖᨠ-ᩔᪧᬅ-ᬳᭅ-ᭌᮃ-ᮠᮮᮯᮺ-ᯥᰀ-ᰣᱍ-ᱏᱚ-ᱽᲀ-ᲈᲐ-ᲺᲽ-Ჿᳩ-ᳬᳮ-ᳳᳵᳶᳺᴀ-ᶿḀ-ἕἘ-Ἕἠ-ὅὈ-Ὅὐ-ὗὙὛὝὟ-ώᾀ-ᾴᾶ-ᾼιῂ-ῄῆ-ῌῐ-ΐῖ-Ίῠ-Ῥῲ-ῴῶ-ῼⁱⁿₐ-ₜℂℇℊ-ℓℕ℘-ℝℤΩℨK-ℹℼ-ℿⅅ-ⅉⅎⅠ-ↈⰀ-ⳤⳫ-ⳮⳲⳳⴀ-ⴥⴧⴭⴰ-ⵧⵯⶀ-ⶖⶠ-ⶦⶨ-ⶮⶰ-ⶶⶸ-ⶾⷀ-ⷆⷈ-ⷎⷐ-ⷖⷘ-ⷞ々-〇〡-〩〱-〵〸-〼ぁ-ゖ゛-ゟァ-ヺー-ヿㄅ-ㄯㄱ-ㆎㆠ-ㆿㇰ-ㇿ㐀-䶿一-ꒌꓐ-ꓽꔀ-ꘌꘐ-ꘟꘪꘫꙀ-ꙮꙿ-ꚝꚠ-ꛯꜗ-ꜟꜢ-ꞈꞋ-ꟊꟐꟑꟓꟕ-ꟙꟲ-ꠁꠃ-ꠅꠇ-ꠊꠌ-ꠢꡀ-ꡳꢂ-ꢳꣲ-ꣷꣻꣽꣾꤊ-ꤥꤰ-ꥆꥠ-ꥼꦄ-ꦲꧏꧠ-ꧤꧦ-ꧯꧺ-ꧾꨀ-ꨨꩀ-ꩂꩄ-ꩋꩠ-ꩶꩺꩾ-ꪯꪱꪵꪶꪹ-ꪽꫀꫂꫛ-ꫝꫠ-ꫪꫲ-ꫴꬁ-ꬆꬉ-ꬎꬑ-ꬖꬠ-ꬦꬨ-ꬮꬰ-ꭚꭜ-ꭩꭰ-ꯢ가-힣ힰ-ퟆퟋ-ퟻ豈-舘並-龎ﬀ-ﬆﬓ-ﬗיִײַ-ﬨשׁ-זּטּ-לּמּנּסּףּפּצּ-ﮱﯓ-ﴽﵐ-ﶏﶒ-ﷇﷰ-ﷻﹰ-ﹴﹶ-ﻼＡ-Ｚａ-ｚｦ-ﾾￂ-ￇￊ-ￏￒ-ￗￚ-ￜ",
        z = {
            3: "abstract boolean byte char class double enum export extends final float goto implements import int interface long native package private protected public short static super synchronized throws transient volatile",
            5: "class enum extends super const export import",
            6: "enum",
            strict: "implements interface let package private protected public static yield",
            strictBind: "eval arguments"
        },
        K = "break case catch continue debugger default do else finally for function if return switch throw try var while with null true false instanceof typeof void delete new in this",
        Q = {
            5: K,
            "5module": K + " export import",
            6: K + " const class extends export import super"
        },
        Y = /^in(stanceof)?$/,
        J = new RegExp("[" + G + "]"),
        Z = new RegExp("[" + G + "‌‍·̀-ͯ·҃-֑҇-ׇֽֿׁׂׅׄؐ-ًؚ-٩ٰۖ-ۜ۟-۪ۤۧۨ-ۭ۰-۹ܑܰ-݊ަ-ް߀-߉߫-߽߳ࠖ-࠙ࠛ-ࠣࠥ-ࠧࠩ-࡙࠭-࡛࢘-࢟࣊-ࣣ࣡-ःऺ-़ा-ॏ॑-ॗॢॣ०-९ঁ-ঃ়া-ৄেৈো-্ৗৢৣ০-৯৾ਁ-ਃ਼ਾ-ੂੇੈੋ-੍ੑ੦-ੱੵઁ-ઃ઼ા-ૅે-ૉો-્ૢૣ૦-૯ૺ-૿ଁ-ଃ଼ା-ୄେୈୋ-୍୕-ୗୢୣ୦-୯ஂா-ூெ-ைொ-்ௗ௦-௯ఀ-ఄ఼ా-ౄె-ైొ-్ౕౖౢౣ౦-౯ಁ-ಃ಼ಾ-ೄೆ-ೈೊ-್ೕೖೢೣ೦-೯ೳഀ-ഃ഻഼ാ-ൄെ-ൈൊ-്ൗൢൣ൦-൯ඁ-ඃ්ා-ුූෘ-ෟ෦-෯ෲෳัิ-ฺ็-๎๐-๙ັິ-ຼ່-໎໐-໙༘༙༠-༩༹༵༷༾༿ཱ-྄྆྇ྍ-ྗྙ-ྼ࿆ါ-ှ၀-၉ၖ-ၙၞ-ၠၢ-ၤၧ-ၭၱ-ၴႂ-ႍႏ-ႝ፝-፟፩-፱ᜒ-᜕ᜲ-᜴ᝒᝓᝲᝳ឴-៓៝០-៩᠋-᠍᠏-᠙ᢩᤠ-ᤫᤰ-᤻᥆-᥏᧐-᧚ᨗ-ᨛᩕ-ᩞ᩠-᩿᩼-᪉᪐-᪙᪰-᪽ᪿ-ᫎᬀ-ᬄ᬴-᭄᭐-᭙᭫-᭳ᮀ-ᮂᮡ-ᮭ᮰-᮹᯦-᯳ᰤ-᰷᱀-᱉᱐-᱙᳐-᳔᳒-᳨᳭᳴᳷-᳹᷀-᷿‿⁀⁔⃐-⃥⃜⃡-⃰⳯-⵿⳱ⷠ-〪ⷿ-゙゚〯꘠-꘩꙯ꙴ-꙽ꚞꚟ꛰꛱ꠂ꠆ꠋꠣ-ꠧ꠬ꢀꢁꢴ-ꣅ꣐-꣙꣠-꣱ꣿ-꤉ꤦ-꤭ꥇ-꥓ꦀ-ꦃ꦳-꧀꧐-꧙ꧥ꧰-꧹ꨩ-ꨶꩃꩌꩍ꩐-꩙ꩻ-ꩽꪰꪲ-ꪴꪷꪸꪾ꪿꫁ꫫ-ꫯꫵ꫶ꯣ-ꯪ꯬꯭꯰-꯹ﬞ︀-️︠-︯︳︴﹍-﹏０-９＿]");

    function X(e, t) {
        for (var i = 65536, s = 0; s < t.length; s += 2) {
            if ((i += t[s]) > e) return !1;
            if ((i += t[s + 1]) >= e) return !0
        }
        return !1
    }

    function ee(e, t) {
        return e < 65 ? 36 === e : e < 91 || (e < 97 ? 95 === e : e < 123 || (e <= 65535 ? e >= 170 && J.test(String.fromCharCode(e)) : !1 !== t && X(e, q)))
    }

    function te(e, t) {
        return e < 48 ? 36 === e : e < 58 || !(e < 65) && (e < 91 || (e < 97 ? 95 === e : e < 123 || (e <= 65535 ? e >= 170 && Z.test(String.fromCharCode(e)) : !1 !== t && (X(e, q) || X(e, W)))))
    }
    var ie = function(e, t) {
        void 0 === t && (t = {}), this.label = e, this.keyword = t.keyword, this.beforeExpr = !!t.beforeExpr, this.startsExpr = !!t.startsExpr, this.isLoop = !!t.isLoop, this.isAssign = !!t.isAssign, this.prefix = !!t.prefix, this.postfix = !!t.postfix, this.binop = t.binop || null, this.updateContext = null
    };

    function se(e, t) {
        return new ie(e, {
            beforeExpr: !0,
            binop: t
        })
    }
    var re = {
            beforeExpr: !0
        },
        ne = {
            startsExpr: !0
        },
        ae = {};

    function oe(e, t) {
        return void 0 === t && (t = {}), t.keyword = e, ae[e] = new ie(e, t)
    }
    var ce = {
            num: new ie("num", ne),
            regexp: new ie("regexp", ne),
            string: new ie("string", ne),
            name: new ie("name", ne),
            privateId: new ie("privateId", ne),
            eof: new ie("eof"),
            bracketL: new ie("[", {
                beforeExpr: !0,
                startsExpr: !0
            }),
            bracketR: new ie("]"),
            braceL: new ie("{", {
                beforeExpr: !0,
                startsExpr: !0
            }),
            braceR: new ie("}"),
            parenL: new ie("(", {
                beforeExpr: !0,
                startsExpr: !0
            }),
            parenR: new ie(")"),
            comma: new ie(",", re),
            semi: new ie(";", re),
            colon: new ie(":", re),
            dot: new ie("."),
            question: new ie("?", re),
            questionDot: new ie("?."),
            arrow: new ie("=>", re),
            template: new ie("template"),
            invalidTemplate: new ie("invalidTemplate"),
            ellipsis: new ie("...", re),
            backQuote: new ie("`", ne),
            dollarBraceL: new ie("${", {
                beforeExpr: !0,
                startsExpr: !0
            }),
            eq: new ie("=", {
                beforeExpr: !0,
                isAssign: !0
            }),
            assign: new ie("_=", {
                beforeExpr: !0,
                isAssign: !0
            }),
            incDec: new ie("++/--", {
                prefix: !0,
                postfix: !0,
                startsExpr: !0
            }),
            prefix: new ie("!/~", {
                beforeExpr: !0,
                prefix: !0,
                startsExpr: !0
            }),
            logicalOR: se("||", 1),
            logicalAND: se("&&", 2),
            bitwiseOR: se("|", 3),
            bitwiseXOR: se("^", 4),
            bitwiseAND: se("&", 5),
            equality: se("==/!=/===/!==", 6),
            relational: se("</>/<=/>=", 7),
            bitShift: se("<</>>/>>>", 8),
            plusMin: new ie("+/-", {
                beforeExpr: !0,
                binop: 9,
                prefix: !0,
                startsExpr: !0
            }),
            modulo: se("%", 10),
            star: se("*", 10),
            slash: se("/", 10),
            starstar: new ie("**", {
                beforeExpr: !0
            }),
            coalesce: se("??", 1),
            _break: oe("break"),
            _case: oe("case", re),
            _catch: oe("catch"),
            _continue: oe("continue"),
            _debugger: oe("debugger"),
            _default: oe("default", re),
            _do: oe("do", {
                isLoop: !0,
                beforeExpr: !0
            }),
            _else: oe("else", re),
            _finally: oe("finally"),
            _for: oe("for", {
                isLoop: !0
            }),
            _function: oe("function", ne),
            _if: oe("if"),
            _return: oe("return", re),
            _switch: oe("switch"),
            _throw: oe("throw", re),
            _try: oe("try"),
            _var: oe("var"),
            _const: oe("const"),
            _while: oe("while", {
                isLoop: !0
            }),
            _with: oe("with"),
            _new: oe("new", {
                beforeExpr: !0,
                startsExpr: !0
            }),
            _this: oe("this", ne),
            _super: oe("super", ne),
            _class: oe("class", ne),
            _extends: oe("extends", re),
            _export: oe("export"),
            _import: oe("import", ne),
            _null: oe("null", ne),
            _true: oe("true", ne),
            _false: oe("false", ne),
            _in: oe("in", {
                beforeExpr: !0,
                binop: 7
            }),
            _instanceof: oe("instanceof", {
                beforeExpr: !0,
                binop: 7
            }),
            _typeof: oe("typeof", {
                beforeExpr: !0,
                prefix: !0,
                startsExpr: !0
            }),
            _void: oe("void", {
                beforeExpr: !0,
                prefix: !0,
                startsExpr: !0
            }),
            _delete: oe("delete", {
                beforeExpr: !0,
                prefix: !0,
                startsExpr: !0
            })
        },
        he = /\r\n?|\n|\u2028|\u2029/,
        le = new RegExp(he.source, "g");

    function pe(e) {
        return 10 === e || 13 === e || 8232 === e || 8233 === e
    }

    function ue(e, t, i) {
        void 0 === i && (i = e.length);
        for (var s = t; s < i; s++) {
            var r = e.charCodeAt(s);
            if (pe(r)) return s < i - 1 && 13 === r && 10 === e.charCodeAt(s + 1) ? s + 2 : s + 1
        }
        return -1
    }
    var de = /[\u1680\u2000-\u200a\u202f\u205f\u3000\ufeff]/,
        fe = /(?:\s|\/\/.*|\/\*[^]*?\*\/)*/g,
        me = Object.prototype,
        ge = me.hasOwnProperty,
        xe = me.toString,
        ye = Object.hasOwn || function(e, t) {
            return ge.call(e, t)
        },
        ve = Array.isArray || function(e) {
            return "[object Array]" === xe.call(e)
        };

    function we(e) {
        return new RegExp("^(?:" + e.replace(/ /g, "|") + ")$")
    }

    function be(e) {
        return e <= 65535 ? String.fromCharCode(e) : (e -= 65536, String.fromCharCode(55296 + (e >> 10), 56320 + (1023 & e)))
    }
    var _e = /(?:[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])/,
        ke = function(e, t) {
            this.line = e, this.column = t
        };
    ke.prototype.offset = function(e) {
        return new ke(this.line, this.column + e)
    };
    var Ce = function(e, t, i) {
        this.start = t, this.end = i, null !== e.sourceFile && (this.source = e.sourceFile)
    };

    function Ee(e, t) {
        for (var i = 1, s = 0;;) {
            var r = ue(e, s, t);
            if (r < 0) return new ke(i, t - s);
            ++i, s = r
        }
    }
    var Se = {
            ecmaVersion: null,
            sourceType: "script",
            onInsertedSemicolon: null,
            onTrailingComma: null,
            allowReserved: null,
            allowReturnOutsideFunction: !1,
            allowImportExportEverywhere: !1,
            allowAwaitOutsideFunction: null,
            allowSuperOutsideMethod: null,
            allowHashBang: !1,
            checkPrivateFields: !0,
            locations: !1,
            onToken: null,
            onComment: null,
            ranges: !1,
            program: null,
            sourceFile: null,
            directSourceFile: null,
            preserveParens: !1
        },
        Ie = !1;

    function Ae(e) {
        var t = {};
        for (var i in Se) t[i] = e && ye(e, i) ? e[i] : Se[i];
        if ("latest" === t.ecmaVersion ? t.ecmaVersion = 1e8 : null == t.ecmaVersion ? (!Ie && "object" == typeof console && console.warn && (Ie = !0, console.warn("Since Acorn 8.0.0, options.ecmaVersion is required.\nDefaulting to 2020, but this will stop working in the future.")), t.ecmaVersion = 11) : t.ecmaVersion >= 2015 && (t.ecmaVersion -= 2009), null == t.allowReserved && (t.allowReserved = t.ecmaVersion < 5), (!e || null == e.allowHashBang) && (t.allowHashBang = t.ecmaVersion >= 14), ve(t.onToken)) {
            var s = t.onToken;
            t.onToken = function(e) {
                return s.push(e)
            }
        }
        return ve(t.onComment) && (t.onComment = function(e, t) {
            return function(i, s, r, n, a, o) {
                var c = {
                    type: i ? "Block" : "Line",
                    value: s,
                    start: r,
                    end: n
                };
                e.locations && (c.loc = new Ce(this, a, o)), e.ranges && (c.range = [r, n]), t.push(c)
            }
        }(t, t.onComment)), t
    }
    var Pe = 256;

    function Ne(e, t) {
        return 2 | (e ? 4 : 0) | (t ? 8 : 0)
    }
    var Le = function(e, t, i) {
            this.options = e = Ae(e), this.sourceFile = e.sourceFile, this.keywords = we(Q[e.ecmaVersion >= 6 ? 6 : "module" === e.sourceType ? "5module" : 5]);
            var s = "";
            !0 !== e.allowReserved && (s = z[e.ecmaVersion >= 6 ? 6 : 5 === e.ecmaVersion ? 5 : 3], "module" === e.sourceType && (s += " await")), this.reservedWords = we(s);
            var r = (s ? s + " " : "") + z.strict;
            this.reservedWordsStrict = we(r), this.reservedWordsStrictBind = we(r + " " + z.strictBind), this.input = String(t), this.containsEsc = !1, i ? (this.pos = i, this.lineStart = this.input.lastIndexOf("\n", i - 1) + 1, this.curLine = this.input.slice(0, this.lineStart).split(he).length) : (this.pos = this.lineStart = 0, this.curLine = 1), this.type = ce.eof, this.value = null, this.start = this.end = this.pos, this.startLoc = this.endLoc = this.curPosition(), this.lastTokEndLoc = this.lastTokStartLoc = null, this.lastTokStart = this.lastTokEnd = this.pos, this.context = this.initialContext(), this.exprAllowed = !0, this.inModule = "module" === e.sourceType, this.strict = this.inModule || this.strictDirective(this.pos), this.potentialArrowAt = -1, this.potentialArrowInForAwait = !1, this.yieldPos = this.awaitPos = this.awaitIdentPos = 0, this.labels = [], this.undefinedExports = Object.create(null), 0 === this.pos && e.allowHashBang && "#!" === this.input.slice(0, 2) && this.skipLineComment(2), this.scopeStack = [], this.enterScope(1), this.regexpState = null, this.privateNameStack = []
        },
        Te = {
            inFunction: {
                configurable: !0
            },
            inGenerator: {
                configurable: !0
            },
            inAsync: {
                configurable: !0
            },
            canAwait: {
                configurable: !0
            },
            allowSuper: {
                configurable: !0
            },
            allowDirectSuper: {
                configurable: !0
            },
            treatFunctionsAsVar: {
                configurable: !0
            },
            allowNewDotTarget: {
                configurable: !0
            },
            inClassStaticBlock: {
                configurable: !0
            }
        };
    Le.prototype.parse = function() {
        var e = this.options.program || this.startNode();
        return this.nextToken(), this.parseTopLevel(e)
    }, Te.inFunction.get = function() {
        return (2 & this.currentVarScope().flags) > 0
    }, Te.inGenerator.get = function() {
        return (8 & this.currentVarScope().flags) > 0 && !this.currentVarScope().inClassFieldInit
    }, Te.inAsync.get = function() {
        return (4 & this.currentVarScope().flags) > 0 && !this.currentVarScope().inClassFieldInit
    }, Te.canAwait.get = function() {
        for (var e = this.scopeStack.length - 1; e >= 0; e--) {
            var t = this.scopeStack[e];
            if (t.inClassFieldInit || t.flags & Pe) return !1;
            if (2 & t.flags) return (4 & t.flags) > 0
        }
        return this.inModule && this.options.ecmaVersion >= 13 || this.options.allowAwaitOutsideFunction
    }, Te.allowSuper.get = function() {
        var e = this.currentThisScope(),
            t = e.flags,
            i = e.inClassFieldInit;
        return (64 & t) > 0 || i || this.options.allowSuperOutsideMethod
    }, Te.allowDirectSuper.get = function() {
        return (128 & this.currentThisScope().flags) > 0
    }, Te.treatFunctionsAsVar.get = function() {
        return this.treatFunctionsAsVarInScope(this.currentScope())
    }, Te.allowNewDotTarget.get = function() {
        var e = this.currentThisScope(),
            t = e.flags,
            i = e.inClassFieldInit;
        return (258 & t) > 0 || i
    }, Te.inClassStaticBlock.get = function() {
        return (this.currentVarScope().flags & Pe) > 0
    }, Le.extend = function() {
        for (var e = [], t = arguments.length; t--;) e[t] = arguments[t];
        for (var i = this, s = 0; s < e.length; s++) i = e[s](i);
        return i
    }, Le.parse = function(e, t) {
        return new this(t, e).parse()
    }, Le.parseExpressionAt = function(e, t, i) {
        var s = new this(i, e, t);
        return s.nextToken(), s.parseExpression()
    }, Le.tokenizer = function(e, t) {
        return new this(t, e)
    }, Object.defineProperties(Le.prototype, Te);
    var Re = Le.prototype,
        Ve = /^(?:'((?:\\.|[^'\\])*?)'|"((?:\\.|[^"\\])*?)")/;
    Re.strictDirective = function(e) {
        if (this.options.ecmaVersion < 5) return !1;
        for (;;) {
            fe.lastIndex = e, e += fe.exec(this.input)[0].length;
            var t = Ve.exec(this.input.slice(e));
            if (!t) return !1;
            if ("use strict" === (t[1] || t[2])) {
                fe.lastIndex = e + t[0].length;
                var i = fe.exec(this.input),
                    s = i.index + i[0].length,
                    r = this.input.charAt(s);
                return ";" === r || "}" === r || he.test(i[0]) && !(/[(`.[+\-/*%<>=,?^&]/.test(r) || "!" === r && "=" === this.input.charAt(s + 1))
            }
            e += t[0].length, fe.lastIndex = e, e += fe.exec(this.input)[0].length, ";" === this.input[e] && e++
        }
    }, Re.eat = function(e) {
        return this.type === e && (this.next(), !0)
    }, Re.isContextual = function(e) {
        return this.type === ce.name && this.value === e && !this.containsEsc
    }, Re.eatContextual = function(e) {
        return !!this.isContextual(e) && (this.next(), !0)
    }, Re.expectContextual = function(e) {
        this.eatContextual(e) || this.unexpected()
    }, Re.canInsertSemicolon = function() {
        return this.type === ce.eof || this.type === ce.braceR || he.test(this.input.slice(this.lastTokEnd, this.start))
    }, Re.insertSemicolon = function() {
        if (this.canInsertSemicolon()) return this.options.onInsertedSemicolon && this.options.onInsertedSemicolon(this.lastTokEnd, this.lastTokEndLoc), !0
    }, Re.semicolon = function() {
        !this.eat(ce.semi) && !this.insertSemicolon() && this.unexpected()
    }, Re.afterTrailingComma = function(e, t) {
        if (this.type === e) return this.options.onTrailingComma && this.options.onTrailingComma(this.lastTokStart, this.lastTokStartLoc), t || this.next(), !0
    }, Re.expect = function(e) {
        this.eat(e) || this.unexpected()
    }, Re.unexpected = function(e) {
        this.raise(e ? ? this.start, "Unexpected token")
    };
    var Oe = function() {
        this.shorthandAssign = this.trailingComma = this.parenthesizedAssign = this.parenthesizedBind = this.doubleProto = -1
    };
    Re.checkPatternErrors = function(e, t) {
        if (e) {
            e.trailingComma > -1 && this.raiseRecoverable(e.trailingComma, "Comma is not permitted after the rest element");
            var i = t ? e.parenthesizedAssign : e.parenthesizedBind;
            i > -1 && this.raiseRecoverable(i, t ? "Assigning to rvalue" : "Parenthesized pattern")
        }
    }, Re.checkExpressionErrors = function(e, t) {
        if (!e) return !1;
        var i = e.shorthandAssign,
            s = e.doubleProto;
        if (!t) return i >= 0 || s >= 0;
        i >= 0 && this.raise(i, "Shorthand property assignments are valid only in destructuring patterns"), s >= 0 && this.raiseRecoverable(s, "Redefinition of __proto__ property")
    }, Re.checkYieldAwaitInDefaultParams = function() {
        this.yieldPos && (!this.awaitPos || this.yieldPos < this.awaitPos) && this.raise(this.yieldPos, "Yield expression cannot be a default value"), this.awaitPos && this.raise(this.awaitPos, "Await expression cannot be a default value")
    }, Re.isSimpleAssignTarget = function(e) {
        return "ParenthesizedExpression" === e.type ? this.isSimpleAssignTarget(e.expression) : "Identifier" === e.type || "MemberExpression" === e.type
    };
    var De = Le.prototype;
    De.parseTopLevel = function(e) {
        var t = Object.create(null);
        for (e.body || (e.body = []); this.type !== ce.eof;) {
            var i = this.parseStatement(null, !0, t);
            e.body.push(i)
        }
        if (this.inModule)
            for (var s = 0, r = Object.keys(this.undefinedExports); s < r.length; s += 1) {
                var n = r[s];
                this.raiseRecoverable(this.undefinedExports[n].start, "Export '" + n + "' is not defined")
            }
        return this.adaptDirectivePrologue(e.body), this.next(), e.sourceType = this.options.sourceType, this.finishNode(e, "Program")
    };
    var je = {
            kind: "loop"
        },
        Me = {
            kind: "switch"
        };
    De.isLet = function(e) {
        if (this.options.ecmaVersion < 6 || !this.isContextual("let")) return !1;
        fe.lastIndex = this.pos;
        var t = fe.exec(this.input),
            i = this.pos + t[0].length,
            s = this.input.charCodeAt(i);
        if (91 === s || 92 === s) return !0;
        if (e) return !1;
        if (123 === s || s > 55295 && s < 56320) return !0;
        if (ee(s, !0)) {
            for (var r = i + 1; te(s = this.input.charCodeAt(r), !0);) ++r;
            if (92 === s || s > 55295 && s < 56320) return !0;
            var n = this.input.slice(i, r);
            if (!Y.test(n)) return !0
        }
        return !1
    }, De.isAsyncFunction = function() {
        if (this.options.ecmaVersion < 8 || !this.isContextual("async")) return !1;
        fe.lastIndex = this.pos;
        var e, t = fe.exec(this.input),
            i = this.pos + t[0].length;
        return !(he.test(this.input.slice(this.pos, i)) || "function" !== this.input.slice(i, i + 8) || i + 8 !== this.input.length && (te(e = this.input.charCodeAt(i + 8)) || e > 55295 && e < 56320))
    }, De.parseStatement = function(e, t, i) {
        var s, r = this.type,
            n = this.startNode();
        switch (this.isLet(e) && (r = ce._var, s = "let"), r) {
            case ce._break:
            case ce._continue:
                return this.parseBreakContinueStatement(n, r.keyword);
            case ce._debugger:
                return this.parseDebuggerStatement(n);
            case ce._do:
                return this.parseDoStatement(n);
            case ce._for:
                return this.parseForStatement(n);
            case ce._function:
                return e && (this.strict || "if" !== e && "label" !== e) && this.options.ecmaVersion >= 6 && this.unexpected(), this.parseFunctionStatement(n, !1, !e);
            case ce._class:
                return e && this.unexpected(), this.parseClass(n, !0);
            case ce._if:
                return this.parseIfStatement(n);
            case ce._return:
                return this.parseReturnStatement(n);
            case ce._switch:
                return this.parseSwitchStatement(n);
            case ce._throw:
                return this.parseThrowStatement(n);
            case ce._try:
                return this.parseTryStatement(n);
            case ce._const:
            case ce._var:
                return s = s || this.value, e && "var" !== s && this.unexpected(), this.parseVarStatement(n, s);
            case ce._while:
                return this.parseWhileStatement(n);
            case ce._with:
                return this.parseWithStatement(n);
            case ce.braceL:
                return this.parseBlock(!0, n);
            case ce.semi:
                return this.parseEmptyStatement(n);
            case ce._export:
            case ce._import:
                if (this.options.ecmaVersion > 10 && r === ce._import) {
                    fe.lastIndex = this.pos;
                    var a = fe.exec(this.input),
                        o = this.pos + a[0].length,
                        c = this.input.charCodeAt(o);
                    if (40 === c || 46 === c) return this.parseExpressionStatement(n, this.parseExpression())
                }
                return this.options.allowImportExportEverywhere || (t || this.raise(this.start, "'import' and 'export' may only appear at the top level"), this.inModule || this.raise(this.start, "'import' and 'export' may appear only with 'sourceType: module'")), r === ce._import ? this.parseImport(n) : this.parseExport(n, i);
            default:
                if (this.isAsyncFunction()) return e && this.unexpected(), this.next(), this.parseFunctionStatement(n, !0, !e);
                var h = this.value,
                    l = this.parseExpression();
                return r === ce.name && "Identifier" === l.type && this.eat(ce.colon) ? this.parseLabeledStatement(n, h, l, e) : this.parseExpressionStatement(n, l)
        }
    }, De.parseBreakContinueStatement = function(e, t) {
        var i = "break" === t;
        this.next(), this.eat(ce.semi) || this.insertSemicolon() ? e.label = null : this.type !== ce.name ? this.unexpected() : (e.label = this.parseIdent(), this.semicolon());
        for (var s = 0; s < this.labels.length; ++s) {
            var r = this.labels[s];
            if ((null == e.label || r.name === e.label.name) && (null != r.kind && (i || "loop" === r.kind) || e.label && i)) break
        }
        return s === this.labels.length && this.raise(e.start, "Unsyntactic " + t), this.finishNode(e, i ? "BreakStatement" : "ContinueStatement")
    }, De.parseDebuggerStatement = function(e) {
        return this.next(), this.semicolon(), this.finishNode(e, "DebuggerStatement")
    }, De.parseDoStatement = function(e) {
        return this.next(), this.labels.push(je), e.body = this.parseStatement("do"), this.labels.pop(), this.expect(ce._while), e.test = this.parseParenExpression(), this.options.ecmaVersion >= 6 ? this.eat(ce.semi) : this.semicolon(), this.finishNode(e, "DoWhileStatement")
    }, De.parseForStatement = function(e) {
        this.next();
        var t = this.options.ecmaVersion >= 9 && this.canAwait && this.eatContextual("await") ? this.lastTokStart : -1;
        if (this.labels.push(je), this.enterScope(0), this.expect(ce.parenL), this.type === ce.semi) return t > -1 && this.unexpected(t), this.parseFor(e, null);
        var i = this.isLet();
        if (this.type === ce._var || this.type === ce._const || i) {
            var s = this.startNode(),
                r = i ? "let" : this.value;
            return this.next(), this.parseVar(s, !0, r), this.finishNode(s, "VariableDeclaration"), (this.type === ce._in || this.options.ecmaVersion >= 6 && this.isContextual("of")) && 1 === s.declarations.length ? (this.options.ecmaVersion >= 9 && (this.type === ce._in ? t > -1 && this.unexpected(t) : e.await = t > -1), this.parseForIn(e, s)) : (t > -1 && this.unexpected(t), this.parseFor(e, s))
        }
        var n = this.isContextual("let"),
            a = !1,
            o = new Oe,
            c = this.parseExpression(!(t > -1) || "await", o);
        return this.type === ce._in || (a = this.options.ecmaVersion >= 6 && this.isContextual("of")) ? (this.options.ecmaVersion >= 9 && (this.type === ce._in ? t > -1 && this.unexpected(t) : e.await = t > -1), n && a && this.raise(c.start, "The left-hand side of a for-of loop may not start with 'let'."), this.toAssignable(c, !1, o), this.checkLValPattern(c), this.parseForIn(e, c)) : (this.checkExpressionErrors(o, !0), t > -1 && this.unexpected(t), this.parseFor(e, c))
    }, De.parseFunctionStatement = function(e, t, i) {
        return this.next(), this.parseFunction(e, Ue | (i ? 0 : $e), !1, t)
    }, De.parseIfStatement = function(e) {
        return this.next(), e.test = this.parseParenExpression(), e.consequent = this.parseStatement("if"), e.alternate = this.eat(ce._else) ? this.parseStatement("if") : null, this.finishNode(e, "IfStatement")
    }, De.parseReturnStatement = function(e) {
        return !this.inFunction && !this.options.allowReturnOutsideFunction && this.raise(this.start, "'return' outside of function"), this.next(), this.eat(ce.semi) || this.insertSemicolon() ? e.argument = null : (e.argument = this.parseExpression(), this.semicolon()), this.finishNode(e, "ReturnStatement")
    }, De.parseSwitchStatement = function(e) {
        this.next(), e.discriminant = this.parseParenExpression(), e.cases = [], this.expect(ce.braceL), this.labels.push(Me), this.enterScope(0);
        for (var t, i = !1; this.type !== ce.braceR;)
            if (this.type === ce._case || this.type === ce._default) {
                var s = this.type === ce._case;
                t && this.finishNode(t, "SwitchCase"), e.cases.push(t = this.startNode()), t.consequent = [], this.next(), s ? t.test = this.parseExpression() : (i && this.raiseRecoverable(this.lastTokStart, "Multiple default clauses"), i = !0, t.test = null), this.expect(ce.colon)
            } else t || this.unexpected(), t.consequent.push(this.parseStatement(null));
        return this.exitScope(), t && this.finishNode(t, "SwitchCase"), this.next(), this.labels.pop(), this.finishNode(e, "SwitchStatement")
    }, De.parseThrowStatement = function(e) {
        return this.next(), he.test(this.input.slice(this.lastTokEnd, this.start)) && this.raise(this.lastTokEnd, "Illegal newline after throw"), e.argument = this.parseExpression(), this.semicolon(), this.finishNode(e, "ThrowStatement")
    };
    var Be = [];
    De.parseCatchClauseParam = function() {
        var e = this.parseBindingAtom(),
            t = "Identifier" === e.type;
        return this.enterScope(t ? 32 : 0), this.checkLValPattern(e, t ? 4 : 2), this.expect(ce.parenR), e
    }, De.parseTryStatement = function(e) {
        if (this.next(), e.block = this.parseBlock(), e.handler = null, this.type === ce._catch) {
            var t = this.startNode();
            this.next(), this.eat(ce.parenL) ? t.param = this.parseCatchClauseParam() : (this.options.ecmaVersion < 10 && this.unexpected(), t.param = null, this.enterScope(0)), t.body = this.parseBlock(!1), this.exitScope(), e.handler = this.finishNode(t, "CatchClause")
        }
        return e.finalizer = this.eat(ce._finally) ? this.parseBlock() : null, !e.handler && !e.finalizer && this.raise(e.start, "Missing catch or finally clause"), this.finishNode(e, "TryStatement")
    }, De.parseVarStatement = function(e, t, i) {
        return this.next(), this.parseVar(e, !1, t, i), this.semicolon(), this.finishNode(e, "VariableDeclaration")
    }, De.parseWhileStatement = function(e) {
        return this.next(), e.test = this.parseParenExpression(), this.labels.push(je), e.body = this.parseStatement("while"), this.labels.pop(), this.finishNode(e, "WhileStatement")
    }, De.parseWithStatement = function(e) {
        return this.strict && this.raise(this.start, "'with' in strict mode"), this.next(), e.object = this.parseParenExpression(), e.body = this.parseStatement("with"), this.finishNode(e, "WithStatement")
    }, De.parseEmptyStatement = function(e) {
        return this.next(), this.finishNode(e, "EmptyStatement")
    }, De.parseLabeledStatement = function(e, t, i, s) {
        for (var r = 0, n = this.labels; r < n.length; r += 1) {
            n[r].name === t && this.raise(i.start, "Label '" + t + "' is already declared")
        }
        for (var a = this.type.isLoop ? "loop" : this.type === ce._switch ? "switch" : null, o = this.labels.length - 1; o >= 0; o--) {
            var c = this.labels[o];
            if (c.statementStart !== e.start) break;
            c.statementStart = this.start, c.kind = a
        }
        return this.labels.push({
            name: t,
            kind: a,
            statementStart: this.start
        }), e.body = this.parseStatement(s ? -1 === s.indexOf("label") ? s + "label" : s : "label"), this.labels.pop(), e.label = i, this.finishNode(e, "LabeledStatement")
    }, De.parseExpressionStatement = function(e, t) {
        return e.expression = t, this.semicolon(), this.finishNode(e, "ExpressionStatement")
    }, De.parseBlock = function(e, t, i) {
        for (void 0 === e && (e = !0), void 0 === t && (t = this.startNode()), t.body = [], this.expect(ce.braceL), e && this.enterScope(0); this.type !== ce.braceR;) {
            var s = this.parseStatement(null);
            t.body.push(s)
        }
        return i && (this.strict = !1), this.next(), e && this.exitScope(), this.finishNode(t, "BlockStatement")
    }, De.parseFor = function(e, t) {
        return e.init = t, this.expect(ce.semi), e.test = this.type === ce.semi ? null : this.parseExpression(), this.expect(ce.semi), e.update = this.type === ce.parenR ? null : this.parseExpression(), this.expect(ce.parenR), e.body = this.parseStatement("for"), this.exitScope(), this.labels.pop(), this.finishNode(e, "ForStatement")
    }, De.parseForIn = function(e, t) {
        var i = this.type === ce._in;
        return this.next(), "VariableDeclaration" === t.type && null != t.declarations[0].init && (!i || this.options.ecmaVersion < 8 || this.strict || "var" !== t.kind || "Identifier" !== t.declarations[0].id.type) && this.raise(t.start, (i ? "for-in" : "for-of") + " loop variable declaration may not have an initializer"), e.left = t, e.right = i ? this.parseExpression() : this.parseMaybeAssign(), this.expect(ce.parenR), e.body = this.parseStatement("for"), this.exitScope(), this.labels.pop(), this.finishNode(e, i ? "ForInStatement" : "ForOfStatement")
    }, De.parseVar = function(e, t, i, s) {
        for (e.declarations = [], e.kind = i;;) {
            var r = this.startNode();
            if (this.parseVarId(r, i), this.eat(ce.eq) ? r.init = this.parseMaybeAssign(t) : s || "const" !== i || this.type === ce._in || this.options.ecmaVersion >= 6 && this.isContextual("of") ? s || "Identifier" === r.id.type || t && (this.type === ce._in || this.isContextual("of")) ? r.init = null : this.raise(this.lastTokEnd, "Complex binding patterns require an initialization value") : this.unexpected(), e.declarations.push(this.finishNode(r, "VariableDeclarator")), !this.eat(ce.comma)) break
        }
        return e
    }, De.parseVarId = function(e, t) {
        e.id = this.parseBindingAtom(), this.checkLValPattern(e.id, "var" === t ? 1 : 2, !1)
    };
    var Ue = 1,
        $e = 2;

    function Fe(e, t) {
        var i = t.key.name,
            s = e[i],
            r = "true";
        return "MethodDefinition" === t.type && ("get" === t.kind || "set" === t.kind) && (r = (t.static ? "s" : "i") + t.kind), "iget" === s && "iset" === r || "iset" === s && "iget" === r || "sget" === s && "sset" === r || "sset" === s && "sget" === r ? (e[i] = "true", !1) : !!s || (e[i] = r, !1)
    }

    function He(e, t) {
        var i = e.computed,
            s = e.key;
        return !i && ("Identifier" === s.type && s.name === t || "Literal" === s.type && s.value === t)
    }
    De.parseFunction = function(e, t, i, s, r) {
        this.initFunction(e), (this.options.ecmaVersion >= 9 || this.options.ecmaVersion >= 6 && !s) && (this.type === ce.star && t & $e && this.unexpected(), e.generator = this.eat(ce.star)), this.options.ecmaVersion >= 8 && (e.async = !!s), t & Ue && (e.id = 4 & t && this.type !== ce.name ? null : this.parseIdent(), e.id && !(t & $e) && this.checkLValSimple(e.id, this.strict || e.generator || e.async ? this.treatFunctionsAsVar ? 1 : 2 : 3));
        var n = this.yieldPos,
            a = this.awaitPos,
            o = this.awaitIdentPos;
        return this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0, this.enterScope(Ne(e.async, e.generator)), t & Ue || (e.id = this.type === ce.name ? this.parseIdent() : null), this.parseFunctionParams(e), this.parseFunctionBody(e, i, !1, r), this.yieldPos = n, this.awaitPos = a, this.awaitIdentPos = o, this.finishNode(e, t & Ue ? "FunctionDeclaration" : "FunctionExpression")
    }, De.parseFunctionParams = function(e) {
        this.expect(ce.parenL), e.params = this.parseBindingList(ce.parenR, !1, this.options.ecmaVersion >= 8), this.checkYieldAwaitInDefaultParams()
    }, De.parseClass = function(e, t) {
        this.next();
        var i = this.strict;
        this.strict = !0, this.parseClassId(e, t), this.parseClassSuper(e);
        var s = this.enterClassBody(),
            r = this.startNode(),
            n = !1;
        for (r.body = [], this.expect(ce.braceL); this.type !== ce.braceR;) {
            var a = this.parseClassElement(null !== e.superClass);
            a && (r.body.push(a), "MethodDefinition" === a.type && "constructor" === a.kind ? (n && this.raiseRecoverable(a.start, "Duplicate constructor in the same class"), n = !0) : a.key && "PrivateIdentifier" === a.key.type && Fe(s, a) && this.raiseRecoverable(a.key.start, "Identifier '#" + a.key.name + "' has already been declared"))
        }
        return this.strict = i, this.next(), e.body = this.finishNode(r, "ClassBody"), this.exitClassBody(), this.finishNode(e, t ? "ClassDeclaration" : "ClassExpression")
    }, De.parseClassElement = function(e) {
        if (this.eat(ce.semi)) return null;
        var t = this.options.ecmaVersion,
            i = this.startNode(),
            s = "",
            r = !1,
            n = !1,
            a = "method",
            o = !1;
        if (this.eatContextual("static")) {
            if (t >= 13 && this.eat(ce.braceL)) return this.parseClassStaticBlock(i), i;
            this.isClassElementNameStart() || this.type === ce.star ? o = !0 : s = "static"
        }
        if (i.static = o, !s && t >= 8 && this.eatContextual("async") && (!this.isClassElementNameStart() && this.type !== ce.star || this.canInsertSemicolon() ? s = "async" : n = !0), !s && (t >= 9 || !n) && this.eat(ce.star) && (r = !0), !s && !n && !r) {
            var c = this.value;
            (this.eatContextual("get") || this.eatContextual("set")) && (this.isClassElementNameStart() ? a = c : s = c)
        }
        if (s ? (i.computed = !1, i.key = this.startNodeAt(this.lastTokStart, this.lastTokStartLoc), i.key.name = s, this.finishNode(i.key, "Identifier")) : this.parseClassElementName(i), t < 13 || this.type === ce.parenL || "method" !== a || r || n) {
            var h = !i.static && He(i, "constructor"),
                l = h && e;
            h && "method" !== a && this.raise(i.key.start, "Constructor can't have get/set modifier"), i.kind = h ? "constructor" : a, this.parseClassMethod(i, r, n, l)
        } else this.parseClassField(i);
        return i
    }, De.isClassElementNameStart = function() {
        return this.type === ce.name || this.type === ce.privateId || this.type === ce.num || this.type === ce.string || this.type === ce.bracketL || this.type.keyword
    }, De.parseClassElementName = function(e) {
        this.type === ce.privateId ? ("constructor" === this.value && this.raise(this.start, "Classes can't have an element named '#constructor'"), e.computed = !1, e.key = this.parsePrivateIdent()) : this.parsePropertyName(e)
    }, De.parseClassMethod = function(e, t, i, s) {
        var r = e.key;
        "constructor" === e.kind ? (t && this.raise(r.start, "Constructor can't be a generator"), i && this.raise(r.start, "Constructor can't be an async method")) : e.static && He(e, "prototype") && this.raise(r.start, "Classes may not have a static property named prototype");
        var n = e.value = this.parseMethod(t, i, s);
        return "get" === e.kind && 0 !== n.params.length && this.raiseRecoverable(n.start, "getter should have no params"), "set" === e.kind && 1 !== n.params.length && this.raiseRecoverable(n.start, "setter should have exactly one param"), "set" === e.kind && "RestElement" === n.params[0].type && this.raiseRecoverable(n.params[0].start, "Setter cannot use rest params"), this.finishNode(e, "MethodDefinition")
    }, De.parseClassField = function(e) {
        if (He(e, "constructor") ? this.raise(e.key.start, "Classes can't have a field named 'constructor'") : e.static && He(e, "prototype") && this.raise(e.key.start, "Classes can't have a static field named 'prototype'"), this.eat(ce.eq)) {
            var t = this.currentThisScope(),
                i = t.inClassFieldInit;
            t.inClassFieldInit = !0, e.value = this.parseMaybeAssign(), t.inClassFieldInit = i
        } else e.value = null;
        return this.semicolon(), this.finishNode(e, "PropertyDefinition")
    }, De.parseClassStaticBlock = function(e) {
        e.body = [];
        var t = this.labels;
        for (this.labels = [], this.enterScope(320); this.type !== ce.braceR;) {
            var i = this.parseStatement(null);
            e.body.push(i)
        }
        return this.next(), this.exitScope(), this.labels = t, this.finishNode(e, "StaticBlock")
    }, De.parseClassId = function(e, t) {
        this.type === ce.name ? (e.id = this.parseIdent(), t && this.checkLValSimple(e.id, 2, !1)) : (!0 === t && this.unexpected(), e.id = null)
    }, De.parseClassSuper = function(e) {
        e.superClass = this.eat(ce._extends) ? this.parseExprSubscripts(null, !1) : null
    }, De.enterClassBody = function() {
        var e = {
            declared: Object.create(null),
            used: []
        };
        return this.privateNameStack.push(e), e.declared
    }, De.exitClassBody = function() {
        var e = this.privateNameStack.pop(),
            t = e.declared,
            i = e.used;
        if (this.options.checkPrivateFields)
            for (var s = this.privateNameStack.length, r = 0 === s ? null : this.privateNameStack[s - 1], n = 0; n < i.length; ++n) {
                var a = i[n];
                ye(t, a.name) || (r ? r.used.push(a) : this.raiseRecoverable(a.start, "Private field '#" + a.name + "' must be declared in an enclosing class"))
            }
    }, De.parseExportAllDeclaration = function(e, t) {
        return this.options.ecmaVersion >= 11 && (this.eatContextual("as") ? (e.exported = this.parseModuleExportName(), this.checkExport(t, e.exported, this.lastTokStart)) : e.exported = null), this.expectContextual("from"), this.type !== ce.string && this.unexpected(), e.source = this.parseExprAtom(), this.semicolon(), this.finishNode(e, "ExportAllDeclaration")
    }, De.parseExport = function(e, t) {
        if (this.next(), this.eat(ce.star)) return this.parseExportAllDeclaration(e, t);
        if (this.eat(ce._default)) return this.checkExport(t, "default", this.lastTokStart), e.declaration = this.parseExportDefaultDeclaration(), this.finishNode(e, "ExportDefaultDeclaration");
        if (this.shouldParseExportStatement()) e.declaration = this.parseExportDeclaration(e), "VariableDeclaration" === e.declaration.type ? this.checkVariableExport(t, e.declaration.declarations) : this.checkExport(t, e.declaration.id, e.declaration.id.start), e.specifiers = [], e.source = null;
        else {
            if (e.declaration = null, e.specifiers = this.parseExportSpecifiers(t), this.eatContextual("from")) this.type !== ce.string && this.unexpected(), e.source = this.parseExprAtom();
            else {
                for (var i = 0, s = e.specifiers; i < s.length; i += 1) {
                    var r = s[i];
                    this.checkUnreserved(r.local), this.checkLocalExport(r.local), "Literal" === r.local.type && this.raise(r.local.start, "A string literal cannot be used as an exported binding without `from`.")
                }
                e.source = null
            }
            this.semicolon()
        }
        return this.finishNode(e, "ExportNamedDeclaration")
    }, De.parseExportDeclaration = function(e) {
        return this.parseStatement(null)
    }, De.parseExportDefaultDeclaration = function() {
        var e;
        if (this.type === ce._function || (e = this.isAsyncFunction())) {
            var t = this.startNode();
            return this.next(), e && this.next(), this.parseFunction(t, 4 | Ue, !1, e)
        }
        if (this.type === ce._class) {
            var i = this.startNode();
            return this.parseClass(i, "nullableID")
        }
        var s = this.parseMaybeAssign();
        return this.semicolon(), s
    }, De.checkExport = function(e, t, i) {
        e && ("string" != typeof t && (t = "Identifier" === t.type ? t.name : t.value), ye(e, t) && this.raiseRecoverable(i, "Duplicate export '" + t + "'"), e[t] = !0)
    }, De.checkPatternExport = function(e, t) {
        var i = t.type;
        if ("Identifier" === i) this.checkExport(e, t, t.start);
        else if ("ObjectPattern" === i)
            for (var s = 0, r = t.properties; s < r.length; s += 1) {
                var n = r[s];
                this.checkPatternExport(e, n)
            } else if ("ArrayPattern" === i)
                for (var a = 0, o = t.elements; a < o.length; a += 1) {
                    var c = o[a];
                    c && this.checkPatternExport(e, c)
                } else "Property" === i ? this.checkPatternExport(e, t.value) : "AssignmentPattern" === i ? this.checkPatternExport(e, t.left) : "RestElement" === i ? this.checkPatternExport(e, t.argument) : "ParenthesizedExpression" === i && this.checkPatternExport(e, t.expression)
    }, De.checkVariableExport = function(e, t) {
        if (e)
            for (var i = 0, s = t; i < s.length; i += 1) {
                var r = s[i];
                this.checkPatternExport(e, r.id)
            }
    }, De.shouldParseExportStatement = function() {
        return "var" === this.type.keyword || "const" === this.type.keyword || "class" === this.type.keyword || "function" === this.type.keyword || this.isLet() || this.isAsyncFunction()
    }, De.parseExportSpecifier = function(e) {
        var t = this.startNode();
        return t.local = this.parseModuleExportName(), t.exported = this.eatContextual("as") ? this.parseModuleExportName() : t.local, this.checkExport(e, t.exported, t.exported.start), this.finishNode(t, "ExportSpecifier")
    }, De.parseExportSpecifiers = function(e) {
        var t = [],
            i = !0;
        for (this.expect(ce.braceL); !this.eat(ce.braceR);) {
            if (i) i = !1;
            else if (this.expect(ce.comma), this.afterTrailingComma(ce.braceR)) break;
            t.push(this.parseExportSpecifier(e))
        }
        return t
    }, De.parseImport = function(e) {
        return this.next(), this.type === ce.string ? (e.specifiers = Be, e.source = this.parseExprAtom()) : (e.specifiers = this.parseImportSpecifiers(), this.expectContextual("from"), e.source = this.type === ce.string ? this.parseExprAtom() : this.unexpected()), this.semicolon(), this.finishNode(e, "ImportDeclaration")
    }, De.parseImportSpecifier = function() {
        var e = this.startNode();
        return e.imported = this.parseModuleExportName(), this.eatContextual("as") ? e.local = this.parseIdent() : (this.checkUnreserved(e.imported), e.local = e.imported), this.checkLValSimple(e.local, 2), this.finishNode(e, "ImportSpecifier")
    }, De.parseImportDefaultSpecifier = function() {
        var e = this.startNode();
        return e.local = this.parseIdent(), this.checkLValSimple(e.local, 2), this.finishNode(e, "ImportDefaultSpecifier")
    }, De.parseImportNamespaceSpecifier = function() {
        var e = this.startNode();
        return this.next(), this.expectContextual("as"), e.local = this.parseIdent(), this.checkLValSimple(e.local, 2), this.finishNode(e, "ImportNamespaceSpecifier")
    }, De.parseImportSpecifiers = function() {
        var e = [],
            t = !0;
        if (this.type === ce.name && (e.push(this.parseImportDefaultSpecifier()), !this.eat(ce.comma))) return e;
        if (this.type === ce.star) return e.push(this.parseImportNamespaceSpecifier()), e;
        for (this.expect(ce.braceL); !this.eat(ce.braceR);) {
            if (t) t = !1;
            else if (this.expect(ce.comma), this.afterTrailingComma(ce.braceR)) break;
            e.push(this.parseImportSpecifier())
        }
        return e
    }, De.parseModuleExportName = function() {
        if (this.options.ecmaVersion >= 13 && this.type === ce.string) {
            var e = this.parseLiteral(this.value);
            return _e.test(e.value) && this.raise(e.start, "An export name cannot include a lone surrogate."), e
        }
        return this.parseIdent(!0)
    }, De.adaptDirectivePrologue = function(e) {
        for (var t = 0; t < e.length && this.isDirectiveCandidate(e[t]); ++t) e[t].directive = e[t].expression.raw.slice(1, -1)
    }, De.isDirectiveCandidate = function(e) {
        return this.options.ecmaVersion >= 5 && "ExpressionStatement" === e.type && "Literal" === e.expression.type && "string" == typeof e.expression.value && ('"' === this.input[e.start] || "'" === this.input[e.start])
    };
    var We = Le.prototype;
    We.toAssignable = function(e, t, i) {
        if (this.options.ecmaVersion >= 6 && e) switch (e.type) {
            case "Identifier":
                this.inAsync && "await" === e.name && this.raise(e.start, "Cannot use 'await' as identifier inside an async function");
                break;
            case "ObjectPattern":
            case "ArrayPattern":
            case "AssignmentPattern":
            case "RestElement":
                break;
            case "ObjectExpression":
                e.type = "ObjectPattern", i && this.checkPatternErrors(i, !0);
                for (var s = 0, r = e.properties; s < r.length; s += 1) {
                    var n = r[s];
                    this.toAssignable(n, t), "RestElement" === n.type && ("ArrayPattern" === n.argument.type || "ObjectPattern" === n.argument.type) && this.raise(n.argument.start, "Unexpected token")
                }
                break;
            case "Property":
                "init" !== e.kind && this.raise(e.key.start, "Object pattern can't contain getter or setter"), this.toAssignable(e.value, t);
                break;
            case "ArrayExpression":
                e.type = "ArrayPattern", i && this.checkPatternErrors(i, !0), this.toAssignableList(e.elements, t);
                break;
            case "SpreadElement":
                e.type = "RestElement", this.toAssignable(e.argument, t), "AssignmentPattern" === e.argument.type && this.raise(e.argument.start, "Rest elements cannot have a default value");
                break;
            case "AssignmentExpression":
                "=" !== e.operator && this.raise(e.left.end, "Only '=' operator can be used for specifying default value."), e.type = "AssignmentPattern", delete e.operator, this.toAssignable(e.left, t);
                break;
            case "ParenthesizedExpression":
                this.toAssignable(e.expression, t, i);
                break;
            case "ChainExpression":
                this.raiseRecoverable(e.start, "Optional chaining cannot appear in left-hand side");
                break;
            case "MemberExpression":
                if (!t) break;
            default:
                this.raise(e.start, "Assigning to rvalue")
        } else i && this.checkPatternErrors(i, !0);
        return e
    }, We.toAssignableList = function(e, t) {
        for (var i = e.length, s = 0; s < i; s++) {
            var r = e[s];
            r && this.toAssignable(r, t)
        }
        if (i) {
            var n = e[i - 1];
            6 === this.options.ecmaVersion && t && n && "RestElement" === n.type && "Identifier" !== n.argument.type && this.unexpected(n.argument.start)
        }
        return e
    }, We.parseSpread = function(e) {
        var t = this.startNode();
        return this.next(), t.argument = this.parseMaybeAssign(!1, e), this.finishNode(t, "SpreadElement")
    }, We.parseRestBinding = function() {
        var e = this.startNode();
        return this.next(), 6 === this.options.ecmaVersion && this.type !== ce.name && this.unexpected(), e.argument = this.parseBindingAtom(), this.finishNode(e, "RestElement")
    }, We.parseBindingAtom = function() {
        if (this.options.ecmaVersion >= 6) switch (this.type) {
            case ce.bracketL:
                var e = this.startNode();
                return this.next(), e.elements = this.parseBindingList(ce.bracketR, !0, !0), this.finishNode(e, "ArrayPattern");
            case ce.braceL:
                return this.parseObj(!0)
        }
        return this.parseIdent()
    }, We.parseBindingList = function(e, t, i, s) {
        for (var r = [], n = !0; !this.eat(e);)
            if (n ? n = !1 : this.expect(ce.comma), t && this.type === ce.comma) r.push(null);
            else {
                if (i && this.afterTrailingComma(e)) break;
                if (this.type === ce.ellipsis) {
                    var a = this.parseRestBinding();
                    this.parseBindingListItem(a), r.push(a), this.type === ce.comma && this.raiseRecoverable(this.start, "Comma is not permitted after the rest element"), this.expect(e);
                    break
                }
                r.push(this.parseAssignableListItem(s))
            }
        return r
    }, We.parseAssignableListItem = function(e) {
        var t = this.parseMaybeDefault(this.start, this.startLoc);
        return this.parseBindingListItem(t), t
    }, We.parseBindingListItem = function(e) {
        return e
    }, We.parseMaybeDefault = function(e, t, i) {
        if (i = i || this.parseBindingAtom(), this.options.ecmaVersion < 6 || !this.eat(ce.eq)) return i;
        var s = this.startNodeAt(e, t);
        return s.left = i, s.right = this.parseMaybeAssign(), this.finishNode(s, "AssignmentPattern")
    }, We.checkLValSimple = function(e, t, i) {
        void 0 === t && (t = 0);
        var s = 0 !== t;
        switch (e.type) {
            case "Identifier":
                this.strict && this.reservedWordsStrictBind.test(e.name) && this.raiseRecoverable(e.start, (s ? "Binding " : "Assigning to ") + e.name + " in strict mode"), s && (2 === t && "let" === e.name && this.raiseRecoverable(e.start, "let is disallowed as a lexically bound name"), i && (ye(i, e.name) && this.raiseRecoverable(e.start, "Argument name clash"), i[e.name] = !0), 5 !== t && this.declareName(e.name, t, e.start));
                break;
            case "ChainExpression":
                this.raiseRecoverable(e.start, "Optional chaining cannot appear in left-hand side");
                break;
            case "MemberExpression":
                s && this.raiseRecoverable(e.start, "Binding member expression");
                break;
            case "ParenthesizedExpression":
                return s && this.raiseRecoverable(e.start, "Binding parenthesized expression"), this.checkLValSimple(e.expression, t, i);
            default:
                this.raise(e.start, (s ? "Binding" : "Assigning to") + " rvalue")
        }
    }, We.checkLValPattern = function(e, t, i) {
        switch (void 0 === t && (t = 0), e.type) {
            case "ObjectPattern":
                for (var s = 0, r = e.properties; s < r.length; s += 1) {
                    var n = r[s];
                    this.checkLValInnerPattern(n, t, i)
                }
                break;
            case "ArrayPattern":
                for (var a = 0, o = e.elements; a < o.length; a += 1) {
                    var c = o[a];
                    c && this.checkLValInnerPattern(c, t, i)
                }
                break;
            default:
                this.checkLValSimple(e, t, i)
        }
    }, We.checkLValInnerPattern = function(e, t, i) {
        switch (void 0 === t && (t = 0), e.type) {
            case "Property":
                this.checkLValInnerPattern(e.value, t, i);
                break;
            case "AssignmentPattern":
                this.checkLValPattern(e.left, t, i);
                break;
            case "RestElement":
                this.checkLValPattern(e.argument, t, i);
                break;
            default:
                this.checkLValPattern(e, t, i)
        }
    };
    var qe = function(e, t, i, s, r) {
            this.token = e, this.isExpr = !!t, this.preserveSpace = !!i, this.override = s, this.generator = !!r
        },
        Ge = {
            b_stat: new qe("{", !1),
            b_expr: new qe("{", !0),
            b_tmpl: new qe("${", !1),
            p_stat: new qe("(", !1),
            p_expr: new qe("(", !0),
            q_tmpl: new qe("`", !0, !0, (function(e) {
                return e.tryReadTemplateToken()
            })),
            f_stat: new qe("function", !1),
            f_expr: new qe("function", !0),
            f_expr_gen: new qe("function", !0, !1, null, !0),
            f_gen: new qe("function", !1, !1, null, !0)
        },
        ze = Le.prototype;
    ze.initialContext = function() {
        return [Ge.b_stat]
    }, ze.curContext = function() {
        return this.context[this.context.length - 1]
    }, ze.braceIsBlock = function(e) {
        var t = this.curContext();
        return t === Ge.f_expr || t === Ge.f_stat || (e !== ce.colon || t !== Ge.b_stat && t !== Ge.b_expr ? e === ce._return || e === ce.name && this.exprAllowed ? he.test(this.input.slice(this.lastTokEnd, this.start)) : e === ce._else || e === ce.semi || e === ce.eof || e === ce.parenR || e === ce.arrow || (e === ce.braceL ? t === Ge.b_stat : e !== ce._var && e !== ce._const && e !== ce.name && !this.exprAllowed) : !t.isExpr)
    }, ze.inGeneratorContext = function() {
        for (var e = this.context.length - 1; e >= 1; e--) {
            var t = this.context[e];
            if ("function" === t.token) return t.generator
        }
        return !1
    }, ze.updateContext = function(e) {
        var t, i = this.type;
        i.keyword && e === ce.dot ? this.exprAllowed = !1 : (t = i.updateContext) ? t.call(this, e) : this.exprAllowed = i.beforeExpr
    }, ze.overrideContext = function(e) {
        this.curContext() !== e && (this.context[this.context.length - 1] = e)
    }, ce.parenR.updateContext = ce.braceR.updateContext = function() {
        if (1 !== this.context.length) {
            var e = this.context.pop();
            e === Ge.b_stat && "function" === this.curContext().token && (e = this.context.pop()), this.exprAllowed = !e.isExpr
        } else this.exprAllowed = !0
    }, ce.braceL.updateContext = function(e) {
        this.context.push(this.braceIsBlock(e) ? Ge.b_stat : Ge.b_expr), this.exprAllowed = !0
    }, ce.dollarBraceL.updateContext = function() {
        this.context.push(Ge.b_tmpl), this.exprAllowed = !0
    }, ce.parenL.updateContext = function(e) {
        var t = e === ce._if || e === ce._for || e === ce._with || e === ce._while;
        this.context.push(t ? Ge.p_stat : Ge.p_expr), this.exprAllowed = !0
    }, ce.incDec.updateContext = function() {}, ce._function.updateContext = ce._class.updateContext = function(e) {
        !e.beforeExpr || e === ce._else || e === ce.semi && this.curContext() !== Ge.p_stat || e === ce._return && he.test(this.input.slice(this.lastTokEnd, this.start)) || (e === ce.colon || e === ce.braceL) && this.curContext() === Ge.b_stat ? this.context.push(Ge.f_stat) : this.context.push(Ge.f_expr), this.exprAllowed = !1
    }, ce.backQuote.updateContext = function() {
        this.curContext() === Ge.q_tmpl ? this.context.pop() : this.context.push(Ge.q_tmpl), this.exprAllowed = !1
    }, ce.star.updateContext = function(e) {
        if (e === ce._function) {
            var t = this.context.length - 1;
            this.context[t] === Ge.f_expr ? this.context[t] = Ge.f_expr_gen : this.context[t] = Ge.f_gen
        }
        this.exprAllowed = !0
    }, ce.name.updateContext = function(e) {
        var t = !1;
        this.options.ecmaVersion >= 6 && e !== ce.dot && ("of" === this.value && !this.exprAllowed || "yield" === this.value && this.inGeneratorContext()) && (t = !0), this.exprAllowed = t
    };
    var Ke = Le.prototype;

    function Qe(e) {
        return "MemberExpression" === e.type && "PrivateIdentifier" === e.property.type || "ChainExpression" === e.type && Qe(e.expression)
    }
    Ke.checkPropClash = function(e, t, i) {
        if (!(this.options.ecmaVersion >= 9 && "SpreadElement" === e.type || this.options.ecmaVersion >= 6 && (e.computed || e.method || e.shorthand))) {
            var s, r = e.key;
            switch (r.type) {
                case "Identifier":
                    s = r.name;
                    break;
                case "Literal":
                    s = String(r.value);
                    break;
                default:
                    return
            }
            var n = e.kind;
            if (this.options.ecmaVersion >= 6) return void("__proto__" === s && "init" === n && (t.proto && (i ? i.doubleProto < 0 && (i.doubleProto = r.start) : this.raiseRecoverable(r.start, "Redefinition of __proto__ property")), t.proto = !0));
            var a = t[s = "$" + s];
            if (a)("init" === n ? this.strict && a.init || a.get || a.set : a.init || a[n]) && this.raiseRecoverable(r.start, "Redefinition of property");
            else a = t[s] = {
                init: !1,
                get: !1,
                set: !1
            };
            a[n] = !0
        }
    }, Ke.parseExpression = function(e, t) {
        var i = this.start,
            s = this.startLoc,
            r = this.parseMaybeAssign(e, t);
        if (this.type === ce.comma) {
            var n = this.startNodeAt(i, s);
            for (n.expressions = [r]; this.eat(ce.comma);) n.expressions.push(this.parseMaybeAssign(e, t));
            return this.finishNode(n, "SequenceExpression")
        }
        return r
    }, Ke.parseMaybeAssign = function(e, t, i) {
        if (this.isContextual("yield")) {
            if (this.inGenerator) return this.parseYield(e);
            this.exprAllowed = !1
        }
        var s = !1,
            r = -1,
            n = -1,
            a = -1;
        t ? (r = t.parenthesizedAssign, n = t.trailingComma, a = t.doubleProto, t.parenthesizedAssign = t.trailingComma = -1) : (t = new Oe, s = !0);
        var o = this.start,
            c = this.startLoc;
        (this.type === ce.parenL || this.type === ce.name) && (this.potentialArrowAt = this.start, this.potentialArrowInForAwait = "await" === e);
        var h = this.parseMaybeConditional(e, t);
        if (i && (h = i.call(this, h, o, c)), this.type.isAssign) {
            var l = this.startNodeAt(o, c);
            return l.operator = this.value, this.type === ce.eq && (h = this.toAssignable(h, !1, t)), s || (t.parenthesizedAssign = t.trailingComma = t.doubleProto = -1), t.shorthandAssign >= h.start && (t.shorthandAssign = -1), this.type === ce.eq ? this.checkLValPattern(h) : this.checkLValSimple(h), l.left = h, this.next(), l.right = this.parseMaybeAssign(e), a > -1 && (t.doubleProto = a), this.finishNode(l, "AssignmentExpression")
        }
        return s && this.checkExpressionErrors(t, !0), r > -1 && (t.parenthesizedAssign = r), n > -1 && (t.trailingComma = n), h
    }, Ke.parseMaybeConditional = function(e, t) {
        var i = this.start,
            s = this.startLoc,
            r = this.parseExprOps(e, t);
        if (this.checkExpressionErrors(t)) return r;
        if (this.eat(ce.question)) {
            var n = this.startNodeAt(i, s);
            return n.test = r, n.consequent = this.parseMaybeAssign(), this.expect(ce.colon), n.alternate = this.parseMaybeAssign(e), this.finishNode(n, "ConditionalExpression")
        }
        return r
    }, Ke.parseExprOps = function(e, t) {
        var i = this.start,
            s = this.startLoc,
            r = this.parseMaybeUnary(t, !1, !1, e);
        return this.checkExpressionErrors(t) || r.start === i && "ArrowFunctionExpression" === r.type ? r : this.parseExprOp(r, i, s, -1, e)
    }, Ke.parseExprOp = function(e, t, i, s, r) {
        var n = this.type.binop;
        if (null != n && (!r || this.type !== ce._in) && n > s) {
            var a = this.type === ce.logicalOR || this.type === ce.logicalAND,
                o = this.type === ce.coalesce;
            o && (n = ce.logicalAND.binop);
            var c = this.value;
            this.next();
            var h = this.start,
                l = this.startLoc,
                p = this.parseExprOp(this.parseMaybeUnary(null, !1, !1, r), h, l, n, r),
                u = this.buildBinary(t, i, e, p, c, a || o);
            return (a && this.type === ce.coalesce || o && (this.type === ce.logicalOR || this.type === ce.logicalAND)) && this.raiseRecoverable(this.start, "Logical expressions and coalesce expressions cannot be mixed. Wrap either by parentheses"), this.parseExprOp(u, t, i, s, r)
        }
        return e
    }, Ke.buildBinary = function(e, t, i, s, r, n) {
        "PrivateIdentifier" === s.type && this.raise(s.start, "Private identifier can only be left side of binary expression");
        var a = this.startNodeAt(e, t);
        return a.left = i, a.operator = r, a.right = s, this.finishNode(a, n ? "LogicalExpression" : "BinaryExpression")
    }, Ke.parseMaybeUnary = function(e, t, i, s) {
        var r, n = this.start,
            a = this.startLoc;
        if (this.isContextual("await") && this.canAwait) r = this.parseAwait(s), t = !0;
        else if (this.type.prefix) {
            var o = this.startNode(),
                c = this.type === ce.incDec;
            o.operator = this.value, o.prefix = !0, this.next(), o.argument = this.parseMaybeUnary(null, !0, c, s), this.checkExpressionErrors(e, !0), c ? this.checkLValSimple(o.argument) : this.strict && "delete" === o.operator && "Identifier" === o.argument.type ? this.raiseRecoverable(o.start, "Deleting local variable in strict mode") : "delete" === o.operator && Qe(o.argument) ? this.raiseRecoverable(o.start, "Private fields can not be deleted") : t = !0, r = this.finishNode(o, c ? "UpdateExpression" : "UnaryExpression")
        } else if (t || this.type !== ce.privateId) {
            if (r = this.parseExprSubscripts(e, s), this.checkExpressionErrors(e)) return r;
            for (; this.type.postfix && !this.canInsertSemicolon();) {
                var h = this.startNodeAt(n, a);
                h.operator = this.value, h.prefix = !1, h.argument = r, this.checkLValSimple(r), this.next(), r = this.finishNode(h, "UpdateExpression")
            }
        } else(s || 0 === this.privateNameStack.length) && this.options.checkPrivateFields && this.unexpected(), r = this.parsePrivateIdent(), this.type !== ce._in && this.unexpected();
        return i || !this.eat(ce.starstar) ? r : t ? void this.unexpected(this.lastTokStart) : this.buildBinary(n, a, r, this.parseMaybeUnary(null, !1, !1, s), "**", !1)
    }, Ke.parseExprSubscripts = function(e, t) {
        var i = this.start,
            s = this.startLoc,
            r = this.parseExprAtom(e, t);
        if ("ArrowFunctionExpression" === r.type && ")" !== this.input.slice(this.lastTokStart, this.lastTokEnd)) return r;
        var n = this.parseSubscripts(r, i, s, !1, t);
        return e && "MemberExpression" === n.type && (e.parenthesizedAssign >= n.start && (e.parenthesizedAssign = -1), e.parenthesizedBind >= n.start && (e.parenthesizedBind = -1), e.trailingComma >= n.start && (e.trailingComma = -1)), n
    }, Ke.parseSubscripts = function(e, t, i, s, r) {
        for (var n = this.options.ecmaVersion >= 8 && "Identifier" === e.type && "async" === e.name && this.lastTokEnd === e.end && !this.canInsertSemicolon() && e.end - e.start == 5 && this.potentialArrowAt === e.start, a = !1;;) {
            var o = this.parseSubscript(e, t, i, s, n, a, r);
            if (o.optional && (a = !0), o === e || "ArrowFunctionExpression" === o.type) {
                if (a) {
                    var c = this.startNodeAt(t, i);
                    c.expression = o, o = this.finishNode(c, "ChainExpression")
                }
                return o
            }
            e = o
        }
    }, Ke.shouldParseAsyncArrow = function() {
        return !this.canInsertSemicolon() && this.eat(ce.arrow)
    }, Ke.parseSubscriptAsyncArrow = function(e, t, i, s) {
        return this.parseArrowExpression(this.startNodeAt(e, t), i, !0, s)
    }, Ke.parseSubscript = function(e, t, i, s, r, n, a) {
        var o = this.options.ecmaVersion >= 11,
            c = o && this.eat(ce.questionDot);
        s && c && this.raise(this.lastTokStart, "Optional chaining cannot appear in the callee of new expressions");
        var h = this.eat(ce.bracketL);
        if (h || c && this.type !== ce.parenL && this.type !== ce.backQuote || this.eat(ce.dot)) {
            var l = this.startNodeAt(t, i);
            l.object = e, h ? (l.property = this.parseExpression(), this.expect(ce.bracketR)) : this.type === ce.privateId && "Super" !== e.type ? l.property = this.parsePrivateIdent() : l.property = this.parseIdent("never" !== this.options.allowReserved), l.computed = !!h, o && (l.optional = c), e = this.finishNode(l, "MemberExpression")
        } else if (!s && this.eat(ce.parenL)) {
            var p = new Oe,
                u = this.yieldPos,
                d = this.awaitPos,
                f = this.awaitIdentPos;
            this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0;
            var m = this.parseExprList(ce.parenR, this.options.ecmaVersion >= 8, !1, p);
            if (r && !c && this.shouldParseAsyncArrow()) return this.checkPatternErrors(p, !1), this.checkYieldAwaitInDefaultParams(), this.awaitIdentPos > 0 && this.raise(this.awaitIdentPos, "Cannot use 'await' as identifier inside an async function"), this.yieldPos = u, this.awaitPos = d, this.awaitIdentPos = f, this.parseSubscriptAsyncArrow(t, i, m, a);
            this.checkExpressionErrors(p, !0), this.yieldPos = u || this.yieldPos, this.awaitPos = d || this.awaitPos, this.awaitIdentPos = f || this.awaitIdentPos;
            var g = this.startNodeAt(t, i);
            g.callee = e, g.arguments = m, o && (g.optional = c), e = this.finishNode(g, "CallExpression")
        } else if (this.type === ce.backQuote) {
            (c || n) && this.raise(this.start, "Optional chaining cannot appear in the tag of tagged template expressions");
            var x = this.startNodeAt(t, i);
            x.tag = e, x.quasi = this.parseTemplate({
                isTagged: !0
            }), e = this.finishNode(x, "TaggedTemplateExpression")
        }
        return e
    }, Ke.parseExprAtom = function(e, t, i) {
        this.type === ce.slash && this.readRegexp();
        var s, r = this.potentialArrowAt === this.start;
        switch (this.type) {
            case ce._super:
                return this.allowSuper || this.raise(this.start, "'super' keyword outside a method"), s = this.startNode(), this.next(), this.type === ce.parenL && !this.allowDirectSuper && this.raise(s.start, "super() call outside constructor of a subclass"), this.type !== ce.dot && this.type !== ce.bracketL && this.type !== ce.parenL && this.unexpected(), this.finishNode(s, "Super");
            case ce._this:
                return s = this.startNode(), this.next(), this.finishNode(s, "ThisExpression");
            case ce.name:
                var n = this.start,
                    a = this.startLoc,
                    o = this.containsEsc,
                    c = this.parseIdent(!1);
                if (this.options.ecmaVersion >= 8 && !o && "async" === c.name && !this.canInsertSemicolon() && this.eat(ce._function)) return this.overrideContext(Ge.f_expr), this.parseFunction(this.startNodeAt(n, a), 0, !1, !0, t);
                if (r && !this.canInsertSemicolon()) {
                    if (this.eat(ce.arrow)) return this.parseArrowExpression(this.startNodeAt(n, a), [c], !1, t);
                    if (this.options.ecmaVersion >= 8 && "async" === c.name && this.type === ce.name && !o && (!this.potentialArrowInForAwait || "of" !== this.value || this.containsEsc)) return c = this.parseIdent(!1), (this.canInsertSemicolon() || !this.eat(ce.arrow)) && this.unexpected(), this.parseArrowExpression(this.startNodeAt(n, a), [c], !0, t)
                }
                return c;
            case ce.regexp:
                var h = this.value;
                return (s = this.parseLiteral(h.value)).regex = {
                    pattern: h.pattern,
                    flags: h.flags
                }, s;
            case ce.num:
            case ce.string:
                return this.parseLiteral(this.value);
            case ce._null:
            case ce._true:
            case ce._false:
                return (s = this.startNode()).value = this.type === ce._null ? null : this.type === ce._true, s.raw = this.type.keyword, this.next(), this.finishNode(s, "Literal");
            case ce.parenL:
                var l = this.start,
                    p = this.parseParenAndDistinguishExpression(r, t);
                return e && (e.parenthesizedAssign < 0 && !this.isSimpleAssignTarget(p) && (e.parenthesizedAssign = l), e.parenthesizedBind < 0 && (e.parenthesizedBind = l)), p;
            case ce.bracketL:
                return s = this.startNode(), this.next(), s.elements = this.parseExprList(ce.bracketR, !0, !0, e), this.finishNode(s, "ArrayExpression");
            case ce.braceL:
                return this.overrideContext(Ge.b_expr), this.parseObj(!1, e);
            case ce._function:
                return s = this.startNode(), this.next(), this.parseFunction(s, 0);
            case ce._class:
                return this.parseClass(this.startNode(), !1);
            case ce._new:
                return this.parseNew();
            case ce.backQuote:
                return this.parseTemplate();
            case ce._import:
                return this.options.ecmaVersion >= 11 ? this.parseExprImport(i) : this.unexpected();
            default:
                return this.parseExprAtomDefault()
        }
    }, Ke.parseExprAtomDefault = function() {
        this.unexpected()
    }, Ke.parseExprImport = function(e) {
        var t = this.startNode();
        this.containsEsc && this.raiseRecoverable(this.start, "Escape sequence in keyword import");
        var i = this.parseIdent(!0);
        return this.type !== ce.parenL || e ? this.type === ce.dot ? (t.meta = i, this.parseImportMeta(t)) : void this.unexpected() : this.parseDynamicImport(t)
    }, Ke.parseDynamicImport = function(e) {
        if (this.next(), e.source = this.parseMaybeAssign(), !this.eat(ce.parenR)) {
            var t = this.start;
            this.eat(ce.comma) && this.eat(ce.parenR) ? this.raiseRecoverable(t, "Trailing comma is not allowed in import()") : this.unexpected(t)
        }
        return this.finishNode(e, "ImportExpression")
    }, Ke.parseImportMeta = function(e) {
        this.next();
        var t = this.containsEsc;
        return e.property = this.parseIdent(!0), "meta" !== e.property.name && this.raiseRecoverable(e.property.start, "The only valid meta property for import is 'import.meta'"), t && this.raiseRecoverable(e.start, "'import.meta' must not contain escaped characters"), "module" !== this.options.sourceType && !this.options.allowImportExportEverywhere && this.raiseRecoverable(e.start, "Cannot use 'import.meta' outside a module"), this.finishNode(e, "MetaProperty")
    }, Ke.parseLiteral = function(e) {
        var t = this.startNode();
        return t.value = e, t.raw = this.input.slice(this.start, this.end), 110 === t.raw.charCodeAt(t.raw.length - 1) && (t.bigint = t.raw.slice(0, -1).replace(/_/g, "")), this.next(), this.finishNode(t, "Literal")
    }, Ke.parseParenExpression = function() {
        this.expect(ce.parenL);
        var e = this.parseExpression();
        return this.expect(ce.parenR), e
    }, Ke.shouldParseArrow = function(e) {
        return !this.canInsertSemicolon()
    }, Ke.parseParenAndDistinguishExpression = function(e, t) {
        var i, s = this.start,
            r = this.startLoc,
            n = this.options.ecmaVersion >= 8;
        if (this.options.ecmaVersion >= 6) {
            this.next();
            var a, o = this.start,
                c = this.startLoc,
                h = [],
                l = !0,
                p = !1,
                u = new Oe,
                d = this.yieldPos,
                f = this.awaitPos;
            for (this.yieldPos = 0, this.awaitPos = 0; this.type !== ce.parenR;) {
                if (l ? l = !1 : this.expect(ce.comma), n && this.afterTrailingComma(ce.parenR, !0)) {
                    p = !0;
                    break
                }
                if (this.type === ce.ellipsis) {
                    a = this.start, h.push(this.parseParenItem(this.parseRestBinding())), this.type === ce.comma && this.raiseRecoverable(this.start, "Comma is not permitted after the rest element");
                    break
                }
                h.push(this.parseMaybeAssign(!1, u, this.parseParenItem))
            }
            var m = this.lastTokEnd,
                g = this.lastTokEndLoc;
            if (this.expect(ce.parenR), e && this.shouldParseArrow(h) && this.eat(ce.arrow)) return this.checkPatternErrors(u, !1), this.checkYieldAwaitInDefaultParams(), this.yieldPos = d, this.awaitPos = f, this.parseParenArrowList(s, r, h, t);
            (!h.length || p) && this.unexpected(this.lastTokStart), a && this.unexpected(a), this.checkExpressionErrors(u, !0), this.yieldPos = d || this.yieldPos, this.awaitPos = f || this.awaitPos, h.length > 1 ? ((i = this.startNodeAt(o, c)).expressions = h, this.finishNodeAt(i, "SequenceExpression", m, g)) : i = h[0]
        } else i = this.parseParenExpression();
        if (this.options.preserveParens) {
            var x = this.startNodeAt(s, r);
            return x.expression = i, this.finishNode(x, "ParenthesizedExpression")
        }
        return i
    }, Ke.parseParenItem = function(e) {
        return e
    }, Ke.parseParenArrowList = function(e, t, i, s) {
        return this.parseArrowExpression(this.startNodeAt(e, t), i, !1, s)
    };
    var Ye = [];
    Ke.parseNew = function() {
        this.containsEsc && this.raiseRecoverable(this.start, "Escape sequence in keyword new");
        var e = this.startNode(),
            t = this.parseIdent(!0);
        if (this.options.ecmaVersion >= 6 && this.eat(ce.dot)) {
            e.meta = t;
            var i = this.containsEsc;
            return e.property = this.parseIdent(!0), "target" !== e.property.name && this.raiseRecoverable(e.property.start, "The only valid meta property for new is 'new.target'"), i && this.raiseRecoverable(e.start, "'new.target' must not contain escaped characters"), this.allowNewDotTarget || this.raiseRecoverable(e.start, "'new.target' can only be used in functions and class static block"), this.finishNode(e, "MetaProperty")
        }
        var s = this.start,
            r = this.startLoc;
        return e.callee = this.parseSubscripts(this.parseExprAtom(null, !1, !0), s, r, !0, !1), this.eat(ce.parenL) ? e.arguments = this.parseExprList(ce.parenR, this.options.ecmaVersion >= 8, !1) : e.arguments = Ye, this.finishNode(e, "NewExpression")
    }, Ke.parseTemplateElement = function(e) {
        var t = e.isTagged,
            i = this.startNode();
        return this.type === ce.invalidTemplate ? (t || this.raiseRecoverable(this.start, "Bad escape sequence in untagged template literal"), i.value = {
            raw: this.value,
            cooked: null
        }) : i.value = {
            raw: this.input.slice(this.start, this.end).replace(/\r\n?/g, "\n"),
            cooked: this.value
        }, this.next(), i.tail = this.type === ce.backQuote, this.finishNode(i, "TemplateElement")
    }, Ke.parseTemplate = function(e) {
        void 0 === e && (e = {});
        var t = e.isTagged;
        void 0 === t && (t = !1);
        var i = this.startNode();
        this.next(), i.expressions = [];
        var s = this.parseTemplateElement({
            isTagged: t
        });
        for (i.quasis = [s]; !s.tail;) this.type === ce.eof && this.raise(this.pos, "Unterminated template literal"), this.expect(ce.dollarBraceL), i.expressions.push(this.parseExpression()), this.expect(ce.braceR), i.quasis.push(s = this.parseTemplateElement({
            isTagged: t
        }));
        return this.next(), this.finishNode(i, "TemplateLiteral")
    }, Ke.isAsyncProp = function(e) {
        return !e.computed && "Identifier" === e.key.type && "async" === e.key.name && (this.type === ce.name || this.type === ce.num || this.type === ce.string || this.type === ce.bracketL || this.type.keyword || this.options.ecmaVersion >= 9 && this.type === ce.star) && !he.test(this.input.slice(this.lastTokEnd, this.start))
    }, Ke.parseObj = function(e, t) {
        var i = this.startNode(),
            s = !0,
            r = {};
        for (i.properties = [], this.next(); !this.eat(ce.braceR);) {
            if (s) s = !1;
            else if (this.expect(ce.comma), this.options.ecmaVersion >= 5 && this.afterTrailingComma(ce.braceR)) break;
            var n = this.parseProperty(e, t);
            e || this.checkPropClash(n, r, t), i.properties.push(n)
        }
        return this.finishNode(i, e ? "ObjectPattern" : "ObjectExpression")
    }, Ke.parseProperty = function(e, t) {
        var i, s, r, n, a = this.startNode();
        if (this.options.ecmaVersion >= 9 && this.eat(ce.ellipsis)) return e ? (a.argument = this.parseIdent(!1), this.type === ce.comma && this.raiseRecoverable(this.start, "Comma is not permitted after the rest element"), this.finishNode(a, "RestElement")) : (a.argument = this.parseMaybeAssign(!1, t), this.type === ce.comma && t && t.trailingComma < 0 && (t.trailingComma = this.start), this.finishNode(a, "SpreadElement"));
        this.options.ecmaVersion >= 6 && (a.method = !1, a.shorthand = !1, (e || t) && (r = this.start, n = this.startLoc), e || (i = this.eat(ce.star)));
        var o = this.containsEsc;
        return this.parsePropertyName(a), !e && !o && this.options.ecmaVersion >= 8 && !i && this.isAsyncProp(a) ? (s = !0, i = this.options.ecmaVersion >= 9 && this.eat(ce.star), this.parsePropertyName(a)) : s = !1, this.parsePropertyValue(a, e, i, s, r, n, t, o), this.finishNode(a, "Property")
    }, Ke.parseGetterSetter = function(e) {
        e.kind = e.key.name, this.parsePropertyName(e), e.value = this.parseMethod(!1);
        var t = "get" === e.kind ? 0 : 1;
        if (e.value.params.length !== t) {
            var i = e.value.start;
            "get" === e.kind ? this.raiseRecoverable(i, "getter should have no params") : this.raiseRecoverable(i, "setter should have exactly one param")
        } else "set" === e.kind && "RestElement" === e.value.params[0].type && this.raiseRecoverable(e.value.params[0].start, "Setter cannot use rest params")
    }, Ke.parsePropertyValue = function(e, t, i, s, r, n, a, o) {
        (i || s) && this.type === ce.colon && this.unexpected(), this.eat(ce.colon) ? (e.value = t ? this.parseMaybeDefault(this.start, this.startLoc) : this.parseMaybeAssign(!1, a), e.kind = "init") : this.options.ecmaVersion >= 6 && this.type === ce.parenL ? (t && this.unexpected(), e.kind = "init", e.method = !0, e.value = this.parseMethod(i, s)) : t || o || !(this.options.ecmaVersion >= 5) || e.computed || "Identifier" !== e.key.type || "get" !== e.key.name && "set" !== e.key.name || this.type === ce.comma || this.type === ce.braceR || this.type === ce.eq ? this.options.ecmaVersion >= 6 && !e.computed && "Identifier" === e.key.type ? ((i || s) && this.unexpected(), this.checkUnreserved(e.key), "await" === e.key.name && !this.awaitIdentPos && (this.awaitIdentPos = r), e.kind = "init", t ? e.value = this.parseMaybeDefault(r, n, this.copyNode(e.key)) : this.type === ce.eq && a ? (a.shorthandAssign < 0 && (a.shorthandAssign = this.start), e.value = this.parseMaybeDefault(r, n, this.copyNode(e.key))) : e.value = this.copyNode(e.key), e.shorthand = !0) : this.unexpected() : ((i || s) && this.unexpected(), this.parseGetterSetter(e))
    }, Ke.parsePropertyName = function(e) {
        if (this.options.ecmaVersion >= 6) {
            if (this.eat(ce.bracketL)) return e.computed = !0, e.key = this.parseMaybeAssign(), this.expect(ce.bracketR), e.key;
            e.computed = !1
        }
        return e.key = this.type === ce.num || this.type === ce.string ? this.parseExprAtom() : this.parseIdent("never" !== this.options.allowReserved)
    }, Ke.initFunction = function(e) {
        e.id = null, this.options.ecmaVersion >= 6 && (e.generator = e.expression = !1), this.options.ecmaVersion >= 8 && (e.async = !1)
    }, Ke.parseMethod = function(e, t, i) {
        var s = this.startNode(),
            r = this.yieldPos,
            n = this.awaitPos,
            a = this.awaitIdentPos;
        return this.initFunction(s), this.options.ecmaVersion >= 6 && (s.generator = e), this.options.ecmaVersion >= 8 && (s.async = !!t), this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0, this.enterScope(64 | Ne(t, s.generator) | (i ? 128 : 0)), this.expect(ce.parenL), s.params = this.parseBindingList(ce.parenR, !1, this.options.ecmaVersion >= 8), this.checkYieldAwaitInDefaultParams(), this.parseFunctionBody(s, !1, !0, !1), this.yieldPos = r, this.awaitPos = n, this.awaitIdentPos = a, this.finishNode(s, "FunctionExpression")
    }, Ke.parseArrowExpression = function(e, t, i, s) {
        var r = this.yieldPos,
            n = this.awaitPos,
            a = this.awaitIdentPos;
        return this.enterScope(16 | Ne(i, !1)), this.initFunction(e), this.options.ecmaVersion >= 8 && (e.async = !!i), this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0, e.params = this.toAssignableList(t, !0), this.parseFunctionBody(e, !0, !1, s), this.yieldPos = r, this.awaitPos = n, this.awaitIdentPos = a, this.finishNode(e, "ArrowFunctionExpression")
    }, Ke.parseFunctionBody = function(e, t, i, s) {
        var r = t && this.type !== ce.braceL,
            n = this.strict,
            a = !1;
        if (r) e.body = this.parseMaybeAssign(s), e.expression = !0, this.checkParams(e, !1);
        else {
            var o = this.options.ecmaVersion >= 7 && !this.isSimpleParamList(e.params);
            (!n || o) && ((a = this.strictDirective(this.end)) && o && this.raiseRecoverable(e.start, "Illegal 'use strict' directive in function with non-simple parameter list"));
            var c = this.labels;
            this.labels = [], a && (this.strict = !0), this.checkParams(e, !n && !a && !t && !i && this.isSimpleParamList(e.params)), this.strict && e.id && this.checkLValSimple(e.id, 5), e.body = this.parseBlock(!1, void 0, a && !n), e.expression = !1, this.adaptDirectivePrologue(e.body.body), this.labels = c
        }
        this.exitScope()
    }, Ke.isSimpleParamList = function(e) {
        for (var t = 0, i = e; t < i.length; t += 1) {
            if ("Identifier" !== i[t].type) return !1
        }
        return !0
    }, Ke.checkParams = function(e, t) {
        for (var i = Object.create(null), s = 0, r = e.params; s < r.length; s += 1) {
            var n = r[s];
            this.checkLValInnerPattern(n, 1, t ? null : i)
        }
    }, Ke.parseExprList = function(e, t, i, s) {
        for (var r = [], n = !0; !this.eat(e);) {
            if (n) n = !1;
            else if (this.expect(ce.comma), t && this.afterTrailingComma(e)) break;
            var a = void 0;
            i && this.type === ce.comma ? a = null : this.type === ce.ellipsis ? (a = this.parseSpread(s), s && this.type === ce.comma && s.trailingComma < 0 && (s.trailingComma = this.start)) : a = this.parseMaybeAssign(!1, s), r.push(a)
        }
        return r
    }, Ke.checkUnreserved = function(e) {
        var t = e.start,
            i = e.end,
            s = e.name;
        (this.inGenerator && "yield" === s && this.raiseRecoverable(t, "Cannot use 'yield' as identifier inside a generator"), this.inAsync && "await" === s && this.raiseRecoverable(t, "Cannot use 'await' as identifier inside an async function"), this.currentThisScope().inClassFieldInit && "arguments" === s && this.raiseRecoverable(t, "Cannot use 'arguments' in class field initializer"), this.inClassStaticBlock && ("arguments" === s || "await" === s) && this.raise(t, "Cannot use " + s + " in class static initialization block"), this.keywords.test(s) && this.raise(t, "Unexpected keyword '" + s + "'"), this.options.ecmaVersion < 6 && -1 !== this.input.slice(t, i).indexOf("\\")) || (this.strict ? this.reservedWordsStrict : this.reservedWords).test(s) && (!this.inAsync && "await" === s && this.raiseRecoverable(t, "Cannot use keyword 'await' outside an async function"), this.raiseRecoverable(t, "The keyword '" + s + "' is reserved"))
    }, Ke.parseIdent = function(e) {
        var t = this.parseIdentNode();
        return this.next(!!e), this.finishNode(t, "Identifier"), e || (this.checkUnreserved(t), "await" === t.name && !this.awaitIdentPos && (this.awaitIdentPos = t.start)), t
    }, Ke.parseIdentNode = function() {
        var e = this.startNode();
        return this.type === ce.name ? e.name = this.value : this.type.keyword ? (e.name = this.type.keyword, ("class" === e.name || "function" === e.name) && (this.lastTokEnd !== this.lastTokStart + 1 || 46 !== this.input.charCodeAt(this.lastTokStart)) && this.context.pop()) : this.unexpected(), e
    }, Ke.parsePrivateIdent = function() {
        var e = this.startNode();
        return this.type === ce.privateId ? e.name = this.value : this.unexpected(), this.next(), this.finishNode(e, "PrivateIdentifier"), this.options.checkPrivateFields && (0 === this.privateNameStack.length ? this.raise(e.start, "Private field '#" + e.name + "' must be declared in an enclosing class") : this.privateNameStack[this.privateNameStack.length - 1].used.push(e)), e
    }, Ke.parseYield = function(e) {
        this.yieldPos || (this.yieldPos = this.start);
        var t = this.startNode();
        return this.next(), this.type === ce.semi || this.canInsertSemicolon() || this.type !== ce.star && !this.type.startsExpr ? (t.delegate = !1, t.argument = null) : (t.delegate = this.eat(ce.star), t.argument = this.parseMaybeAssign(e)), this.finishNode(t, "YieldExpression")
    }, Ke.parseAwait = function(e) {
        this.awaitPos || (this.awaitPos = this.start);
        var t = this.startNode();
        return this.next(), t.argument = this.parseMaybeUnary(null, !0, !1, e), this.finishNode(t, "AwaitExpression")
    };
    var Je = Le.prototype;
    Je.raise = function(e, t) {
        var i = Ee(this.input, e);
        t += " (" + i.line + ":" + i.column + ")";
        var s = new SyntaxError(t);
        throw s.pos = e, s.loc = i, s.raisedAt = this.pos, s
    }, Je.raiseRecoverable = Je.raise, Je.curPosition = function() {
        if (this.options.locations) return new ke(this.curLine, this.pos - this.lineStart)
    };
    var Ze = Le.prototype,
        Xe = function(e) {
            this.flags = e, this.var = [], this.lexical = [], this.functions = [], this.inClassFieldInit = !1
        };
    Ze.enterScope = function(e) {
        this.scopeStack.push(new Xe(e))
    }, Ze.exitScope = function() {
        this.scopeStack.pop()
    }, Ze.treatFunctionsAsVarInScope = function(e) {
        return 2 & e.flags || !this.inModule && 1 & e.flags
    }, Ze.declareName = function(e, t, i) {
        var s = !1;
        if (2 === t) {
            var r = this.currentScope();
            s = r.lexical.indexOf(e) > -1 || r.functions.indexOf(e) > -1 || r.var.indexOf(e) > -1, r.lexical.push(e), this.inModule && 1 & r.flags && delete this.undefinedExports[e]
        } else if (4 === t) {
            this.currentScope().lexical.push(e)
        } else if (3 === t) {
            var n = this.currentScope();
            s = this.treatFunctionsAsVar ? n.lexical.indexOf(e) > -1 : n.lexical.indexOf(e) > -1 || n.var.indexOf(e) > -1, n.functions.push(e)
        } else
            for (var a = this.scopeStack.length - 1; a >= 0; --a) {
                var o = this.scopeStack[a];
                if (o.lexical.indexOf(e) > -1 && !(32 & o.flags && o.lexical[0] === e) || !this.treatFunctionsAsVarInScope(o) && o.functions.indexOf(e) > -1) {
                    s = !0;
                    break
                }
                if (o.var.push(e), this.inModule && 1 & o.flags && delete this.undefinedExports[e], 259 & o.flags) break
            }
        s && this.raiseRecoverable(i, "Identifier '" + e + "' has already been declared")
    }, Ze.checkLocalExport = function(e) {
        -1 === this.scopeStack[0].lexical.indexOf(e.name) && -1 === this.scopeStack[0].var.indexOf(e.name) && (this.undefinedExports[e.name] = e)
    }, Ze.currentScope = function() {
        return this.scopeStack[this.scopeStack.length - 1]
    }, Ze.currentVarScope = function() {
        for (var e = this.scopeStack.length - 1;; e--) {
            var t = this.scopeStack[e];
            if (259 & t.flags) return t
        }
    }, Ze.currentThisScope = function() {
        for (var e = this.scopeStack.length - 1;; e--) {
            var t = this.scopeStack[e];
            if (259 & t.flags && !(16 & t.flags)) return t
        }
    };
    var et = function(e, t, i) {
            this.type = "", this.start = t, this.end = 0, e.options.locations && (this.loc = new Ce(e, i)), e.options.directSourceFile && (this.sourceFile = e.options.directSourceFile), e.options.ranges && (this.range = [t, 0])
        },
        tt = Le.prototype;

    function it(e, t, i, s) {
        return e.type = t, e.end = i, this.options.locations && (e.loc.end = s), this.options.ranges && (e.range[1] = i), e
    }
    tt.startNode = function() {
        return new et(this, this.start, this.startLoc)
    }, tt.startNodeAt = function(e, t) {
        return new et(this, e, t)
    }, tt.finishNode = function(e, t) {
        return it.call(this, e, t, this.lastTokEnd, this.lastTokEndLoc)
    }, tt.finishNodeAt = function(e, t, i, s) {
        return it.call(this, e, t, i, s)
    }, tt.copyNode = function(e) {
        var t = new et(this, e.start, this.startLoc);
        for (var i in e) t[i] = e[i];
        return t
    };
    var st = "ASCII ASCII_Hex_Digit AHex Alphabetic Alpha Any Assigned Bidi_Control Bidi_C Bidi_Mirrored Bidi_M Case_Ignorable CI Cased Changes_When_Casefolded CWCF Changes_When_Casemapped CWCM Changes_When_Lowercased CWL Changes_When_NFKC_Casefolded CWKCF Changes_When_Titlecased CWT Changes_When_Uppercased CWU Dash Default_Ignorable_Code_Point DI Deprecated Dep Diacritic Dia Emoji Emoji_Component Emoji_Modifier Emoji_Modifier_Base Emoji_Presentation Extender Ext Grapheme_Base Gr_Base Grapheme_Extend Gr_Ext Hex_Digit Hex IDS_Binary_Operator IDSB IDS_Trinary_Operator IDST ID_Continue IDC ID_Start IDS Ideographic Ideo Join_Control Join_C Logical_Order_Exception LOE Lowercase Lower Math Noncharacter_Code_Point NChar Pattern_Syntax Pat_Syn Pattern_White_Space Pat_WS Quotation_Mark QMark Radical Regional_Indicator RI Sentence_Terminal STerm Soft_Dotted SD Terminal_Punctuation Term Unified_Ideograph UIdeo Uppercase Upper Variation_Selector VS White_Space space XID_Continue XIDC XID_Start XIDS",
        rt = st + " Extended_Pictographic",
        nt = rt + " EBase EComp EMod EPres ExtPict",
        at = {
            9: st,
            10: rt,
            11: rt,
            12: nt,
            13: nt,
            14: nt
        },
        ot = {
            9: "",
            10: "",
            11: "",
            12: "",
            13: "",
            14: "Basic_Emoji Emoji_Keycap_Sequence RGI_Emoji_Modifier_Sequence RGI_Emoji_Flag_Sequence RGI_Emoji_Tag_Sequence RGI_Emoji_ZWJ_Sequence RGI_Emoji"
        },
        ct = "Cased_Letter LC Close_Punctuation Pe Connector_Punctuation Pc Control Cc cntrl Currency_Symbol Sc Dash_Punctuation Pd Decimal_Number Nd digit Enclosing_Mark Me Final_Punctuation Pf Format Cf Initial_Punctuation Pi Letter L Letter_Number Nl Line_Separator Zl Lowercase_Letter Ll Mark M Combining_Mark Math_Symbol Sm Modifier_Letter Lm Modifier_Symbol Sk Nonspacing_Mark Mn Number N Open_Punctuation Ps Other C Other_Letter Lo Other_Number No Other_Punctuation Po Other_Symbol So Paragraph_Separator Zp Private_Use Co Punctuation P punct Separator Z Space_Separator Zs Spacing_Mark Mc Surrogate Cs Symbol S Titlecase_Letter Lt Unassigned Cn Uppercase_Letter Lu",
        ht = "Adlam Adlm Ahom Anatolian_Hieroglyphs Hluw Arabic Arab Armenian Armn Avestan Avst Balinese Bali Bamum Bamu Bassa_Vah Bass Batak Batk Bengali Beng Bhaiksuki Bhks Bopomofo Bopo Brahmi Brah Braille Brai Buginese Bugi Buhid Buhd Canadian_Aboriginal Cans Carian Cari Caucasian_Albanian Aghb Chakma Cakm Cham Cham Cherokee Cher Common Zyyy Coptic Copt Qaac Cuneiform Xsux Cypriot Cprt Cyrillic Cyrl Deseret Dsrt Devanagari Deva Duployan Dupl Egyptian_Hieroglyphs Egyp Elbasan Elba Ethiopic Ethi Georgian Geor Glagolitic Glag Gothic Goth Grantha Gran Greek Grek Gujarati Gujr Gurmukhi Guru Han Hani Hangul Hang Hanunoo Hano Hatran Hatr Hebrew Hebr Hiragana Hira Imperial_Aramaic Armi Inherited Zinh Qaai Inscriptional_Pahlavi Phli Inscriptional_Parthian Prti Javanese Java Kaithi Kthi Kannada Knda Katakana Kana Kayah_Li Kali Kharoshthi Khar Khmer Khmr Khojki Khoj Khudawadi Sind Lao Laoo Latin Latn Lepcha Lepc Limbu Limb Linear_A Lina Linear_B Linb Lisu Lisu Lycian Lyci Lydian Lydi Mahajani Mahj Malayalam Mlym Mandaic Mand Manichaean Mani Marchen Marc Masaram_Gondi Gonm Meetei_Mayek Mtei Mende_Kikakui Mend Meroitic_Cursive Merc Meroitic_Hieroglyphs Mero Miao Plrd Modi Mongolian Mong Mro Mroo Multani Mult Myanmar Mymr Nabataean Nbat New_Tai_Lue Talu Newa Newa Nko Nkoo Nushu Nshu Ogham Ogam Ol_Chiki Olck Old_Hungarian Hung Old_Italic Ital Old_North_Arabian Narb Old_Permic Perm Old_Persian Xpeo Old_South_Arabian Sarb Old_Turkic Orkh Oriya Orya Osage Osge Osmanya Osma Pahawh_Hmong Hmng Palmyrene Palm Pau_Cin_Hau Pauc Phags_Pa Phag Phoenician Phnx Psalter_Pahlavi Phlp Rejang Rjng Runic Runr Samaritan Samr Saurashtra Saur Sharada Shrd Shavian Shaw Siddham Sidd SignWriting Sgnw Sinhala Sinh Sora_Sompeng Sora Soyombo Soyo Sundanese Sund Syloti_Nagri Sylo Syriac Syrc Tagalog Tglg Tagbanwa Tagb Tai_Le Tale Tai_Tham Lana Tai_Viet Tavt Takri Takr Tamil Taml Tangut Tang Telugu Telu Thaana Thaa Thai Thai Tibetan Tibt Tifinagh Tfng Tirhuta Tirh Ugaritic Ugar Vai Vaii Warang_Citi Wara Yi Yiii Zanabazar_Square Zanb",
        lt = ht + " Dogra Dogr Gunjala_Gondi Gong Hanifi_Rohingya Rohg Makasar Maka Medefaidrin Medf Old_Sogdian Sogo Sogdian Sogd",
        pt = lt + " Elymaic Elym Nandinagari Nand Nyiakeng_Puachue_Hmong Hmnp Wancho Wcho",
        ut = pt + " Chorasmian Chrs Diak Dives_Akuru Khitan_Small_Script Kits Yezi Yezidi",
        dt = ut + " Cypro_Minoan Cpmn Old_Uyghur Ougr Tangsa Tnsa Toto Vithkuqi Vith",
        ft = {
            9: ht,
            10: lt,
            11: pt,
            12: ut,
            13: dt,
            14: dt + " Hrkt Katakana_Or_Hiragana Kawi Nag_Mundari Nagm Unknown Zzzz"
        },
        mt = {};

    function gt(e) {
        var t = mt[e] = {
            binary: we(at[e] + " " + ct),
            binaryOfStrings: we(ot[e]),
            nonBinary: {
                General_Category: we(ct),
                Script: we(ft[e])
            }
        };
        t.nonBinary.Script_Extensions = t.nonBinary.Script, t.nonBinary.gc = t.nonBinary.General_Category, t.nonBinary.sc = t.nonBinary.Script, t.nonBinary.scx = t.nonBinary.Script_Extensions
    }
    for (xt = 0, yt = [9, 10, 11, 12, 13, 14]; xt < yt.length; xt += 1) gt(yt[xt]);
    var xt, yt, vt = Le.prototype,
        wt = function(e) {
            this.parser = e, this.validFlags = "gim" + (e.options.ecmaVersion >= 6 ? "uy" : "") + (e.options.ecmaVersion >= 9 ? "s" : "") + (e.options.ecmaVersion >= 13 ? "d" : "") + (e.options.ecmaVersion >= 15 ? "v" : ""), this.unicodeProperties = mt[e.options.ecmaVersion >= 14 ? 14 : e.options.ecmaVersion], this.source = "", this.flags = "", this.start = 0, this.switchU = !1, this.switchV = !1, this.switchN = !1, this.pos = 0, this.lastIntValue = 0, this.lastStringValue = "", this.lastAssertionIsQuantifiable = !1, this.numCapturingParens = 0, this.maxBackReference = 0, this.groupNames = [], this.backReferenceNames = []
        };

    function bt(e) {
        return 36 === e || e >= 40 && e <= 43 || 46 === e || 63 === e || e >= 91 && e <= 94 || e >= 123 && e <= 125
    }

    function _t(e) {
        return e >= 65 && e <= 90 || e >= 97 && e <= 122
    }
    wt.prototype.reset = function(e, t, i) {
        var s = -1 !== i.indexOf("v"),
            r = -1 !== i.indexOf("u");
        this.start = 0 | e, this.source = t + "", this.flags = i, s && this.parser.options.ecmaVersion >= 15 ? (this.switchU = !0, this.switchV = !0, this.switchN = !0) : (this.switchU = r && this.parser.options.ecmaVersion >= 6, this.switchV = !1, this.switchN = r && this.parser.options.ecmaVersion >= 9)
    }, wt.prototype.raise = function(e) {
        this.parser.raiseRecoverable(this.start, "Invalid regular expression: /" + this.source + "/: " + e)
    }, wt.prototype.at = function(e, t) {
        void 0 === t && (t = !1);
        var i = this.source,
            s = i.length;
        if (e >= s) return -1;
        var r = i.charCodeAt(e);
        if (!t && !this.switchU || r <= 55295 || r >= 57344 || e + 1 >= s) return r;
        var n = i.charCodeAt(e + 1);
        return n >= 56320 && n <= 57343 ? (r << 10) + n - 56613888 : r
    }, wt.prototype.nextIndex = function(e, t) {
        void 0 === t && (t = !1);
        var i = this.source,
            s = i.length;
        if (e >= s) return s;
        var r, n = i.charCodeAt(e);
        return !t && !this.switchU || n <= 55295 || n >= 57344 || e + 1 >= s || (r = i.charCodeAt(e + 1)) < 56320 || r > 57343 ? e + 1 : e + 2
    }, wt.prototype.current = function(e) {
        return void 0 === e && (e = !1), this.at(this.pos, e)
    }, wt.prototype.lookahead = function(e) {
        return void 0 === e && (e = !1), this.at(this.nextIndex(this.pos, e), e)
    }, wt.prototype.advance = function(e) {
        void 0 === e && (e = !1), this.pos = this.nextIndex(this.pos, e)
    }, wt.prototype.eat = function(e, t) {
        return void 0 === t && (t = !1), this.current(t) === e && (this.advance(t), !0)
    }, wt.prototype.eatChars = function(e, t) {
        void 0 === t && (t = !1);
        for (var i = this.pos, s = 0, r = e; s < r.length; s += 1) {
            var n = r[s],
                a = this.at(i, t);
            if (-1 === a || a !== n) return !1;
            i = this.nextIndex(i, t)
        }
        return this.pos = i, !0
    }, vt.validateRegExpFlags = function(e) {
        for (var t = e.validFlags, i = e.flags, s = !1, r = !1, n = 0; n < i.length; n++) {
            var a = i.charAt(n); - 1 === t.indexOf(a) && this.raise(e.start, "Invalid regular expression flag"), i.indexOf(a, n + 1) > -1 && this.raise(e.start, "Duplicate regular expression flag"), "u" === a && (s = !0), "v" === a && (r = !0)
        }
        this.options.ecmaVersion >= 15 && s && r && this.raise(e.start, "Invalid regular expression flag")
    }, vt.validateRegExpPattern = function(e) {
        this.regexp_pattern(e), !e.switchN && this.options.ecmaVersion >= 9 && e.groupNames.length > 0 && (e.switchN = !0, this.regexp_pattern(e))
    }, vt.regexp_pattern = function(e) {
        e.pos = 0, e.lastIntValue = 0, e.lastStringValue = "", e.lastAssertionIsQuantifiable = !1, e.numCapturingParens = 0, e.maxBackReference = 0, e.groupNames.length = 0, e.backReferenceNames.length = 0, this.regexp_disjunction(e), e.pos !== e.source.length && (e.eat(41) && e.raise("Unmatched ')'"), (e.eat(93) || e.eat(125)) && e.raise("Lone quantifier brackets")), e.maxBackReference > e.numCapturingParens && e.raise("Invalid escape");
        for (var t = 0, i = e.backReferenceNames; t < i.length; t += 1) {
            var s = i[t]; - 1 === e.groupNames.indexOf(s) && e.raise("Invalid named capture referenced")
        }
    }, vt.regexp_disjunction = function(e) {
        for (this.regexp_alternative(e); e.eat(124);) this.regexp_alternative(e);
        this.regexp_eatQuantifier(e, !0) && e.raise("Nothing to repeat"), e.eat(123) && e.raise("Lone quantifier brackets")
    }, vt.regexp_alternative = function(e) {
        for (; e.pos < e.source.length && this.regexp_eatTerm(e););
    }, vt.regexp_eatTerm = function(e) {
        return this.regexp_eatAssertion(e) ? (e.lastAssertionIsQuantifiable && this.regexp_eatQuantifier(e) && e.switchU && e.raise("Invalid quantifier"), !0) : !!(e.switchU ? this.regexp_eatAtom(e) : this.regexp_eatExtendedAtom(e)) && (this.regexp_eatQuantifier(e), !0)
    }, vt.regexp_eatAssertion = function(e) {
        var t = e.pos;
        if (e.lastAssertionIsQuantifiable = !1, e.eat(94) || e.eat(36)) return !0;
        if (e.eat(92)) {
            if (e.eat(66) || e.eat(98)) return !0;
            e.pos = t
        }
        if (e.eat(40) && e.eat(63)) {
            var i = !1;
            if (this.options.ecmaVersion >= 9 && (i = e.eat(60)), e.eat(61) || e.eat(33)) return this.regexp_disjunction(e), e.eat(41) || e.raise("Unterminated group"), e.lastAssertionIsQuantifiable = !i, !0
        }
        return e.pos = t, !1
    }, vt.regexp_eatQuantifier = function(e, t) {
        return void 0 === t && (t = !1), !!this.regexp_eatQuantifierPrefix(e, t) && (e.eat(63), !0)
    }, vt.regexp_eatQuantifierPrefix = function(e, t) {
        return e.eat(42) || e.eat(43) || e.eat(63) || this.regexp_eatBracedQuantifier(e, t)
    }, vt.regexp_eatBracedQuantifier = function(e, t) {
        var i = e.pos;
        if (e.eat(123)) {
            var s = 0,
                r = -1;
            if (this.regexp_eatDecimalDigits(e) && (s = e.lastIntValue, e.eat(44) && this.regexp_eatDecimalDigits(e) && (r = e.lastIntValue), e.eat(125))) return -1 !== r && r < s && !t && e.raise("numbers out of order in {} quantifier"), !0;
            e.switchU && !t && e.raise("Incomplete quantifier"), e.pos = i
        }
        return !1
    }, vt.regexp_eatAtom = function(e) {
        return this.regexp_eatPatternCharacters(e) || e.eat(46) || this.regexp_eatReverseSolidusAtomEscape(e) || this.regexp_eatCharacterClass(e) || this.regexp_eatUncapturingGroup(e) || this.regexp_eatCapturingGroup(e)
    }, vt.regexp_eatReverseSolidusAtomEscape = function(e) {
        var t = e.pos;
        if (e.eat(92)) {
            if (this.regexp_eatAtomEscape(e)) return !0;
            e.pos = t
        }
        return !1
    }, vt.regexp_eatUncapturingGroup = function(e) {
        var t = e.pos;
        if (e.eat(40)) {
            if (e.eat(63) && e.eat(58)) {
                if (this.regexp_disjunction(e), e.eat(41)) return !0;
                e.raise("Unterminated group")
            }
            e.pos = t
        }
        return !1
    }, vt.regexp_eatCapturingGroup = function(e) {
        if (e.eat(40)) {
            if (this.options.ecmaVersion >= 9 ? this.regexp_groupSpecifier(e) : 63 === e.current() && e.raise("Invalid group"), this.regexp_disjunction(e), e.eat(41)) return e.numCapturingParens += 1, !0;
            e.raise("Unterminated group")
        }
        return !1
    }, vt.regexp_eatExtendedAtom = function(e) {
        return e.eat(46) || this.regexp_eatReverseSolidusAtomEscape(e) || this.regexp_eatCharacterClass(e) || this.regexp_eatUncapturingGroup(e) || this.regexp_eatCapturingGroup(e) || this.regexp_eatInvalidBracedQuantifier(e) || this.regexp_eatExtendedPatternCharacter(e)
    }, vt.regexp_eatInvalidBracedQuantifier = function(e) {
        return this.regexp_eatBracedQuantifier(e, !0) && e.raise("Nothing to repeat"), !1
    }, vt.regexp_eatSyntaxCharacter = function(e) {
        var t = e.current();
        return !!bt(t) && (e.lastIntValue = t, e.advance(), !0)
    }, vt.regexp_eatPatternCharacters = function(e) {
        for (var t = e.pos, i = 0; - 1 !== (i = e.current()) && !bt(i);) e.advance();
        return e.pos !== t
    }, vt.regexp_eatExtendedPatternCharacter = function(e) {
        var t = e.current();
        return !(-1 === t || 36 === t || t >= 40 && t <= 43 || 46 === t || 63 === t || 91 === t || 94 === t || 124 === t) && (e.advance(), !0)
    }, vt.regexp_groupSpecifier = function(e) {
        if (e.eat(63)) {
            if (this.regexp_eatGroupName(e)) return -1 !== e.groupNames.indexOf(e.lastStringValue) && e.raise("Duplicate capture group name"), void e.groupNames.push(e.lastStringValue);
            e.raise("Invalid group")
        }
    }, vt.regexp_eatGroupName = function(e) {
        if (e.lastStringValue = "", e.eat(60)) {
            if (this.regexp_eatRegExpIdentifierName(e) && e.eat(62)) return !0;
            e.raise("Invalid capture group name")
        }
        return !1
    }, vt.regexp_eatRegExpIdentifierName = function(e) {
        if (e.lastStringValue = "", this.regexp_eatRegExpIdentifierStart(e)) {
            for (e.lastStringValue += be(e.lastIntValue); this.regexp_eatRegExpIdentifierPart(e);) e.lastStringValue += be(e.lastIntValue);
            return !0
        }
        return !1
    }, vt.regexp_eatRegExpIdentifierStart = function(e) {
        var t = e.pos,
            i = this.options.ecmaVersion >= 11,
            s = e.current(i);
        return e.advance(i), 92 === s && this.regexp_eatRegExpUnicodeEscapeSequence(e, i) && (s = e.lastIntValue),
            function(e) {
                return ee(e, !0) || 36 === e || 95 === e
            }(s) ? (e.lastIntValue = s, !0) : (e.pos = t, !1)
    }, vt.regexp_eatRegExpIdentifierPart = function(e) {
        var t = e.pos,
            i = this.options.ecmaVersion >= 11,
            s = e.current(i);
        return e.advance(i), 92 === s && this.regexp_eatRegExpUnicodeEscapeSequence(e, i) && (s = e.lastIntValue),
            function(e) {
                return te(e, !0) || 36 === e || 95 === e || 8204 === e || 8205 === e
            }(s) ? (e.lastIntValue = s, !0) : (e.pos = t, !1)
    }, vt.regexp_eatAtomEscape = function(e) {
        return !!(this.regexp_eatBackReference(e) || this.regexp_eatCharacterClassEscape(e) || this.regexp_eatCharacterEscape(e) || e.switchN && this.regexp_eatKGroupName(e)) || (e.switchU && (99 === e.current() && e.raise("Invalid unicode escape"), e.raise("Invalid escape")), !1)
    }, vt.regexp_eatBackReference = function(e) {
        var t = e.pos;
        if (this.regexp_eatDecimalEscape(e)) {
            var i = e.lastIntValue;
            if (e.switchU) return i > e.maxBackReference && (e.maxBackReference = i), !0;
            if (i <= e.numCapturingParens) return !0;
            e.pos = t
        }
        return !1
    }, vt.regexp_eatKGroupName = function(e) {
        if (e.eat(107)) {
            if (this.regexp_eatGroupName(e)) return e.backReferenceNames.push(e.lastStringValue), !0;
            e.raise("Invalid named reference")
        }
        return !1
    }, vt.regexp_eatCharacterEscape = function(e) {
        return this.regexp_eatControlEscape(e) || this.regexp_eatCControlLetter(e) || this.regexp_eatZero(e) || this.regexp_eatHexEscapeSequence(e) || this.regexp_eatRegExpUnicodeEscapeSequence(e, !1) || !e.switchU && this.regexp_eatLegacyOctalEscapeSequence(e) || this.regexp_eatIdentityEscape(e)
    }, vt.regexp_eatCControlLetter = function(e) {
        var t = e.pos;
        if (e.eat(99)) {
            if (this.regexp_eatControlLetter(e)) return !0;
            e.pos = t
        }
        return !1
    }, vt.regexp_eatZero = function(e) {
        return 48 === e.current() && !Et(e.lookahead()) && (e.lastIntValue = 0, e.advance(), !0)
    }, vt.regexp_eatControlEscape = function(e) {
        var t = e.current();
        return 116 === t ? (e.lastIntValue = 9, e.advance(), !0) : 110 === t ? (e.lastIntValue = 10, e.advance(), !0) : 118 === t ? (e.lastIntValue = 11, e.advance(), !0) : 102 === t ? (e.lastIntValue = 12, e.advance(), !0) : 114 === t && (e.lastIntValue = 13, e.advance(), !0)
    }, vt.regexp_eatControlLetter = function(e) {
        var t = e.current();
        return !!_t(t) && (e.lastIntValue = t % 32, e.advance(), !0)
    }, vt.regexp_eatRegExpUnicodeEscapeSequence = function(e, t) {
        void 0 === t && (t = !1);
        var i = e.pos,
            s = t || e.switchU;
        if (e.eat(117)) {
            if (this.regexp_eatFixedHexDigits(e, 4)) {
                var r = e.lastIntValue;
                if (s && r >= 55296 && r <= 56319) {
                    var n = e.pos;
                    if (e.eat(92) && e.eat(117) && this.regexp_eatFixedHexDigits(e, 4)) {
                        var a = e.lastIntValue;
                        if (a >= 56320 && a <= 57343) return e.lastIntValue = 1024 * (r - 55296) + (a - 56320) + 65536, !0
                    }
                    e.pos = n, e.lastIntValue = r
                }
                return !0
            }
            if (s && e.eat(123) && this.regexp_eatHexDigits(e) && e.eat(125) && function(e) {
                    return e >= 0 && e <= 1114111
                }(e.lastIntValue)) return !0;
            s && e.raise("Invalid unicode escape"), e.pos = i
        }
        return !1
    }, vt.regexp_eatIdentityEscape = function(e) {
        if (e.switchU) return !!this.regexp_eatSyntaxCharacter(e) || !!e.eat(47) && (e.lastIntValue = 47, !0);
        var t = e.current();
        return !(99 === t || e.switchN && 107 === t) && (e.lastIntValue = t, e.advance(), !0)
    }, vt.regexp_eatDecimalEscape = function(e) {
        e.lastIntValue = 0;
        var t = e.current();
        if (t >= 49 && t <= 57) {
            do {
                e.lastIntValue = 10 * e.lastIntValue + (t - 48), e.advance()
            } while ((t = e.current()) >= 48 && t <= 57);
            return !0
        }
        return !1
    };

    function kt(e) {
        return _t(e) || 95 === e
    }

    function Ct(e) {
        return kt(e) || Et(e)
    }

    function Et(e) {
        return e >= 48 && e <= 57
    }

    function St(e) {
        return e >= 48 && e <= 57 || e >= 65 && e <= 70 || e >= 97 && e <= 102
    }

    function It(e) {
        return e >= 65 && e <= 70 ? e - 65 + 10 : e >= 97 && e <= 102 ? e - 97 + 10 : e - 48
    }

    function At(e) {
        return e >= 48 && e <= 55
    }
    vt.regexp_eatCharacterClassEscape = function(e) {
        var t = e.current();
        if (function(e) {
                return 100 === e || 68 === e || 115 === e || 83 === e || 119 === e || 87 === e
            }(t)) return e.lastIntValue = -1, e.advance(), 1;
        var i = !1;
        if (e.switchU && this.options.ecmaVersion >= 9 && ((i = 80 === t) || 112 === t)) {
            var s;
            if (e.lastIntValue = -1, e.advance(), e.eat(123) && (s = this.regexp_eatUnicodePropertyValueExpression(e)) && e.eat(125)) return i && 2 === s && e.raise("Invalid property name"), s;
            e.raise("Invalid property name")
        }
        return 0
    }, vt.regexp_eatUnicodePropertyValueExpression = function(e) {
        var t = e.pos;
        if (this.regexp_eatUnicodePropertyName(e) && e.eat(61)) {
            var i = e.lastStringValue;
            if (this.regexp_eatUnicodePropertyValue(e)) {
                var s = e.lastStringValue;
                return this.regexp_validateUnicodePropertyNameAndValue(e, i, s), 1
            }
        }
        if (e.pos = t, this.regexp_eatLoneUnicodePropertyNameOrValue(e)) {
            var r = e.lastStringValue;
            return this.regexp_validateUnicodePropertyNameOrValue(e, r)
        }
        return 0
    }, vt.regexp_validateUnicodePropertyNameAndValue = function(e, t, i) {
        ye(e.unicodeProperties.nonBinary, t) || e.raise("Invalid property name"), e.unicodeProperties.nonBinary[t].test(i) || e.raise("Invalid property value")
    }, vt.regexp_validateUnicodePropertyNameOrValue = function(e, t) {
        return e.unicodeProperties.binary.test(t) ? 1 : e.switchV && e.unicodeProperties.binaryOfStrings.test(t) ? 2 : void e.raise("Invalid property name")
    }, vt.regexp_eatUnicodePropertyName = function(e) {
        var t = 0;
        for (e.lastStringValue = ""; kt(t = e.current());) e.lastStringValue += be(t), e.advance();
        return "" !== e.lastStringValue
    }, vt.regexp_eatUnicodePropertyValue = function(e) {
        var t = 0;
        for (e.lastStringValue = ""; Ct(t = e.current());) e.lastStringValue += be(t), e.advance();
        return "" !== e.lastStringValue
    }, vt.regexp_eatLoneUnicodePropertyNameOrValue = function(e) {
        return this.regexp_eatUnicodePropertyValue(e)
    }, vt.regexp_eatCharacterClass = function(e) {
        if (e.eat(91)) {
            var t = e.eat(94),
                i = this.regexp_classContents(e);
            return e.eat(93) || e.raise("Unterminated character class"), t && 2 === i && e.raise("Negated character class may contain strings"), !0
        }
        return !1
    }, vt.regexp_classContents = function(e) {
        return 93 === e.current() ? 1 : e.switchV ? this.regexp_classSetExpression(e) : (this.regexp_nonEmptyClassRanges(e), 1)
    }, vt.regexp_nonEmptyClassRanges = function(e) {
        for (; this.regexp_eatClassAtom(e);) {
            var t = e.lastIntValue;
            if (e.eat(45) && this.regexp_eatClassAtom(e)) {
                var i = e.lastIntValue;
                e.switchU && (-1 === t || -1 === i) && e.raise("Invalid character class"), -1 !== t && -1 !== i && t > i && e.raise("Range out of order in character class")
            }
        }
    }, vt.regexp_eatClassAtom = function(e) {
        var t = e.pos;
        if (e.eat(92)) {
            if (this.regexp_eatClassEscape(e)) return !0;
            if (e.switchU) {
                var i = e.current();
                (99 === i || At(i)) && e.raise("Invalid class escape"), e.raise("Invalid escape")
            }
            e.pos = t
        }
        var s = e.current();
        return 93 !== s && (e.lastIntValue = s, e.advance(), !0)
    }, vt.regexp_eatClassEscape = function(e) {
        var t = e.pos;
        if (e.eat(98)) return e.lastIntValue = 8, !0;
        if (e.switchU && e.eat(45)) return e.lastIntValue = 45, !0;
        if (!e.switchU && e.eat(99)) {
            if (this.regexp_eatClassControlLetter(e)) return !0;
            e.pos = t
        }
        return this.regexp_eatCharacterClassEscape(e) || this.regexp_eatCharacterEscape(e)
    }, vt.regexp_classSetExpression = function(e) {
        var t, i = 1;
        if (!this.regexp_eatClassSetRange(e))
            if (t = this.regexp_eatClassSetOperand(e)) {
                2 === t && (i = 2);
                for (var s = e.pos; e.eatChars([38, 38]);) 38 !== e.current() && (t = this.regexp_eatClassSetOperand(e)) ? 2 !== t && (i = 1) : e.raise("Invalid character in character class");
                if (s !== e.pos) return i;
                for (; e.eatChars([45, 45]);) this.regexp_eatClassSetOperand(e) || e.raise("Invalid character in character class");
                if (s !== e.pos) return i
            } else e.raise("Invalid character in character class");
        for (;;)
            if (!this.regexp_eatClassSetRange(e)) {
                if (!(t = this.regexp_eatClassSetOperand(e))) return i;
                2 === t && (i = 2)
            }
    }, vt.regexp_eatClassSetRange = function(e) {
        var t = e.pos;
        if (this.regexp_eatClassSetCharacter(e)) {
            var i = e.lastIntValue;
            if (e.eat(45) && this.regexp_eatClassSetCharacter(e)) {
                var s = e.lastIntValue;
                return -1 !== i && -1 !== s && i > s && e.raise("Range out of order in character class"), !0
            }
            e.pos = t
        }
        return !1
    }, vt.regexp_eatClassSetOperand = function(e) {
        return this.regexp_eatClassSetCharacter(e) ? 1 : this.regexp_eatClassStringDisjunction(e) || this.regexp_eatNestedClass(e)
    }, vt.regexp_eatNestedClass = function(e) {
        var t = e.pos;
        if (e.eat(91)) {
            var i = e.eat(94),
                s = this.regexp_classContents(e);
            if (e.eat(93)) return i && 2 === s && e.raise("Negated character class may contain strings"), s;
            e.pos = t
        }
        if (e.eat(92)) {
            var r = this.regexp_eatCharacterClassEscape(e);
            if (r) return r;
            e.pos = t
        }
        return null
    }, vt.regexp_eatClassStringDisjunction = function(e) {
        var t = e.pos;
        if (e.eatChars([92, 113])) {
            if (e.eat(123)) {
                var i = this.regexp_classStringDisjunctionContents(e);
                if (e.eat(125)) return i
            } else e.raise("Invalid escape");
            e.pos = t
        }
        return null
    }, vt.regexp_classStringDisjunctionContents = function(e) {
        for (var t = this.regexp_classString(e); e.eat(124);) 2 === this.regexp_classString(e) && (t = 2);
        return t
    }, vt.regexp_classString = function(e) {
        for (var t = 0; this.regexp_eatClassSetCharacter(e);) t++;
        return 1 === t ? 1 : 2
    }, vt.regexp_eatClassSetCharacter = function(e) {
        var t = e.pos;
        if (e.eat(92)) return !(!this.regexp_eatCharacterEscape(e) && !this.regexp_eatClassSetReservedPunctuator(e)) || (e.eat(98) ? (e.lastIntValue = 8, !0) : (e.pos = t, !1));
        var i = e.current();
        return !(i < 0 || i === e.lookahead() && function(e) {
            return 33 === e || e >= 35 && e <= 38 || e >= 42 && e <= 44 || 46 === e || e >= 58 && e <= 64 || 94 === e || 96 === e || 126 === e
        }(i) || function(e) {
            return 40 === e || 41 === e || 45 === e || 47 === e || e >= 91 && e <= 93 || e >= 123 && e <= 125
        }(i)) && (e.advance(), e.lastIntValue = i, !0)
    }, vt.regexp_eatClassSetReservedPunctuator = function(e) {
        var t = e.current();
        return !! function(e) {
            return 33 === e || 35 === e || 37 === e || 38 === e || 44 === e || 45 === e || e >= 58 && e <= 62 || 64 === e || 96 === e || 126 === e
        }(t) && (e.lastIntValue = t, e.advance(), !0)
    }, vt.regexp_eatClassControlLetter = function(e) {
        var t = e.current();
        return !(!Et(t) && 95 !== t) && (e.lastIntValue = t % 32, e.advance(), !0)
    }, vt.regexp_eatHexEscapeSequence = function(e) {
        var t = e.pos;
        if (e.eat(120)) {
            if (this.regexp_eatFixedHexDigits(e, 2)) return !0;
            e.switchU && e.raise("Invalid escape"), e.pos = t
        }
        return !1
    }, vt.regexp_eatDecimalDigits = function(e) {
        var t = e.pos,
            i = 0;
        for (e.lastIntValue = 0; Et(i = e.current());) e.lastIntValue = 10 * e.lastIntValue + (i - 48), e.advance();
        return e.pos !== t
    }, vt.regexp_eatHexDigits = function(e) {
        var t = e.pos,
            i = 0;
        for (e.lastIntValue = 0; St(i = e.current());) e.lastIntValue = 16 * e.lastIntValue + It(i), e.advance();
        return e.pos !== t
    }, vt.regexp_eatLegacyOctalEscapeSequence = function(e) {
        if (this.regexp_eatOctalDigit(e)) {
            var t = e.lastIntValue;
            if (this.regexp_eatOctalDigit(e)) {
                var i = e.lastIntValue;
                t <= 3 && this.regexp_eatOctalDigit(e) ? e.lastIntValue = 64 * t + 8 * i + e.lastIntValue : e.lastIntValue = 8 * t + i
            } else e.lastIntValue = t;
            return !0
        }
        return !1
    }, vt.regexp_eatOctalDigit = function(e) {
        var t = e.current();
        return At(t) ? (e.lastIntValue = t - 48, e.advance(), !0) : (e.lastIntValue = 0, !1)
    }, vt.regexp_eatFixedHexDigits = function(e, t) {
        var i = e.pos;
        e.lastIntValue = 0;
        for (var s = 0; s < t; ++s) {
            var r = e.current();
            if (!St(r)) return e.pos = i, !1;
            e.lastIntValue = 16 * e.lastIntValue + It(r), e.advance()
        }
        return !0
    };
    var Pt = function(e) {
            this.type = e.type, this.value = e.value, this.start = e.start, this.end = e.end, e.options.locations && (this.loc = new Ce(e, e.startLoc, e.endLoc)), e.options.ranges && (this.range = [e.start, e.end])
        },
        Nt = Le.prototype;

    function Lt(e) {
        return "function" != typeof BigInt ? null : BigInt(e.replace(/_/g, ""))
    }
    Nt.next = function(e) {
        !e && this.type.keyword && this.containsEsc && this.raiseRecoverable(this.start, "Escape sequence in keyword " + this.type.keyword), this.options.onToken && this.options.onToken(new Pt(this)), this.lastTokEnd = this.end, this.lastTokStart = this.start, this.lastTokEndLoc = this.endLoc, this.lastTokStartLoc = this.startLoc, this.nextToken()
    }, Nt.getToken = function() {
        return this.next(), new Pt(this)
    }, typeof Symbol < "u" && (Nt[Symbol.iterator] = function() {
        var e = this;
        return {
            next: function() {
                var t = e.getToken();
                return {
                    done: t.type === ce.eof,
                    value: t
                }
            }
        }
    }), Nt.nextToken = function() {
        var e = this.curContext();
        return (!e || !e.preserveSpace) && this.skipSpace(), this.start = this.pos, this.options.locations && (this.startLoc = this.curPosition()), this.pos >= this.input.length ? this.finishToken(ce.eof) : e.override ? e.override(this) : void this.readToken(this.fullCharCodeAtPos())
    }, Nt.readToken = function(e) {
        return ee(e, this.options.ecmaVersion >= 6) || 92 === e ? this.readWord() : this.getTokenFromCode(e)
    }, Nt.fullCharCodeAtPos = function() {
        var e = this.input.charCodeAt(this.pos);
        if (e <= 55295 || e >= 56320) return e;
        var t = this.input.charCodeAt(this.pos + 1);
        return t <= 56319 || t >= 57344 ? e : (e << 10) + t - 56613888
    }, Nt.skipBlockComment = function() {
        var e = this.options.onComment && this.curPosition(),
            t = this.pos,
            i = this.input.indexOf("*/", this.pos += 2);
        if (-1 === i && this.raise(this.pos - 2, "Unterminated comment"), this.pos = i + 2, this.options.locations)
            for (var s = void 0, r = t;
                (s = ue(this.input, r, this.pos)) > -1;) ++this.curLine, r = this.lineStart = s;
        this.options.onComment && this.options.onComment(!0, this.input.slice(t + 2, i), t, this.pos, e, this.curPosition())
    }, Nt.skipLineComment = function(e) {
        for (var t = this.pos, i = this.options.onComment && this.curPosition(), s = this.input.charCodeAt(this.pos += e); this.pos < this.input.length && !pe(s);) s = this.input.charCodeAt(++this.pos);
        this.options.onComment && this.options.onComment(!1, this.input.slice(t + e, this.pos), t, this.pos, i, this.curPosition())
    }, Nt.skipSpace = function() {
        e: for (; this.pos < this.input.length;) {
            var e = this.input.charCodeAt(this.pos);
            switch (e) {
                case 32:
                case 160:
                    ++this.pos;
                    break;
                case 13:
                    10 === this.input.charCodeAt(this.pos + 1) && ++this.pos;
                case 10:
                case 8232:
                case 8233:
                    ++this.pos, this.options.locations && (++this.curLine, this.lineStart = this.pos);
                    break;
                case 47:
                    switch (this.input.charCodeAt(this.pos + 1)) {
                        case 42:
                            this.skipBlockComment();
                            break;
                        case 47:
                            this.skipLineComment(2);
                            break;
                        default:
                            break e
                    }
                    break;
                default:
                    if (!(e > 8 && e < 14 || e >= 5760 && de.test(String.fromCharCode(e)))) break e;
                    ++this.pos
            }
        }
    }, Nt.finishToken = function(e, t) {
        this.end = this.pos, this.options.locations && (this.endLoc = this.curPosition());
        var i = this.type;
        this.type = e, this.value = t, this.updateContext(i)
    }, Nt.readToken_dot = function() {
        var e = this.input.charCodeAt(this.pos + 1);
        if (e >= 48 && e <= 57) return this.readNumber(!0);
        var t = this.input.charCodeAt(this.pos + 2);
        return this.options.ecmaVersion >= 6 && 46 === e && 46 === t ? (this.pos += 3, this.finishToken(ce.ellipsis)) : (++this.pos, this.finishToken(ce.dot))
    }, Nt.readToken_slash = function() {
        var e = this.input.charCodeAt(this.pos + 1);
        return this.exprAllowed ? (++this.pos, this.readRegexp()) : 61 === e ? this.finishOp(ce.assign, 2) : this.finishOp(ce.slash, 1)
    }, Nt.readToken_mult_modulo_exp = function(e) {
        var t = this.input.charCodeAt(this.pos + 1),
            i = 1,
            s = 42 === e ? ce.star : ce.modulo;
        return this.options.ecmaVersion >= 7 && 42 === e && 42 === t && (++i, s = ce.starstar, t = this.input.charCodeAt(this.pos + 2)), 61 === t ? this.finishOp(ce.assign, i + 1) : this.finishOp(s, i)
    }, Nt.readToken_pipe_amp = function(e) {
        var t = this.input.charCodeAt(this.pos + 1);
        if (t === e) {
            if (this.options.ecmaVersion >= 12)
                if (61 === this.input.charCodeAt(this.pos + 2)) return this.finishOp(ce.assign, 3);
            return this.finishOp(124 === e ? ce.logicalOR : ce.logicalAND, 2)
        }
        return 61 === t ? this.finishOp(ce.assign, 2) : this.finishOp(124 === e ? ce.bitwiseOR : ce.bitwiseAND, 1)
    }, Nt.readToken_caret = function() {
        return 61 === this.input.charCodeAt(this.pos + 1) ? this.finishOp(ce.assign, 2) : this.finishOp(ce.bitwiseXOR, 1)
    }, Nt.readToken_plus_min = function(e) {
        var t = this.input.charCodeAt(this.pos + 1);
        return t === e ? 45 !== t || this.inModule || 62 !== this.input.charCodeAt(this.pos + 2) || 0 !== this.lastTokEnd && !he.test(this.input.slice(this.lastTokEnd, this.pos)) ? this.finishOp(ce.incDec, 2) : (this.skipLineComment(3), this.skipSpace(), this.nextToken()) : 61 === t ? this.finishOp(ce.assign, 2) : this.finishOp(ce.plusMin, 1)
    }, Nt.readToken_lt_gt = function(e) {
        var t = this.input.charCodeAt(this.pos + 1),
            i = 1;
        return t === e ? (i = 62 === e && 62 === this.input.charCodeAt(this.pos + 2) ? 3 : 2, 61 === this.input.charCodeAt(this.pos + i) ? this.finishOp(ce.assign, i + 1) : this.finishOp(ce.bitShift, i)) : 33 !== t || 60 !== e || this.inModule || 45 !== this.input.charCodeAt(this.pos + 2) || 45 !== this.input.charCodeAt(this.pos + 3) ? (61 === t && (i = 2), this.finishOp(ce.relational, i)) : (this.skipLineComment(4), this.skipSpace(), this.nextToken())
    }, Nt.readToken_eq_excl = function(e) {
        var t = this.input.charCodeAt(this.pos + 1);
        return 61 === t ? this.finishOp(ce.equality, 61 === this.input.charCodeAt(this.pos + 2) ? 3 : 2) : 61 === e && 62 === t && this.options.ecmaVersion >= 6 ? (this.pos += 2, this.finishToken(ce.arrow)) : this.finishOp(61 === e ? ce.eq : ce.prefix, 1)
    }, Nt.readToken_question = function() {
        var e = this.options.ecmaVersion;
        if (e >= 11) {
            var t = this.input.charCodeAt(this.pos + 1);
            if (46 === t) {
                var i = this.input.charCodeAt(this.pos + 2);
                if (i < 48 || i > 57) return this.finishOp(ce.questionDot, 2)
            }
            if (63 === t) {
                if (e >= 12)
                    if (61 === this.input.charCodeAt(this.pos + 2)) return this.finishOp(ce.assign, 3);
                return this.finishOp(ce.coalesce, 2)
            }
        }
        return this.finishOp(ce.question, 1)
    }, Nt.readToken_numberSign = function() {
        var e = 35;
        if (this.options.ecmaVersion >= 13 && (++this.pos, ee(e = this.fullCharCodeAtPos(), !0) || 92 === e)) return this.finishToken(ce.privateId, this.readWord1());
        this.raise(this.pos, "Unexpected character '" + be(e) + "'")
    }, Nt.getTokenFromCode = function(e) {
        switch (e) {
            case 46:
                return this.readToken_dot();
            case 40:
                return ++this.pos, this.finishToken(ce.parenL);
            case 41:
                return ++this.pos, this.finishToken(ce.parenR);
            case 59:
                return ++this.pos, this.finishToken(ce.semi);
            case 44:
                return ++this.pos, this.finishToken(ce.comma);
            case 91:
                return ++this.pos, this.finishToken(ce.bracketL);
            case 93:
                return ++this.pos, this.finishToken(ce.bracketR);
            case 123:
                return ++this.pos, this.finishToken(ce.braceL);
            case 125:
                return ++this.pos, this.finishToken(ce.braceR);
            case 58:
                return ++this.pos, this.finishToken(ce.colon);
            case 96:
                if (this.options.ecmaVersion < 6) break;
                return ++this.pos, this.finishToken(ce.backQuote);
            case 48:
                var t = this.input.charCodeAt(this.pos + 1);
                if (120 === t || 88 === t) return this.readRadixNumber(16);
                if (this.options.ecmaVersion >= 6) {
                    if (111 === t || 79 === t) return this.readRadixNumber(8);
                    if (98 === t || 66 === t) return this.readRadixNumber(2)
                }
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
                return this.readNumber(!1);
            case 34:
            case 39:
                return this.readString(e);
            case 47:
                return this.readToken_slash();
            case 37:
            case 42:
                return this.readToken_mult_modulo_exp(e);
            case 124:
            case 38:
                return this.readToken_pipe_amp(e);
            case 94:
                return this.readToken_caret();
            case 43:
            case 45:
                return this.readToken_plus_min(e);
            case 60:
            case 62:
                return this.readToken_lt_gt(e);
            case 61:
            case 33:
                return this.readToken_eq_excl(e);
            case 63:
                return this.readToken_question();
            case 126:
                return this.finishOp(ce.prefix, 1);
            case 35:
                return this.readToken_numberSign()
        }
        this.raise(this.pos, "Unexpected character '" + be(e) + "'")
    }, Nt.finishOp = function(e, t) {
        var i = this.input.slice(this.pos, this.pos + t);
        return this.pos += t, this.finishToken(e, i)
    }, Nt.readRegexp = function() {
        for (var e, t, i = this.pos;;) {
            this.pos >= this.input.length && this.raise(i, "Unterminated regular expression");
            var s = this.input.charAt(this.pos);
            if (he.test(s) && this.raise(i, "Unterminated regular expression"), e) e = !1;
            else {
                if ("[" === s) t = !0;
                else if ("]" === s && t) t = !1;
                else if ("/" === s && !t) break;
                e = "\\" === s
            }++this.pos
        }
        var r = this.input.slice(i, this.pos);
        ++this.pos;
        var n = this.pos,
            a = this.readWord1();
        this.containsEsc && this.unexpected(n);
        var o = this.regexpState || (this.regexpState = new wt(this));
        o.reset(i, r, a), this.validateRegExpFlags(o), this.validateRegExpPattern(o);
        var c = null;
        try {
            c = new RegExp(r, a)
        } catch {}
        return this.finishToken(ce.regexp, {
            pattern: r,
            flags: a,
            value: c
        })
    }, Nt.readInt = function(e, t, i) {
        for (var s = this.options.ecmaVersion >= 12 && void 0 === t, r = i && 48 === this.input.charCodeAt(this.pos), n = this.pos, a = 0, o = 0, c = 0, h = t ? ? 1 / 0; c < h; ++c, ++this.pos) {
            var l = this.input.charCodeAt(this.pos),
                p = void 0;
            if (s && 95 === l) r && this.raiseRecoverable(this.pos, "Numeric separator is not allowed in legacy octal numeric literals"), 95 === o && this.raiseRecoverable(this.pos, "Numeric separator must be exactly one underscore"), 0 === c && this.raiseRecoverable(this.pos, "Numeric separator is not allowed at the first of digits"), o = l;
            else {
                if ((p = l >= 97 ? l - 97 + 10 : l >= 65 ? l - 65 + 10 : l >= 48 && l <= 57 ? l - 48 : 1 / 0) >= e) break;
                o = l, a = a * e + p
            }
        }
        return s && 95 === o && this.raiseRecoverable(this.pos - 1, "Numeric separator is not allowed at the last of digits"), this.pos === n || null != t && this.pos - n !== t ? null : a
    }, Nt.readRadixNumber = function(e) {
        var t = this.pos;
        this.pos += 2;
        var i = this.readInt(e);
        return null == i && this.raise(this.start + 2, "Expected number in radix " + e), this.options.ecmaVersion >= 11 && 110 === this.input.charCodeAt(this.pos) ? (i = Lt(this.input.slice(t, this.pos)), ++this.pos) : ee(this.fullCharCodeAtPos()) && this.raise(this.pos, "Identifier directly after number"), this.finishToken(ce.num, i)
    }, Nt.readNumber = function(e) {
        var t = this.pos;
        !e && null === this.readInt(10, void 0, !0) && this.raise(t, "Invalid number");
        var i = this.pos - t >= 2 && 48 === this.input.charCodeAt(t);
        i && this.strict && this.raise(t, "Invalid number");
        var s = this.input.charCodeAt(this.pos);
        if (!i && !e && this.options.ecmaVersion >= 11 && 110 === s) {
            var r = Lt(this.input.slice(t, this.pos));
            return ++this.pos, ee(this.fullCharCodeAtPos()) && this.raise(this.pos, "Identifier directly after number"), this.finishToken(ce.num, r)
        }
        i && /[89]/.test(this.input.slice(t, this.pos)) && (i = !1), 46 === s && !i && (++this.pos, this.readInt(10), s = this.input.charCodeAt(this.pos)), (69 === s || 101 === s) && !i && ((43 === (s = this.input.charCodeAt(++this.pos)) || 45 === s) && ++this.pos, null === this.readInt(10) && this.raise(t, "Invalid number")), ee(this.fullCharCodeAtPos()) && this.raise(this.pos, "Identifier directly after number");
        var n = function(e, t) {
            return t ? parseInt(e, 8) : parseFloat(e.replace(/_/g, ""))
        }(this.input.slice(t, this.pos), i);
        return this.finishToken(ce.num, n)
    }, Nt.readCodePoint = function() {
        var e;
        if (123 === this.input.charCodeAt(this.pos)) {
            this.options.ecmaVersion < 6 && this.unexpected();
            var t = ++this.pos;
            e = this.readHexChar(this.input.indexOf("}", this.pos) - this.pos), ++this.pos, e > 1114111 && this.invalidStringToken(t, "Code point out of bounds")
        } else e = this.readHexChar(4);
        return e
    }, Nt.readString = function(e) {
        for (var t = "", i = ++this.pos;;) {
            this.pos >= this.input.length && this.raise(this.start, "Unterminated string constant");
            var s = this.input.charCodeAt(this.pos);
            if (s === e) break;
            92 === s ? (t += this.input.slice(i, this.pos), t += this.readEscapedChar(!1), i = this.pos) : 8232 === s || 8233 === s ? (this.options.ecmaVersion < 10 && this.raise(this.start, "Unterminated string constant"), ++this.pos, this.options.locations && (this.curLine++, this.lineStart = this.pos)) : (pe(s) && this.raise(this.start, "Unterminated string constant"), ++this.pos)
        }
        return t += this.input.slice(i, this.pos++), this.finishToken(ce.string, t)
    };
    var Tt = {};
    Nt.tryReadTemplateToken = function() {
        this.inTemplateElement = !0;
        try {
            this.readTmplToken()
        } catch (e) {
            if (e !== Tt) throw e;
            this.readInvalidTemplateToken()
        }
        this.inTemplateElement = !1
    }, Nt.invalidStringToken = function(e, t) {
        if (this.inTemplateElement && this.options.ecmaVersion >= 9) throw Tt;
        this.raise(e, t)
    }, Nt.readTmplToken = function() {
        for (var e = "", t = this.pos;;) {
            this.pos >= this.input.length && this.raise(this.start, "Unterminated template");
            var i = this.input.charCodeAt(this.pos);
            if (96 === i || 36 === i && 123 === this.input.charCodeAt(this.pos + 1)) return this.pos !== this.start || this.type !== ce.template && this.type !== ce.invalidTemplate ? (e += this.input.slice(t, this.pos), this.finishToken(ce.template, e)) : 36 === i ? (this.pos += 2, this.finishToken(ce.dollarBraceL)) : (++this.pos, this.finishToken(ce.backQuote));
            if (92 === i) e += this.input.slice(t, this.pos), e += this.readEscapedChar(!0), t = this.pos;
            else if (pe(i)) {
                switch (e += this.input.slice(t, this.pos), ++this.pos, i) {
                    case 13:
                        10 === this.input.charCodeAt(this.pos) && ++this.pos;
                    case 10:
                        e += "\n";
                        break;
                    default:
                        e += String.fromCharCode(i)
                }
                this.options.locations && (++this.curLine, this.lineStart = this.pos), t = this.pos
            } else ++this.pos
        }
    }, Nt.readInvalidTemplateToken = function() {
        for (; this.pos < this.input.length; this.pos++) switch (this.input[this.pos]) {
            case "\\":
                ++this.pos;
                break;
            case "$":
                if ("{" !== this.input[this.pos + 1]) break;
            case "`":
                return this.finishToken(ce.invalidTemplate, this.input.slice(this.start, this.pos))
        }
        this.raise(this.start, "Unterminated template")
    }, Nt.readEscapedChar = function(e) {
        var t = this.input.charCodeAt(++this.pos);
        switch (++this.pos, t) {
            case 110:
                return "\n";
            case 114:
                return "\r";
            case 120:
                return String.fromCharCode(this.readHexChar(2));
            case 117:
                return be(this.readCodePoint());
            case 116:
                return "\t";
            case 98:
                return "\b";
            case 118:
                return "\v";
            case 102:
                return "\f";
            case 13:
                10 === this.input.charCodeAt(this.pos) && ++this.pos;
            case 10:
                return this.options.locations && (this.lineStart = this.pos, ++this.curLine), "";
            case 56:
            case 57:
                if (this.strict && this.invalidStringToken(this.pos - 1, "Invalid escape sequence"), e) {
                    var i = this.pos - 1;
                    this.invalidStringToken(i, "Invalid escape sequence in template string")
                }
            default:
                if (t >= 48 && t <= 55) {
                    var s = this.input.substr(this.pos - 1, 3).match(/^[0-7]+/)[0],
                        r = parseInt(s, 8);
                    return r > 255 && (s = s.slice(0, -1), r = parseInt(s, 8)), this.pos += s.length - 1, t = this.input.charCodeAt(this.pos), ("0" !== s || 56 === t || 57 === t) && (this.strict || e) && this.invalidStringToken(this.pos - 1 - s.length, e ? "Octal literal in template string" : "Octal literal in strict mode"), String.fromCharCode(r)
                }
                return pe(t) ? "" : String.fromCharCode(t)
        }
    }, Nt.readHexChar = function(e) {
        var t = this.pos,
            i = this.readInt(16, e);
        return null === i && this.invalidStringToken(t, "Bad character escape sequence"), i
    }, Nt.readWord1 = function() {
        this.containsEsc = !1;
        for (var e = "", t = !0, i = this.pos, s = this.options.ecmaVersion >= 6; this.pos < this.input.length;) {
            var r = this.fullCharCodeAtPos();
            if (te(r, s)) this.pos += r <= 65535 ? 1 : 2;
            else {
                if (92 !== r) break;
                this.containsEsc = !0, e += this.input.slice(i, this.pos);
                var n = this.pos;
                117 !== this.input.charCodeAt(++this.pos) && this.invalidStringToken(this.pos, "Expecting Unicode escape sequence \\uXXXX"), ++this.pos;
                var a = this.readCodePoint();
                (t ? ee : te)(a, s) || this.invalidStringToken(n, "Invalid Unicode escape"), e += be(a), i = this.pos
            }
            t = !1
        }
        return e + this.input.slice(i, this.pos)
    }, Nt.readWord = function() {
        var e = this.readWord1(),
            t = ce.name;
        return this.keywords.test(e) && (t = ae[e]), this.finishToken(t, e)
    };

    function Rt(e, t) {
        return Le.parse(e, t)
    }
    Le.acorn = {
        Parser: Le,
        version: "8.10.0",
        defaultOptions: Se,
        Position: ke,
        SourceLocation: Ce,
        getLineInfo: Ee,
        Node: et,
        TokenType: ie,
        tokTypes: ce,
        keywordTypes: ae,
        TokContext: qe,
        tokContexts: Ge,
        isIdentifierChar: te,
        isIdentifierStart: ee,
        Token: Pt,
        isNewLine: pe,
        lineBreak: he,
        lineBreakG: le,
        nonASCIIwhitespace: de
    };
    var Vt = globalThis.fetch,
        Ot = globalThis.WebSocket,
        Dt = globalThis.Request,
        jt = globalThis.Response,
        Mt = {
            prototype: {
                send: Ot.prototype.send
            },
            CLOSED: Ot.CLOSED,
            CLOSING: Ot.CLOSING,
            CONNECTING: Ot.CONNECTING,
            OPEN: Ot.OPEN
        },
        Bt = [101, 204, 205, 304],
        Ut = [301, 302, 303, 307, 308],
        $t = class extends Error {
            constructor(e, t) {
                super(t.message || t.code), u(this, "status"), u(this, "body"), this.status = e, this.body = t
            }
        },
        Ft = class {
            constructor(e, t) {
                u(this, "base"), this.base = new URL(`./v${e}/`, t)
            }
        };

    function Ht(e, t) {
        let i = (65535 & e) + (65535 & t);
        return (e >> 16) + (t >> 16) + (i >> 16) << 16 | 65535 & i
    }

    function Wt(e, t, i, s, r, n) {
        return Ht(function(e, t) {
            return e << t | e >>> 32 - t
        }(Ht(Ht(t, e), Ht(s, n)), r), i)
    }

    function qt(e, t, i, s, r, n, a) {
        return Wt(t & i | ~t & s, e, t, r, n, a)
    }

    function Gt(e, t, i, s, r, n, a) {
        return Wt(t & s | i & ~s, e, t, r, n, a)
    }

    function zt(e, t, i, s, r, n, a) {
        return Wt(t ^ i ^ s, e, t, r, n, a)
    }

    function Kt(e, t, i, s, r, n, a) {
        return Wt(i ^ (t | ~s), e, t, r, n, a)
    }

    function Qt(e, t) {
        e[t >> 5] |= 128 << t % 32, e[14 + (t + 64 >>> 9 << 4)] = t;
        let i = 1732584193,
            s = -271733879,
            r = -1732584194,
            n = 271733878;
        for (let t = 0; t < e.length; t += 16) {
            let a = i,
                o = s,
                c = r,
                h = n;
            i = qt(i, s, r, n, e[t], 7, -680876936), n = qt(n, i, s, r, e[t + 1], 12, -389564586), r = qt(r, n, i, s, e[t + 2], 17, 606105819), s = qt(s, r, n, i, e[t + 3], 22, -1044525330), i = qt(i, s, r, n, e[t + 4], 7, -176418897), n = qt(n, i, s, r, e[t + 5], 12, 1200080426), r = qt(r, n, i, s, e[t + 6], 17, -1473231341), s = qt(s, r, n, i, e[t + 7], 22, -45705983), i = qt(i, s, r, n, e[t + 8], 7, 1770035416), n = qt(n, i, s, r, e[t + 9], 12, -1958414417), r = qt(r, n, i, s, e[t + 10], 17, -42063), s = qt(s, r, n, i, e[t + 11], 22, -1990404162), i = qt(i, s, r, n, e[t + 12], 7, 1804603682), n = qt(n, i, s, r, e[t + 13], 12, -40341101), r = qt(r, n, i, s, e[t + 14], 17, -1502002290), s = qt(s, r, n, i, e[t + 15], 22, 1236535329), i = Gt(i, s, r, n, e[t + 1], 5, -165796510), n = Gt(n, i, s, r, e[t + 6], 9, -1069501632), r = Gt(r, n, i, s, e[t + 11], 14, 643717713), s = Gt(s, r, n, i, e[t], 20, -373897302), i = Gt(i, s, r, n, e[t + 5], 5, -701558691), n = Gt(n, i, s, r, e[t + 10], 9, 38016083), r = Gt(r, n, i, s, e[t + 15], 14, -660478335), s = Gt(s, r, n, i, e[t + 4], 20, -405537848), i = Gt(i, s, r, n, e[t + 9], 5, 568446438), n = Gt(n, i, s, r, e[t + 14], 9, -1019803690), r = Gt(r, n, i, s, e[t + 3], 14, -187363961), s = Gt(s, r, n, i, e[t + 8], 20, 1163531501), i = Gt(i, s, r, n, e[t + 13], 5, -1444681467), n = Gt(n, i, s, r, e[t + 2], 9, -51403784), r = Gt(r, n, i, s, e[t + 7], 14, 1735328473), s = Gt(s, r, n, i, e[t + 12], 20, -1926607734), i = zt(i, s, r, n, e[t + 5], 4, -378558), n = zt(n, i, s, r, e[t + 8], 11, -2022574463), r = zt(r, n, i, s, e[t + 11], 16, 1839030562), s = zt(s, r, n, i, e[t + 14], 23, -35309556), i = zt(i, s, r, n, e[t + 1], 4, -1530992060), n = zt(n, i, s, r, e[t + 4], 11, 1272893353), r = zt(r, n, i, s, e[t + 7], 16, -155497632), s = zt(s, r, n, i, e[t + 10], 23, -1094730640), i = zt(i, s, r, n, e[t + 13], 4, 681279174), n = zt(n, i, s, r, e[t], 11, -358537222), r = zt(r, n, i, s, e[t + 3], 16, -722521979), s = zt(s, r, n, i, e[t + 6], 23, 76029189), i = zt(i, s, r, n, e[t + 9], 4, -640364487), n = zt(n, i, s, r, e[t + 12], 11, -421815835), r = zt(r, n, i, s, e[t + 15], 16, 530742520), s = zt(s, r, n, i, e[t + 2], 23, -995338651), i = Kt(i, s, r, n, e[t], 6, -198630844), n = Kt(n, i, s, r, e[t + 7], 10, 1126891415), r = Kt(r, n, i, s, e[t + 14], 15, -1416354905), s = Kt(s, r, n, i, e[t + 5], 21, -57434055), i = Kt(i, s, r, n, e[t + 12], 6, 1700485571), n = Kt(n, i, s, r, e[t + 3], 10, -1894986606), r = Kt(r, n, i, s, e[t + 10], 15, -1051523), s = Kt(s, r, n, i, e[t + 1], 21, -2054922799), i = Kt(i, s, r, n, e[t + 8], 6, 1873313359), n = Kt(n, i, s, r, e[t + 15], 10, -30611744), r = Kt(r, n, i, s, e[t + 6], 15, -1560198380), s = Kt(s, r, n, i, e[t + 13], 21, 1309151649), i = Kt(i, s, r, n, e[t + 4], 6, -145523070), n = Kt(n, i, s, r, e[t + 11], 10, -1120210379), r = Kt(r, n, i, s, e[t + 2], 15, 718787259), s = Kt(s, r, n, i, e[t + 9], 21, -343485551), i = Ht(i, a), s = Ht(s, o), r = Ht(r, c), n = Ht(n, h)
        }
        return [i, s, r, n]
    }

    function Yt(e) {
        let t = "",
            i = 32 * e.length;
        for (let s = 0; s < i; s += 8) t += String.fromCharCode(e[s >> 5] >>> s % 32 & 255);
        return t
    }

    function Jt(e) {
        let t = [],
            i = e.length >> 2;
        for (let e = 0; e < i; e += 1) t[e] = 0;
        let s = 8 * e.length;
        for (let i = 0; i < s; i += 8) t[i >> 5] |= (255 & e.charCodeAt(i / 8)) << i % 32;
        return t
    }

    function Zt(e) {
        let t = "0123456789abcdef",
            i = "";
        for (let s = 0; s < e.length; s += 1) {
            let r = e.charCodeAt(s);
            i += t.charAt(r >>> 4 & 15) + t.charAt(15 & r)
        }
        return i
    }

    function Xt(e) {
        return unescape(encodeURIComponent(e))
    }

    function ei(e) {
        return function(e) {
            return Yt(Qt(Jt(e), 8 * e.length))
        }(Xt(e))
    }

    function ti(e, t) {
        return function(e, t) {
            let i = Jt(e),
                s = [],
                r = [];
            i.length > 16 && (i = Qt(i, 8 * e.length));
            for (let e = 0; e < 16; e += 1) s[e] = 909522486 ^ i[e], r[e] = 1549556828 ^ i[e];
            let n = Qt(s.concat(Jt(t)), 512 + 8 * t.length);
            return Yt(Qt(r.concat(n), 640))
        }(Xt(e), Xt(t))
    }

    function ii(e, t, i) {
        return t ? i ? ti(t, e) : function(e, t) {
            return Zt(ti(e, t))
        }(t, e) : i ? ei(e) : function(e) {
            return Zt(ei(e))
        }(e)
    }
    var si = 3072;

    function ri(e) {
        for (let t = 0; t < e.length; t++) {
            let i = e[t];
            if (!"!#$%&'*+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~".includes(i)) return !1
        }
        return !0
    }
    var ni = [
        ["v3", class extends Ft {
            constructor(e) {
                super(3, e), u(this, "ws"), u(this, "http"), this.ws = new URL(this.base), this.http = new URL(this.base), "https:" === this.ws.protocol ? this.ws.protocol = "wss:" : this.ws.protocol = "ws:"
            }
            connect(e, t, i, s, r) {
                let n = new Ot(this.ws),
                    a = () => {
                        n.removeEventListener("close", o), n.removeEventListener("message", c)
                    },
                    o = () => {
                        a()
                    },
                    c = e => {
                        if (a(), "string" != typeof e.data) throw new TypeError("the first websocket message was not a text frame");
                        let t = JSON.parse(e.data);
                        if ("open" !== t.type) throw new TypeError("message was not of open type");
                        e.stopImmediatePropagation(), s({
                            protocol: t.protocol,
                            setCookies: t.setCookies
                        }), r(Mt.OPEN), n.dispatchEvent(new Event("open"))
                    };
                return n.addEventListener("close", o), n.addEventListener("message", c), n.addEventListener("open", (s => {
                    s.stopImmediatePropagation(), r(Mt.CONNECTING), i().then((i => Mt.prototype.send.call(n, JSON.stringify({
                        type: "connect",
                        remote: e.toString(),
                        protocols: t,
                        headers: i,
                        forwardHeaders: []
                    }))))
                }), {
                    once: !0
                }), n
            }
            async request(e, t, i, s, r, n, a) {
                if (s.protocol.startsWith("blob:")) {
                    let e = await Vt(s),
                        t = new jt(e.body, e);
                    return t.rawHeaders = Object.fromEntries(e.headers), t.rawResponse = e, t
                }
                let o = {};
                if (t instanceof Headers)
                    for (let [e, i] of t) o[e] = i;
                else
                    for (let e in t) o[e] = t[e];
                let c = {
                    credentials: "omit",
                    method: e,
                    signal: a
                };
                "only-if-cached" !== r && (c.cache = r), void 0 !== i && (c.body = i), void 0 !== n && (c.duplex = n), c.headers = this.createBareHeaders(s, o);
                let h = await Vt(this.http + "?cache=" + ii(s.toString()), c),
                    l = await this.readBareResponse(h),
                    p = new jt(Bt.includes(l.status) ? void 0 : h.body, {
                        status: l.status,
                        statusText: l.statusText ? ? void 0,
                        headers: new Headers(l.headers)
                    });
                return p.rawHeaders = l.headers, p.rawResponse = h, p
            }
            async readBareResponse(e) {
                if (!e.ok) throw new $t(e.status, await e.json());
                let t = function(e) {
                        let t = new Headers(e),
                            i = "x-bare-headers";
                        if (e.has(`${i}-0`)) {
                            let s = [];
                            for (let [r, n] of e)
                                if (r.startsWith(i)) {
                                    if (!n.startsWith(";")) throw new $t(400, {
                                        code: "INVALID_BARE_HEADER",
                                        id: `request.headers.${r}`,
                                        message: "Value didn't begin with semi-colon."
                                    });
                                    s[parseInt(r.slice(15))] = n.slice(1), t.delete(r)
                                }
                            t.set(i, s.join(""))
                        }
                        return t
                    }(e.headers),
                    i = {},
                    s = t.get("x-bare-status");
                null !== s && (i.status = parseInt(s));
                let r = t.get("x-bare-status-text");
                null !== r && (i.statusText = r);
                let n = t.get("x-bare-headers");
                return null !== n && (i.headers = JSON.parse(n)), i
            }
            createBareHeaders(e, t, i = [], s = [], r = []) {
                let n = new Headers;
                n.set("x-bare-url", e.toString()), n.set("x-bare-headers", JSON.stringify(t));
                for (let e of i) n.append("x-bare-forward-headers", e);
                for (let e of s) n.append("x-bare-pass-headers", e);
                for (let e of r) n.append("x-bare-pass-status", e.toString());
                return function(e) {
                    let t = new Headers(e);
                    if (e.has("x-bare-headers")) {
                        let i = e.get("x-bare-headers");
                        if (i.length > si) {
                            t.delete("x-bare-headers");
                            let e = 0;
                            for (let s = 0; s < i.length; s += si) {
                                let r = i.slice(s, s + si),
                                    n = e++;
                                t.set(`x-bare-headers-${n}`, `;${r}`)
                            }
                        }
                    }
                }(n), n
            }
        }]
    ];
    async function ai(e, t) {
        let i = await Vt(e, {
            signal: t
        });
        if (!i.ok) throw new Error(`Unable to fetch Bare meta: ${i.status} ${await i.text()}`);
        return await i.json()
    }
    var oi = Object.getOwnPropertyDescriptor(Ot.prototype, "readyState").get,
        ci = ["ws:", "wss:"],
        hi = class {
            constructor(e, t) {
                u(this, "manifest"), u(this, "client"), u(this, "server"), u(this, "working"), u(this, "onDemand"), u(this, "onDemandSignal"), this.server = new URL(e), !t || t instanceof AbortSignal ? (this.onDemand = !0, this.onDemandSignal = t) : (this.onDemand = !1, this.loadManifest(t))
            }
            loadManifest(e) {
                return this.manifest = e, this.client = this.getClient(), this.client
            }
            demand() {
                return this.onDemand ? (this.working || (this.working = ai(this.server, this.onDemandSignal).then((e => this.loadManifest(e))).catch((e => {
                    throw delete this.working, e
                }))), this.working) : this.client
            }
            getClient() {
                for (let [e, t] of ni)
                    if (this.manifest.versions.includes(e)) return new t(this.server);
                throw new Error("Unable to find compatible client version. Starting from v2.0.0, @tomphttp/bare-client only supports Bare servers v3+. For more information, see https://github.com/tomphttp/bare-client/")
            }
            createWebSocket(e, t = [], i) {
                if (!this.client) throw new TypeError("You need to wait for the client to finish fetching the manifest before creating any WebSockets. Try caching the manifest data before making this request.");
                try {
                    e = new URL(e)
                } catch {
                    throw new DOMException(`Faiiled to construct 'WebSocket': The URL '${e}' is invalid.`)
                }
                if (!ci.includes(e.protocol)) throw new DOMException(`Failed to construct 'WebSocket': The URL's scheme must be either 'ws' or 'wss'. '${e.protocol}' is not allowed.`);
                Array.isArray(t) || (t = [t]), t = t.map(String);
                for (let e of t)
                    if (!ri(e)) throw new DOMException(`Failed to construct 'WebSocket': The subprotocol '${e}' is invalid.`);
                let s = this.client.connect(e, t, (async () => {
                        let t = "function" == typeof i.headers ? await i.headers() : i.headers || {},
                            s = t instanceof Headers ? Object.fromEntries(t) : t;
                        return s.Host = e.host, s.Pragma = "no-cache", s["Cache-Control"] = "no-cache", s.Upgrade = "websocket", s.Connection = "Upgrade", s
                    }), (e => {
                        r = e.protocol, i.setCookiesCallback && i.setCookiesCallback(e.setCookies)
                    }), (e => {
                        n = e
                    }), i.webSocketImpl || Ot),
                    r = "",
                    n = Mt.CONNECTING,
                    a = () => {
                        let e = oi.call(s);
                        return e === Mt.OPEN ? n : e
                    };
                i.readyStateHook ? i.readyStateHook(s, a) : Object.defineProperty(s, "readyState", {
                    get: a,
                    configurable: !0,
                    enumerable: !0
                });
                let o = () => {
                    if (a() === Mt.CONNECTING) return new DOMException("Failed to execute 'send' on 'WebSocket': Still in CONNECTING state.")
                };
                i.sendErrorHook ? i.sendErrorHook(s, o) : s.send = function(...e) {
                    let t = o();
                    if (t) throw t;
                    Mt.prototype.send.call(this, ...e)
                }, i.urlHook ? i.urlHook(s, e) : Object.defineProperty(s, "url", {
                    get: () => e.toString(),
                    configurable: !0,
                    enumerable: !0
                });
                let c = () => r;
                return i.protocolHook ? i.protocolHook(s, c) : Object.defineProperty(s, "protocol", {
                    get: c,
                    configurable: !0,
                    enumerable: !0
                }), s
            }
            async fetch(e, t) {
                let i = function(e) {
                        return "string" == typeof e || e instanceof URL
                    }(e) ? new Dt(e, t) : e,
                    s = t ? .headers || i.headers,
                    r = s instanceof Headers ? Object.fromEntries(s) : s,
                    n = t ? .duplex,
                    a = t ? .body || i.body,
                    o = new URL(i.url),
                    c = await this.demand();
                for (let e = 0;; e++) {
                    "host" in r ? r.host = o.host : r.Host = o.host;
                    let s = await c.request(i.method, r, a, o, i.cache, n, i.signal);
                    s.finalURL = o.toString();
                    let h = t ? .redirect || i.redirect;
                    if (!Ut.includes(s.status)) return s;
                    switch (h) {
                        case "follow":
                            {
                                let t = s.headers.get("location");
                                if (20 > e && null !== t) {
                                    o = new URL(t, o);
                                    continue
                                }
                                throw new TypeError("Failed to fetch")
                            }
                        case "error":
                            throw new TypeError("Failed to fetch");
                        case "manual":
                            return s
                    }
                }
            }
        };
    async function li(e, t) {
        let i = await ai(e, t);
        return new hi(e, i)
    }
    var pi = p(f(), 1),
        ui = p(m(), 1),
        {
            stringify: di
        } = JSON;
    if (!String.prototype.repeat) throw new Error("String.prototype.repeat is undefined, see https://github.com/davidbonnet/astring#installation");
    if (!String.prototype.endsWith) throw new Error("String.prototype.endsWith is undefined, see https://github.com/davidbonnet/astring#installation");
    var fi = {
            "||": 2,
            "??": 3,
            "&&": 4,
            "|": 5,
            "^": 6,
            "&": 7,
            "==": 8,
            "!=": 8,
            "===": 8,
            "!==": 8,
            "<": 9,
            ">": 9,
            "<=": 9,
            ">=": 9,
            in: 9,
            instanceof: 9,
            "<<": 10,
            ">>": 10,
            ">>>": 10,
            "+": 11,
            "-": 11,
            "*": 12,
            "%": 12,
            "/": 12,
            "**": 13
        },
        mi = 17,
        gi = {
            ArrayExpression: 20,
            TaggedTemplateExpression: 20,
            ThisExpression: 20,
            Identifier: 20,
            PrivateIdentifier: 20,
            Literal: 18,
            TemplateLiteral: 20,
            Super: 20,
            SequenceExpression: 20,
            MemberExpression: 19,
            ChainExpression: 19,
            CallExpression: 19,
            NewExpression: 19,
            ArrowFunctionExpression: mi,
            ClassExpression: mi,
            FunctionExpression: mi,
            ObjectExpression: mi,
            UpdateExpression: 16,
            UnaryExpression: 15,
            AwaitExpression: 15,
            BinaryExpression: 14,
            LogicalExpression: 13,
            ConditionalExpression: 4,
            AssignmentExpression: 3,
            YieldExpression: 2,
            RestElement: 1
        };

    function xi(e, t) {
        let {
            generator: i
        } = e;
        if (e.write("("), null != t && t.length > 0) {
            i[t[0].type](t[0], e);
            let {
                length: s
            } = t;
            for (let r = 1; r < s; r++) {
                let s = t[r];
                e.write(", "), i[s.type](s, e)
            }
        }
        e.write(")")
    }

    function yi(e, t, i, s) {
        let r = e.expressionsPrecedence[t.type];
        if (r === mi) return !0;
        let n = e.expressionsPrecedence[i.type];
        return r !== n ? !s && 15 === r && 14 === n && "**" === i.operator || r < n : (13 === r || 14 === r) && ("**" === t.operator && "**" === i.operator ? !s : 13 === r && 13 === n && ("??" === t.operator || "??" === i.operator) || (s ? fi[t.operator] <= fi[i.operator] : fi[t.operator] < fi[i.operator]))
    }

    function vi(e, t, i, s) {
        let {
            generator: r
        } = e;
        yi(e, t, i, s) ? (e.write("("), r[t.type](t, e), e.write(")")) : r[t.type](t, e)
    }

    function wi(e, t, i, s) {
        let r = t.split("\n"),
            n = r.length - 1;
        if (e.write(r[0].trim()), n > 0) {
            e.write(s);
            for (let t = 1; t < n; t++) e.write(i + r[t].trim() + s);
            e.write(i + r[n].trim())
        }
    }

    function bi(e, t, i, s) {
        let {
            length: r
        } = t;
        for (let n = 0; n < r; n++) {
            let r = t[n];
            e.write(i), "L" === r.type[0] ? e.write("// " + r.value.trim() + "\n", r) : (e.write("/*"), wi(e, r.value, i, s), e.write("*/" + s))
        }
    }

    function _i(e, t) {
        let {
            generator: i
        } = e, {
            declarations: s
        } = t;
        e.write(t.kind + " ");
        let {
            length: r
        } = s;
        if (r > 0) {
            i.VariableDeclarator(s[0], e);
            for (let t = 1; t < r; t++) e.write(", "), i.VariableDeclarator(s[t], e)
        }
    }
    var ki, Ci, Ei, Si, Ii, Ai, Pi = {
            Program(e, t) {
                let i = t.indent.repeat(t.indentLevel),
                    {
                        lineEnd: s,
                        writeComments: r
                    } = t;
                r && null != e.comments && bi(t, e.comments, i, s);
                let n = e.body,
                    {
                        length: a
                    } = n;
                for (let e = 0; e < a; e++) {
                    let a = n[e];
                    r && null != a.comments && bi(t, a.comments, i, s), t.write(i), this[a.type](a, t), t.write(s)
                }
                r && null != e.trailingComments && bi(t, e.trailingComments, i, s)
            },
            BlockStatement: Ai = function(e, t) {
                let i = t.indent.repeat(t.indentLevel++),
                    {
                        lineEnd: s,
                        writeComments: r
                    } = t,
                    n = i + t.indent;
                t.write("{");
                let a = e.body;
                if (null != a && a.length > 0) {
                    t.write(s), r && null != e.comments && bi(t, e.comments, n, s);
                    let {
                        length: o
                    } = a;
                    for (let e = 0; e < o; e++) {
                        let i = a[e];
                        r && null != i.comments && bi(t, i.comments, n, s), t.write(n), this[i.type](i, t), t.write(s)
                    }
                    t.write(i)
                } else r && null != e.comments && (t.write(s), bi(t, e.comments, n, s), t.write(i));
                r && null != e.trailingComments && bi(t, e.trailingComments, n, s), t.write("}"), t.indentLevel--
            },
            ClassBody: Ai,
            StaticBlock(e, t) {
                t.write("static "), this.BlockStatement(e, t)
            },
            EmptyStatement(e, t) {
                t.write(";")
            },
            ExpressionStatement(e, t) {
                let i = t.expressionsPrecedence[e.expression.type];
                i === mi || 3 === i && "O" === e.expression.left.type[0] ? (t.write("("), this[e.expression.type](e.expression, t), t.write(")")) : this[e.expression.type](e.expression, t), t.write(";")
            },
            IfStatement(e, t) {
                t.write("if ("), this[e.test.type](e.test, t), t.write(") "), this[e.consequent.type](e.consequent, t), null != e.alternate && (t.write(" else "), this[e.alternate.type](e.alternate, t))
            },
            LabeledStatement(e, t) {
                this[e.label.type](e.label, t), t.write(": "), this[e.body.type](e.body, t)
            },
            BreakStatement(e, t) {
                t.write("break"), null != e.label && (t.write(" "), this[e.label.type](e.label, t)), t.write(";")
            },
            ContinueStatement(e, t) {
                t.write("continue"), null != e.label && (t.write(" "), this[e.label.type](e.label, t)), t.write(";")
            },
            WithStatement(e, t) {
                t.write("with ("), this[e.object.type](e.object, t), t.write(") "), this[e.body.type](e.body, t)
            },
            SwitchStatement(e, t) {
                let i = t.indent.repeat(t.indentLevel++),
                    {
                        lineEnd: s,
                        writeComments: r
                    } = t;
                t.indentLevel++;
                let n = i + t.indent,
                    a = n + t.indent;
                t.write("switch ("), this[e.discriminant.type](e.discriminant, t), t.write(") {" + s);
                let {
                    cases: o
                } = e, {
                    length: c
                } = o;
                for (let e = 0; e < c; e++) {
                    let i = o[e];
                    r && null != i.comments && bi(t, i.comments, n, s), i.test ? (t.write(n + "case "), this[i.test.type](i.test, t), t.write(":" + s)) : t.write(n + "default:" + s);
                    let {
                        consequent: c
                    } = i, {
                        length: h
                    } = c;
                    for (let e = 0; e < h; e++) {
                        let i = c[e];
                        r && null != i.comments && bi(t, i.comments, a, s), t.write(a), this[i.type](i, t), t.write(s)
                    }
                }
                t.indentLevel -= 2, t.write(i + "}")
            },
            ReturnStatement(e, t) {
                t.write("return"), e.argument && (t.write(" "), this[e.argument.type](e.argument, t)), t.write(";")
            },
            ThrowStatement(e, t) {
                t.write("throw "), this[e.argument.type](e.argument, t), t.write(";")
            },
            TryStatement(e, t) {
                if (t.write("try "), this[e.block.type](e.block, t), e.handler) {
                    let {
                        handler: i
                    } = e;
                    null == i.param ? t.write(" catch ") : (t.write(" catch ("), this[i.param.type](i.param, t), t.write(") ")), this[i.body.type](i.body, t)
                }
                e.finalizer && (t.write(" finally "), this[e.finalizer.type](e.finalizer, t))
            },
            WhileStatement(e, t) {
                t.write("while ("), this[e.test.type](e.test, t), t.write(") "), this[e.body.type](e.body, t)
            },
            DoWhileStatement(e, t) {
                t.write("do "), this[e.body.type](e.body, t), t.write(" while ("), this[e.test.type](e.test, t), t.write(");")
            },
            ForStatement(e, t) {
                if (t.write("for ("), null != e.init) {
                    let {
                        init: i
                    } = e;
                    "V" === i.type[0] ? _i(t, i) : this[i.type](i, t)
                }
                t.write("; "), e.test && this[e.test.type](e.test, t), t.write("; "), e.update && this[e.update.type](e.update, t), t.write(") "), this[e.body.type](e.body, t)
            },
            ForInStatement: ki = function(e, t) {
                t.write(`for ${e.await?"await ":""}(`);
                let {
                    left: i
                } = e;
                "V" === i.type[0] ? _i(t, i) : this[i.type](i, t), t.write("I" === e.type[3] ? " in " : " of "), this[e.right.type](e.right, t), t.write(") "), this[e.body.type](e.body, t)
            },
            ForOfStatement: ki,
            DebuggerStatement(e, t) {
                t.write("debugger;", e)
            },
            FunctionDeclaration: Ci = function(e, t) {
                t.write((e.async ? "async " : "") + (e.generator ? "function* " : "function ") + (e.id ? e.id.name : ""), e), xi(t, e.params), t.write(" "), this[e.body.type](e.body, t)
            },
            FunctionExpression: Ci,
            VariableDeclaration(e, t) {
                _i(t, e), t.write(";")
            },
            VariableDeclarator(e, t) {
                this[e.id.type](e.id, t), null != e.init && (t.write(" = "), this[e.init.type](e.init, t))
            },
            ClassDeclaration(e, t) {
                if (t.write("class " + (e.id ? `${e.id.name} ` : ""), e), e.superClass) {
                    t.write("extends ");
                    let {
                        superClass: i
                    } = e, {
                        type: s
                    } = i, r = t.expressionsPrecedence[s];
                    "C" === s[0] && "l" === s[1] && "E" === s[5] || !(r === mi || r < t.expressionsPrecedence.ClassExpression) ? this[i.type](i, t) : (t.write("("), this[e.superClass.type](i, t), t.write(")")), t.write(" ")
                }
                this.ClassBody(e.body, t)
            },
            ImportDeclaration(e, t) {
                t.write("import ");
                let {
                    specifiers: i
                } = e, {
                    length: s
                } = i, r = 0;
                if (s > 0) {
                    for (; r < s;) {
                        r > 0 && t.write(", ");
                        let e = i[r],
                            s = e.type[6];
                        if ("D" === s) t.write(e.local.name, e), r++;
                        else {
                            if ("N" !== s) break;
                            t.write("* as " + e.local.name, e), r++
                        }
                    }
                    if (r < s) {
                        for (t.write("{");;) {
                            let e = i[r],
                                {
                                    name: n
                                } = e.imported;
                            if (t.write(n, e), n !== e.local.name && t.write(" as " + e.local.name), !(++r < s)) break;
                            t.write(", ")
                        }
                        t.write("}")
                    }
                    t.write(" from ")
                }
                this.Literal(e.source, t), t.write(";")
            },
            ImportExpression(e, t) {
                t.write("import("), this[e.source.type](e.source, t), t.write(")")
            },
            ExportDefaultDeclaration(e, t) {
                t.write("export default "), this[e.declaration.type](e.declaration, t), null != t.expressionsPrecedence[e.declaration.type] && "F" !== e.declaration.type[0] && t.write(";")
            },
            ExportNamedDeclaration(e, t) {
                if (t.write("export "), e.declaration) this[e.declaration.type](e.declaration, t);
                else {
                    t.write("{");
                    let {
                        specifiers: i
                    } = e, {
                        length: s
                    } = i;
                    if (s > 0)
                        for (let e = 0;;) {
                            let r = i[e],
                                {
                                    name: n
                                } = r.local;
                            if (t.write(n, r), n !== r.exported.name && t.write(" as " + r.exported.name), !(++e < s)) break;
                            t.write(", ")
                        }
                    t.write("}"), e.source && (t.write(" from "), this.Literal(e.source, t)), t.write(";")
                }
            },
            ExportAllDeclaration(e, t) {
                null != e.exported ? t.write("export * as " + e.exported.name + " from ") : t.write("export * from "), this.Literal(e.source, t), t.write(";")
            },
            MethodDefinition(e, t) {
                e.static && t.write("static ");
                let i = e.kind[0];
                ("g" === i || "s" === i) && t.write(e.kind + " "), e.value.async && t.write("async "), e.value.generator && t.write("*"), e.computed ? (t.write("["), this[e.key.type](e.key, t), t.write("]")) : this[e.key.type](e.key, t), xi(t, e.value.params), t.write(" "), this[e.value.body.type](e.value.body, t)
            },
            ClassExpression(e, t) {
                this.ClassDeclaration(e, t)
            },
            ArrowFunctionExpression(e, t) {
                t.write(e.async ? "async " : "", e);
                let {
                    params: i
                } = e;
                null != i && (1 === i.length && "I" === i[0].type[0] ? t.write(i[0].name, i[0]) : xi(t, e.params)), t.write(" => "), "O" === e.body.type[0] ? (t.write("("), this.ObjectExpression(e.body, t), t.write(")")) : this[e.body.type](e.body, t)
            },
            ThisExpression(e, t) {
                t.write("this", e)
            },
            Super(e, t) {
                t.write("super", e)
            },
            RestElement: Ei = function(e, t) {
                t.write("..."), this[e.argument.type](e.argument, t)
            },
            SpreadElement: Ei,
            YieldExpression(e, t) {
                t.write(e.delegate ? "yield*" : "yield"), e.argument && (t.write(" "), this[e.argument.type](e.argument, t))
            },
            AwaitExpression(e, t) {
                t.write("await ", e), vi(t, e.argument, e)
            },
            TemplateLiteral(e, t) {
                let {
                    quasis: i,
                    expressions: s
                } = e;
                t.write("`");
                let {
                    length: r
                } = s;
                for (let e = 0; e < r; e++) {
                    let r = s[e],
                        n = i[e];
                    t.write(n.value.raw, n), t.write("${"), this[r.type](r, t), t.write("}")
                }
                let n = i[i.length - 1];
                t.write(n.value.raw, n), t.write("`")
            },
            TemplateElement(e, t) {
                t.write(e.value.raw, e)
            },
            TaggedTemplateExpression(e, t) {
                vi(t, e.tag, e), this[e.quasi.type](e.quasi, t)
            },
            ArrayExpression: Ii = function(e, t) {
                if (t.write("["), e.elements.length > 0) {
                    let {
                        elements: i
                    } = e, {
                        length: s
                    } = i;
                    for (let e = 0;;) {
                        let r = i[e];
                        if (null != r && this[r.type](r, t), !(++e < s)) {
                            null == r && t.write(", ");
                            break
                        }
                        t.write(", ")
                    }
                }
                t.write("]")
            },
            ArrayPattern: Ii,
            ObjectExpression(e, t) {
                let i = t.indent.repeat(t.indentLevel++),
                    {
                        lineEnd: s,
                        writeComments: r
                    } = t,
                    n = i + t.indent;
                if (t.write("{"), e.properties.length > 0) {
                    t.write(s), r && null != e.comments && bi(t, e.comments, n, s);
                    let a = "," + s,
                        {
                            properties: o
                        } = e,
                        {
                            length: c
                        } = o;
                    for (let e = 0;;) {
                        let i = o[e];
                        if (r && null != i.comments && bi(t, i.comments, n, s), t.write(n), this[i.type](i, t), !(++e < c)) break;
                        t.write(a)
                    }
                    t.write(s), r && null != e.trailingComments && bi(t, e.trailingComments, n, s), t.write(i + "}")
                } else r ? null != e.comments ? (t.write(s), bi(t, e.comments, n, s), null != e.trailingComments && bi(t, e.trailingComments, n, s), t.write(i + "}")) : null != e.trailingComments ? (t.write(s), bi(t, e.trailingComments, n, s), t.write(i + "}")) : t.write("}") : t.write("}");
                t.indentLevel--
            },
            Property(e, t) {
                e.method || "i" !== e.kind[0] ? this.MethodDefinition(e, t) : (e.shorthand || (e.computed ? (t.write("["), this[e.key.type](e.key, t), t.write("]")) : this[e.key.type](e.key, t), t.write(": ")), this[e.value.type](e.value, t))
            },
            PropertyDefinition(e, t) {
                e.static && t.write("static "), e.computed && t.write("["), this[e.key.type](e.key, t), e.computed && t.write("]"), null != e.value ? (t.write(" = "), this[e.value.type](e.value, t), t.write(";")) : "F" !== e.key.type[0] && t.write(";")
            },
            ObjectPattern(e, t) {
                if (t.write("{"), e.properties.length > 0) {
                    let {
                        properties: i
                    } = e, {
                        length: s
                    } = i;
                    for (let e = 0; this[i[e].type](i[e], t), ++e < s;) t.write(", ")
                }
                t.write("}")
            },
            SequenceExpression(e, t) {
                xi(t, e.expressions)
            },
            UnaryExpression(e, t) {
                if (e.prefix) {
                    let {
                        operator: i,
                        argument: s,
                        argument: {
                            type: r
                        }
                    } = e;
                    t.write(i);
                    let n = yi(t, s, e);
                    !n && (i.length > 1 || "U" === r[0] && ("n" === r[1] || "p" === r[1]) && s.prefix && s.operator[0] === i && ("+" === i || "-" === i)) && t.write(" "), n ? (t.write(i.length > 1 ? " (" : "("), this[r](s, t), t.write(")")) : this[r](s, t)
                } else this[e.argument.type](e.argument, t), t.write(e.operator)
            },
            UpdateExpression(e, t) {
                e.prefix ? (t.write(e.operator), this[e.argument.type](e.argument, t)) : (this[e.argument.type](e.argument, t), t.write(e.operator))
            },
            AssignmentExpression(e, t) {
                this[e.left.type](e.left, t), t.write(" " + e.operator + " "), this[e.right.type](e.right, t)
            },
            AssignmentPattern(e, t) {
                this[e.left.type](e.left, t), t.write(" = "), this[e.right.type](e.right, t)
            },
            BinaryExpression: Si = function(e, t) {
                let i = "in" === e.operator;
                i && t.write("("), vi(t, e.left, e, !1), t.write(" " + e.operator + " "), vi(t, e.right, e, !0), i && t.write(")")
            },
            LogicalExpression: Si,
            ConditionalExpression(e, t) {
                let {
                    test: i
                } = e, s = t.expressionsPrecedence[i.type];
                s === mi || s <= t.expressionsPrecedence.ConditionalExpression ? (t.write("("), this[i.type](i, t), t.write(")")) : this[i.type](i, t), t.write(" ? "), this[e.consequent.type](e.consequent, t), t.write(" : "), this[e.alternate.type](e.alternate, t)
            },
            NewExpression(e, t) {
                t.write("new ");
                let i = t.expressionsPrecedence[e.callee.type];
                i === mi || i < t.expressionsPrecedence.CallExpression || function(e) {
                    let t = e;
                    for (; null != t;) {
                        let {
                            type: e
                        } = t;
                        if ("C" === e[0] && "a" === e[1]) return !0;
                        if ("M" !== e[0] || "e" !== e[1] || "m" !== e[2]) return !1;
                        t = t.object
                    }
                }(e.callee) ? (t.write("("), this[e.callee.type](e.callee, t), t.write(")")) : this[e.callee.type](e.callee, t), xi(t, e.arguments)
            },
            CallExpression(e, t) {
                let i = t.expressionsPrecedence[e.callee.type];
                i === mi || i < t.expressionsPrecedence.CallExpression ? (t.write("("), this[e.callee.type](e.callee, t), t.write(")")) : this[e.callee.type](e.callee, t), e.optional && t.write("?."), xi(t, e.arguments)
            },
            ChainExpression(e, t) {
                this[e.expression.type](e.expression, t)
            },
            MemberExpression(e, t) {
                let i = t.expressionsPrecedence[e.object.type];
                i === mi || i < t.expressionsPrecedence.MemberExpression ? (t.write("("), this[e.object.type](e.object, t), t.write(")")) : this[e.object.type](e.object, t), e.computed ? (e.optional && t.write("?."), t.write("["), this[e.property.type](e.property, t), t.write("]")) : (e.optional ? t.write("?.") : t.write("."), this[e.property.type](e.property, t))
            },
            MetaProperty(e, t) {
                t.write(e.meta.name + "." + e.property.name, e)
            },
            Identifier(e, t) {
                t.write(e.name, e)
            },
            PrivateIdentifier(e, t) {
                t.write(`#${e.name}`, e)
            },
            Literal(e, t) {
                null != e.raw ? t.write(e.raw, e) : null != e.regex ? this.RegExpLiteral(e, t) : null != e.bigint ? t.write(e.bigint + "n", e) : t.write(di(e.value), e)
            },
            RegExpLiteral(e, t) {
                let {
                    regex: i
                } = e;
                t.write(`/${i.pattern}/${i.flags}`, e)
            }
        },
        Ni = {},
        Li = class {
            constructor(e) {
                let t = e ? ? Ni;
                this.output = "", null != t.output ? (this.output = t.output, this.write = this.writeToStream) : this.output = "", this.generator = null != t.generator ? t.generator : Pi, this.expressionsPrecedence = null != t.expressionsPrecedence ? t.expressionsPrecedence : gi, this.indent = null != t.indent ? t.indent : "  ", this.lineEnd = null != t.lineEnd ? t.lineEnd : "\n", this.indentLevel = null != t.startingIndentLevel ? t.startingIndentLevel : 0, this.writeComments = !!t.comments && t.comments, null != t.sourceMap && (this.write = null == t.output ? this.writeAndMap : this.writeToStreamAndMap, this.sourceMap = t.sourceMap, this.line = 1, this.column = 0, this.lineEndSize = this.lineEnd.split("\n").length - 1, this.mapping = {
                    original: null,
                    generated: this,
                    name: void 0,
                    source: t.sourceMap.file || t.sourceMap._file
                })
            }
            write(e) {
                this.output += e
            }
            writeToStream(e) {
                this.output.write(e)
            }
            writeAndMap(e, t) {
                this.output += e, this.map(e, t)
            }
            writeToStreamAndMap(e, t) {
                this.output.write(e), this.map(e, t)
            }
            map(e, t) {
                if (null != t) {
                    let {
                        type: i
                    } = t;
                    if ("L" === i[0] && "n" === i[2]) return this.column = 0, void this.line++;
                    if (null != t.loc) {
                        let {
                            mapping: e
                        } = this;
                        e.original = t.loc.start, e.name = t.name, this.sourceMap.addMapping(e)
                    }
                    if ("T" === i[0] && "E" === i[8] || "L" === i[0] && "i" === i[1] && "string" == typeof t.value) {
                        let {
                            length: t
                        } = e, {
                            column: i,
                            line: s
                        } = this;
                        for (let r = 0; r < t; r++) "\n" === e[r] ? (i = 0, s++) : i++;
                        return this.column = i, void(this.line = s)
                    }
                }
                let {
                    length: i
                } = e, {
                    lineEnd: s
                } = this;
                i > 0 && (this.lineEndSize > 0 && (1 === s.length ? e[i - 1] === s : e.endsWith(s)) ? (this.line += this.lineEndSize, this.column = 0) : this.column += i)
            }
            toString() {
                return this.output
            }
        };

    function Ti(e, t) {
        let i = new Li(t);
        return i.generator[e.type](e, i), i.output
    }
    var Ri = class {
        constructor(e) {
            this.mime = _, this.idb = C, this.path = k, this.acorn = {
                parse: Rt
            }, this.bare = {
                createBareClient: li,
                BareClient: hi
            }, this.base64 = {
                encode: btoa,
                decode: atob
            }, this.estree = {
                generate: Ti
            }, this.cookie = pi, this.setCookieParser = ui.parse, this.ctx = e
        }
    };

    function Vi(e, t, i, s, r = "", n = !1, a = "") {
        if (self.__dynamic$config) var o = "development" == self.__dynamic$config.mode;
        else o = !1;
        if (n) {
            var c = [{
                nodeName: "script",
                tagName: "script",
                namespaceURI: "http://www.w3.org/1999/xhtml",
                childNodes: [],
                attrs: [{
                    name: "src",
                    value: e + (o ? "?" + Math.floor(89999 * Math.random() + 1e4) : "")
                }]
            }, {
                nodeName: "script",
                tagName: "script",
                namespaceURI: "http://www.w3.org/1999/xhtml",
                childNodes: [],
                attrs: [{
                    name: "src",
                    value: t + (o ? "?" + Math.floor(89999 * Math.random() + 1e4) : "")
                }]
            }];
            return this.ctx.config.assets.files.inject && c.unshift({
                nodeName: "script",
                tagName: "script",
                namespaceURI: "http://www.w3.org/1999/xhtml",
                childNodes: [],
                attrs: [{
                    name: "src",
                    value: this.ctx.config.assets.files.inject + (o ? "?" + Math.floor(89999 * Math.random() + 1e4) : "")
                }]
            }), s && c.unshift({
                nodeName: "script",
                tagName: "script",
                namespaceURI: "http://www.w3.org/1999/xhtml",
                childNodes: [],
                attrs: [{
                    name: "src",
                    value: "data:application/javascript;base64," + btoa(`self.__dynamic$cookies = atob("${btoa(s)}");document.currentScript?.remove();`)
                }]
            }), r && c.unshift({
                nodeName: "script",
                tagName: "script",
                namespaceURI: "http://www.w3.org/1999/xhtml",
                childNodes: [],
                attrs: [{
                    name: "src",
                    value: "data:application/javascript;base64," + btoa(r + ";document.currentScript?.remove();")
                }]
            }), a && c.unshift({
                nodeName: "script",
                tagName: "script",
                namespaceURI: "http://www.w3.org/1999/xhtml",
                childNodes: [],
                attrs: [{
                    name: "src",
                    value: "data:application/javascript;base64," + btoa(a + ";document.currentScript?.remove();")
                }]
            }), c
        }
        var h = [`<script src="${t+(o?"?"+Math.floor(89999*Math.random()+1e4):"")}"><\/script>`, `<script src="${e+(o?"?"+Math.floor(89999*Math.random()+1e4):"")}"><\/script>`];
        return this.ctx.config.assets.files.inject && h.unshift(`<script src="${this.ctx.config.assets.files.inject+(o?"?"+Math.floor(89999*Math.random()+1e4):"")}"><\/script>`), s && h.unshift(`<script src="${"data:application/javascript;base64,"+btoa(`self.__dynamic$cookies = atob("${btoa(s)}");document.currentScript?.remove();`)}"><\/script>`), r && h.unshift(`<script src="${"data:application/javascript;base64,"+btoa(r+";document.currentScript?.remove();")}"><\/script>`), a && h.unshift(`<script src="${"data:application/javascript;base64,"+btoa(a+";document.currentScript?.remove();")}"><\/script>`), h
    }
    var Oi = class {
            constructor(e) {
                this.generateHead = Vi, this.config = [{
                    elements: "all",
                    tags: ["style"],
                    action: "css"
                }, {
                    elements: ["script", "iframe", "embed", "input", "track", "media", "source", "img", "a", "link", "area", "form", "object"],
                    tags: ["src", "href", "action", "data"],
                    action: "url"
                }, {
                    elements: ["source", "img"],
                    tags: ["srcset"],
                    action: "srcset"
                }, {
                    elements: ["script", "link"],
                    tags: ["integrity"],
                    action: "rewrite",
                    new: "nointegrity"
                }, {
                    elements: ["script", "link"],
                    tags: ["nonce"],
                    action: "rewrite",
                    new: "nononce"
                }, {
                    elements: ["meta"],
                    tags: ["http-equiv"],
                    action: "http-equiv"
                }, {
                    elements: ["iframe"],
                    tags: ["srcdoc"],
                    action: "html"
                }, {
                    elements: ["link"],
                    tags: ["imagesrcset"],
                    action: "srcset"
                }, {
                    elements: "all",
                    tags: ["onclick"],
                    action: "js"
                }], this.ctx = e.ctx
            }
            generateRedirect(e) {
                return `\n<HTML><HEAD><meta http-equiv="content-type" content="text/html;charset=utf-8">\n<TITLE>301 Moved</TITLE></HEAD><BODY>\n<H1>301 Moved</H1>\nThe document has moved\n<A HREF="${e}">here</A>.\n</BODY></HTML>\n    `
            }
            iterate(e, t) {
                ! function i(s = e) {
                    for (var r = 0; r < s.childNodes.length; r++) t(s.childNodes[r]), s.childNodes[r].childNodes && s.childNodes[r].childNodes.length && i(s.childNodes[r])
                }(e)
            }
            rewrite(e, t, i = []) {
                return Array.isArray(e) && (e = e[0]), e && ((e = e.toString()).match(/<\!DOCTYPE[^>]*>/gi) || (e = "<!DOCTYPE html>" + e), e.replace(/(<!DOCTYPE html>|<html(.*?)>)/im, `$1${i.join("")}\n`).replace(/<(script|link)\b[^>]*>/g, ((e, t) => e.replace(/\snonce\s*=\s*"[^"]*"/, (e => e.replace("nonce", "nononce"))).replace(/\sintegrity\s*=\s*"[^"]*"/, (e => e.replace("integrity", "nointegrity"))))))
            }
        },
        Di = class {
            constructor(e) {
                this.ctx = e.ctx
            }
            rewrite(e, t, i = {}) {
                return e && e.toString().replace(/(?:@import\s?|url\(?)['"]?(.*?)['")]/gim, ((...e) => {
                    try {
                        return e[0].replace(e[3], this.ctx.url.encode(e[3], t))
                    } catch {
                        return e[0]
                    }
                }))
            }
        };

    function ji(e, t) {
        "object" == typeof e && t && function e(t, i, s) {
            if ("object" == typeof t && s) {
                t.parent = i, s(t, i, s);
                for (let i in t) "parent" !== i && (Array.isArray(t[i]) ? t[i].forEach((i => {
                    i && e(i, t, s)
                })) : t[i] && e(t[i], t, s));
                "function" == typeof t.iterateEnd && t.iterateEnd()
            }
        }(e, null, t)
    }

    function Mi(e, t = {}, i, s) {
        var r = this.ctx.modules.acorn.parse(e.toString(), {
            sourceType: t.module ? "module" : "script",
            allowImportExportEverywhere: !0,
            allowAwaitOutsideFunction: !0,
            allowReturnOutsideFunction: !0,
            ecmaVersion: "latest",
            preserveParens: !1,
            loose: !0,
            allowReserved: !0
        });
        return this.iterate(r, ((e, r = null) => {
            this.emit(e, e.type, r, i, s, t)
        })), e = this.ctx.modules.estree.generate(r)
    }

    function Bi(e, t = {}) {
        Object.entries({
            type: "CallExpression",
            callee: {
                type: "MemberExpression",
                object: {
                    type: "Identifier",
                    name: "self"
                },
                property: {
                    type: "Identifier",
                    name: "__dynamic$message"
                }
            },
            arguments: [e.object || e, {
                type: "Identifier",
                name: "self",
                __dynamic: !0
            }]
        }).forEach((([t, i]) => e[t] = i))
    }

    function Ui(e, t = {}) {
        e.__dynamic || e.arguments.length && (e.arguments = [{
            type: "CallExpression",
            callee: {
                type: "Identifier",
                name: "__dynamic$wrapEval",
                __dynamic: !0
            },
            arguments: e.arguments,
            __dynamic: !0
        }], e.__dynamic = !0)
    }
    var $i = function(e, t, i = {}, s = {}, r = {}, n = {}) {
            if (!e.__dynamic) {
                switch (t) {
                    case "Identifier":
                        ! function(e, t = {}) {
                            if ("string" != typeof e.name) return !1;
                            if (!0 !== e.__dynamic) {
                                if (!["parent", "top", "postMessage", "opener", "window", "self", "globalThis", "parent", "location"].includes(e.name)) return !1;
                                if (("CallExpression" != t.type || t.callee != e) && ("MemberExpression" != t.type || t.object === e || ["document", "window", "self", "globalThis"].includes(t.object.name)) && "FunctionDeclaration" != t.type && "VariableDeclaration" != t.type && ("VariableDeclarator" != t.type || t.id != e) && "LabeledStatement" != t.type && ("Property" != t.type || t.key != e) && ("ArrowFunctionExpression" != t.type || !t.params.includes(e)) && ("FunctionExpression" != t.type || !t.params.includes(e)) && ("FunctionExpression" != t.type || t.id != e) && ("CatchClause" != t.type || t.param != e) && "ContinueStatement" != t.type && "BreakStatement" != t.type && ("AssignmentExpression" != t.type || t.left != e) && "UpdateExpression" != t.type && "UpdateExpression" != t.type && ("ForInStatement" != t.type || t.left != e) && ("MethodDefinition" != t.type || t.key != e) && ("AssignmentPattern" != t.type || t.left != e) && "NewExpression" != t.type && "NewExpression" != t ? .parent ? .type && ("UnaryExpression" != t.type || t.argument != e) && ("Property" != t.type || 1 != t.shorthand || t.value != e)) {
                                    if ("__dynamic" == e.name) return e.name = "undefined";
                                    if ("eval" == e.name && t.right !== e) return e.name = "__dynamic$eval";
                                    e.name = `dg$(${e.name})`
                                }
                            }
                        }(e, i);
                        break;
                    case "MemberExpression":
                        ! function(e, t = {}, i = {}) {
                            if (e.object.name += "", "AssignmentExpression" !== t.type && t.left !== e) {
                                if ("postMessage" == e.property.value && "CallExpression" == t.type && t.callee == e) return Bi(e, t);
                                if ("postMessage" == e.object.value && "CallExpression" == t.type && t.callee == e) return Bi(e, t);
                                if (("postMessage" == e.property.name || "postMessage" == e.object.name) && "Super" !== e.object.type) {
                                    var s = e.object ? .name;
                                    return e.type = "CallExpression", e.callee = {
                                        type: "Identifier",
                                        name: "__dynamic$message"
                                    }, e.arguments = [{
                                        type: "Identifier",
                                        name: s
                                    }, {
                                        type: "Identifier",
                                        name: "self",
                                        __dynamic: !0
                                    }], void("CallExpression" == t.type && (t.arguments = t.arguments))
                                }
                            }
                            if ("eval" == e.property.name && (e.property.name = "__dynamic$eval"), "eval" == e.object.name && (e.object.name = "__dynamic$eval"), "worker" !== i.destination && ("window" == e.property.name && "top" != e.object.name && ("self" == e.object.name || "globalThis" == e.object.name) && "NewExpression" !== t.type && ("CallExpression" !== t.type || "CallExpression" == t.type && e !== t.callee) && (e.property.name = "__dynamic$window"), "top" == e.object.name && "NewExpression" !== t.type && ("CallExpression" !== t.type || "CallExpression" == t.type && e !== t.callee) && (e.object.name = "top.__dynamic$window"), "top" == e.property.name && ("self" == e.object.name || "globalThis" == e.object.name) && "NewExpression" !== t.type && ("CallExpression" !== t.type || "CallExpression" == t.type && e !== t.callee) && (e.property.name = "top.__dynamic$window"), "NewExpression" !== t.type && ("CallExpression" !== t.type || "CallExpression" == t.type && e !== t.callee) && ("window" == e.object.name && (e.object = {
                                    type: "CallExpression",
                                    callee: {
                                        type: "Identifier",
                                        name: "dg$"
                                    },
                                    arguments: [e.object],
                                    __dynamic: !0
                                }), "parent" == e.object.name && (e.object = {
                                    type: "CallExpression",
                                    callee: {
                                        type: "Identifier",
                                        name: "dg$"
                                    },
                                    arguments: [e.object],
                                    __dynamic: !0
                                }), "__dynamic" == e.property.name && (e.property.name = "undefined"), "self" == e.object.name && (e.object = {
                                    type: "CallExpression",
                                    callee: {
                                        type: "Identifier",
                                        name: "dg$"
                                    },
                                    arguments: [e.object],
                                    __dynamic: !0
                                }), "document" == e.object.name && (e.object = {
                                    type: "CallExpression",
                                    callee: {
                                        type: "Identifier",
                                        name: "dg$"
                                    },
                                    arguments: [e.object],
                                    __dynamic: !0
                                }), "globalThis" == e.object.name && (e.object = {
                                    type: "CallExpression",
                                    callee: {
                                        type: "Identifier",
                                        name: "dg$"
                                    },
                                    arguments: [e.object],
                                    __dynamic: !0
                                })), "location" == e.object.name && (e.object = {
                                    type: "CallExpression",
                                    callee: {
                                        type: "Identifier",
                                        name: "dg$"
                                    },
                                    arguments: [e.object],
                                    __dynamic: !0
                                }), "location" == e.property.name && "BinaryExpression" !== t.type && "AssignmentExpression" !== t.type)) {
                                e.property.__dynamic = !0, e.__dynamic = !0;
                                let t = Object.assign({}, e);
                                e.type = "CallExpression", e.callee = {
                                    type: "Identifier",
                                    name: "dg$",
                                    __dynamic: !0
                                }, e.arguments = [t], e.__dynamic = !0
                            }
                            e.computed && "worker" !== i.destination && (e.property = {
                                type: "CallExpression",
                                callee: {
                                    type: "Identifier",
                                    name: "dp$"
                                },
                                arguments: [e.property],
                                __dynamic: !0
                            })
                        }(e, i, n);
                        break;
                    case "Literal":
                        ! function(e, t = {}) {
                            if (!(e.value instanceof String && ("__dynamic" == e.value && (e.value = "undefined"), ["location", "parent", "top", "postMessage"].includes(e.value)))) return !1;
                            "postMessage" == e.value && "AssignmentExpression" != t.type && t.left != e && Bi(e, t), "location" == e.value && (e.value = "__dynamic$location"), "__dynamic" == e.value && (e.value = "undefined"), "eval" == e.value && (e.value = "__dynamic$eval")
                        }(e, i);
                        break;
                    case "CallExpression":
                        ! function(e, t = {}) {
                            if ("AssignmentExpression" != t.type || t.left != e) {
                                if ("Identifier" == e.callee.type) {
                                    if ("postMessage" == e.callee.name) {
                                        let t = "undefined";
                                        return e.callee.type = "CallExpression", e.callee.callee = {
                                            type: "Identifier",
                                            name: "__dynamic$message"
                                        }, void(e.callee.arguments = [{
                                            type: "Identifier",
                                            name: t
                                        }, {
                                            type: "Identifier",
                                            name: "self",
                                            __dynamic: !0
                                        }])
                                    }
                                    "eval" == e.callee.name && Ui(e)
                                }
                                if ("MemberExpression" == e.callee.type) {
                                    if ("postMessage" == e.callee.property.name && "Super" !== e.callee.object.type) {
                                        let t = e.callee.object;
                                        return e.callee.type = "CallExpression", e.callee.callee = {
                                            type: "Identifier",
                                            name: "__dynamic$message"
                                        }, void(e.callee.arguments = [t, {
                                            type: "Identifier",
                                            name: "self",
                                            __dynamic: !0
                                        }])
                                    }
                                    "eval" == e.callee.object.name && Ui(e)
                                }
                                e.arguments.length > 0 && e.arguments.length
                            }
                        }(e, i);
                        break;
                    case "AssignmentExpression":
                        ! function(e, t = {}) {
                            if ("Identifier" == e.left.type) {
                                if (!0 === e.left.__dynamic) return;
                                if ("location" == e.left.name) {
                                    var i = structuredClone(e.left),
                                        s = structuredClone(e.right);
                                    e.right.type = "CallExpression", e.right.callee = {
                                        type: "Identifier",
                                        name: "ds$"
                                    }, e.right.arguments = [i, s]
                                }
                            }
                        }(e, i);
                        break;
                    case "ThisExpression":
                    case "CatchClause":
                    default:
                        break;
                    case "Property":
                        ! function(e, t = {}) {
                            "ObjectPattern" != e.parent.type && "AssignmentExpression" != e.parent ? .parent ? .type && (e.shorthand = !1)
                        }(e, i);
                        break;
                    case "VariableDeclarator":
                        ! function(e, t = {}) {
                            if ("Identifier" !== e.id.type) return !1;
                            !0 !== e.id.__dynamic && e.id.name
                        }(e, i)
                }! function(e, t = {}, i = {}, s = {}) {
                    if ("Literal" == e.type && ("ImportDeclaration" == t.type || "ExportNamedDeclaration" == t.type || "ExportAllDeclaration" == t.type)) {
                        var r = e.value + "";
                        e.value = i.url.encode(e.value, s.meta), e.raw = e.raw.replace(r, e.value), e.__dynamic = !0
                    }
                    "ImportExpression" == e.type && (e.source = {
                        type: "CallExpression",
                        callee: {
                            type: "Identifier",
                            name: "__dynamic$import"
                        },
                        arguments: [e.source, {
                            type: "Literal",
                            __dynamic: !0,
                            value: i.meta.href
                        }]
                    }, e.__dynamic = !0)
                }(e, i, s, r)
            }
        },
        Fi = class {
            constructor(e) {
                this.iterate = ji, this.process = Mi, this.emit = $i, this.ctx = e.ctx
            }
            rewrite(e, t = {}, i = !0, s = {}) {
                if (!e || e instanceof Object || (e = e.toString()).includes("/* dynamic.js */")) return e;
                e = `/* dynamic.js */ \n\n${e}`;
                try {
                    try {
                        e = this.process(e, t, {
                            module: !0,
                            ...this.ctx
                        }, s)
                    } catch {
                        e = this.process(e, t, {
                            module: !1,
                            ...this.ctx
                        }, s)
                    }
                } catch {}
                return i && (e = `\n      if (typeof self !== undefined && typeof self.importScripts == 'function' && typeof self.__dynamic == 'undefined') importScripts('/assets/history/config.js?v=2025-04-15', '/assets/history/handler.js?v=2025-04-15'+Math.floor(Math.random()*(99999-10000)+10000));\n\n      ${e}`), e
            }
        },
        Hi = class {
            constructor(e) {
                this.config = {
                    rewrite: [
                        ["icons", "urlit"],
                        ["name", " - Dynamic"],
                        ["start_url", "url"],
                        ["scope", "url"],
                        ["short_name", " - Dynamic"],
                        ["shortcuts", "urlev"]
                    ],
                    delete: ["serviceworker"]
                }, this.ctx = e.ctx
            }
            rewrite(e, t) {
                let i = JSON.parse(e);
                for (let e in this.config)
                    if ("rewrite" == e)
                        for (var [s, r] of this.config[e])
                            if ("urlit" == r && i[s])
                                for (var n = 0; n < i[s].length; n++) i[s][n].src = this.ctx.url.encode(i[s][n].src, t);
                            else if ("urlev" == r && i[s])
                    for (n = 0; n < i[s].length; n++) i[s][n].url = this.ctx.url.encode(i[s][n].url, t);
                else "url" == r && i[s] ? i[s] = this.ctx.url.encode(i[s], t) : "url" == r || "urlit" == r || "urlev" == r || (i[s] = i[s] + r);
                else if ("delete" == e)
                    for (var s of this.config[e]) i[s] && delete i[s];
                return JSON.stringify(i)
            }
        },
        Wi = {
            encode: (e, t) => e && e.toString() ? e.split(", ").map((e => e.split(" ").map(((e, i) => 0 == i ? t.url.encode(e, t.baseURL || t.meta) : e)).join(" "))).join(", ") : e,
            decode: e => e
        },
        qi = class {
            constructor(e) {
                this.ctx = e, this.html = new Oi(this), this.srcset = Wi, this.js = new Fi(this), this.css = new Di(this), this.man = new Hi(this)
            }
        };
    async function Gi(e) {
        var t;
        if ("GET" === e.method) {
            t = new URL(e.url).searchParams.get("url")
        } else {
            if ("POST" !== e.method) return new Response("Error: Invalid method", {
                status: 405
            });
            null === (t = (await e.formData()).get("url")) && (t = new URL(e.url).searchParams.get("url"));
            if (!t) return new Response("Error: Invalid or Unfound url", {
                status: 400
            })
        }
        return new Response("", {
            status: 301,
            headers: {
                location: location.origin + this.ctx.config.prefix + this.ctx.encoding.encode(t)
            }
        })
    }

    function zi({
        url: e
    }) {
        return !e.toString().substr(location.origin.length, (this.ctx.config.prefix + "route").length).startsWith(this.ctx.config.prefix + "route")
    }

    function Ki({
        url: e
    }) {
        return !e.toString().substr(location.origin.length, this.ctx.config.prefix.length).startsWith(this.ctx.config.prefix)
    }
    async function Qi(e, t, i) {
        for (let r in e)
            if (-1 !== this.ctx.headers.csp.indexOf(r.toLowerCase()) && delete e[r], "location" != r.toLowerCase())
                if ("set-cookie" !== r.toLowerCase());
                else {
                    for await (var s of (Array.isArray(e[r]) ? e[r] = e[r].map((e => this.ctx.modules.setCookieParser(e, {
                        decodeValues: !1
                    })[0])) : e[r] = this.ctx.modules.setCookieParser(e[r], {
                        decodeValues: !1
                    }), e[r])) await i.set(t.host, this.ctx.modules.cookie.serialize(s.name, s.value, { ...s,
                        encode: e => e
                    }));
                    delete e[r]
                }
        else e[r] = this.ctx.url.encode(e[r], t);
        return new Headers(e)
    }

    function Yi(e, t, i, s) {
        let {
            referrer: r
        } = i;
        if (["origin", "Origin", "host", "Host", "referer", "Referer"].forEach((t => {
                e[t] && delete e[t]
            })), e.Origin = `${t.protocol}//${t.host}${t.port?":"+t.port:""}`, e.Host = t.host + (t.port ? ":" + t.port : ""), e.Referer = t.href, "strict-origin-when-cross-origin" == i.referrerPolicy && (e.Referer = `${t.protocol}//${t.host}/`), "origin" == i.referrerPolicy && t.origin && (r = t.origin + "/"), s) {
            switch (i.credentials) {
                case "omit":
                default:
                    break;
                case "same-origin":
                    i.client && t.origin == i.client.__dynamic$location.origin && (e.Cookie = s), i.client || (e.Cookie = s);
                    break;
                case "include":
                    e.Cookie = s
            }
            e.Cookie = s
        }
        if (r && r != location.origin + "/") try {
            e.Referer = this.ctx.url.decode(r), "strict-origin-when-cross-origin" == i.referrerPolicy && (e.Referer = new URL(this.ctx.url.decode(r)).origin), e.Origin = new URL(this.ctx.url.decode(r)).origin
        } catch {}
        return i.client && (e.Origin = i.client.__dynamic$location.origin, e.Referer = i.client.__dynamic$location.href, "strict-origin-when-cross-origin" == i.referrerPolicy && (e.Referer = i.client.__dynamic$location.origin)), this.ctx.config.tab && this.ctx.config.tab.ua && (delete e["user-agent"], delete e["User-Agent"], e["user-agent"] = this.ctx.config.tab.ua), e["sec-fetch-dest"] = i.destination || "empty", e["sec-fetch-mode"] = i.mode || "cors", e["sec-fetch-site"] = i.client ? i.client.__dynamic$location.origin == t.origin ? i.client.__dynamic$location.port == t.port ? "same-origin" : "same-site" : "cross-origin" : "none", "navigate" == i.mode && (e["sec-fetch-site"] = "same-origin"), e["sec-fetch-user"] = "?1", new Headers(e)
    }

    function Ji(e) {
        return Object.assign(Object.create(Object.getPrototypeOf(e)), e)
    }

    function Zi(e) {
        try {
            if (new new Proxy(e, {
                    construct: () => ({})
                }), !Object.getOwnPropertyNames(e).includes("arguments")) throw new Error("");
            return !0
        } catch {
            return !1
        }
    }

    function Xi(e) {
        return e.url.toString().substr(location.origin.length, e.url.toString().length).startsWith(self.__dynamic$config.assets.prefix)
    }
    async function es(e) {
        let t;
        if ("development" !== self.__dynamic$config.mode) {
            var i = await caches.open("__dynamic$files");
            t = i && await i.match(e.url) || await fetch(e)
        } else t = await fetch(e);
        let s = await t.blob();
        return (e.url.startsWith(location.origin + "/assets/history/config.js?v=2025-04-15") || e.url.startsWith(location.origin + "/assets/history/client.js?v=2025-04-15")) && (s = new Blob([`${await s.text()}\nself.document?.currentScript?.remove();`], {
            type: "application/javascript"
        })), new Response(s, {
            headers: t.headers,
            status: t.status,
            statusText: t.statusText
        })
    }
    async function ts(e, t) {}
    var is = class {
        constructor(e) {
            this.rawHeaders = {}, this.headers = new Headers({}), this.status = 200, this.statusText = "OK", this.body = e
        }
        async blob() {
            return this.body
        }
        async text() {
            return await this.body.text()
        }
    };

    function ss(e) {
        var t = this.ctx.encoding;
        return t = "object" == typeof this.ctx.config.encoding ? { ...t,
            ...this.ctx.encoding
        } : { ...this.ctx.encoding[this.ctx.config.encoding]
        }, this.ctx.encoding = { ...this.ctx.encoding,
            ...t
        }, this.ctx.encoding
    }

    function rs(e, t, i) {
        if (!e.url.startsWith("http")) return e.url;
        let s = e.url.toString();
        return e.url.startsWith(location.origin) && (s = s.substr(self.location.origin.length)), s = new URL(s, new URL(t.__dynamic$location.href)).href, this.ctx.url.encode(s, i)
    }
    var ns = class {
        constructor(e) {
            this.route = Gi, this.routePath = zi, this.path = Ki, this.resHeader = Qi, this.reqHeader = Yi, this.clone = Ji, this.class = Zi, this.file = Xi, this.edit = es, this.error = ts, this.encode = ss, this.rewritePath = rs, this.about = is, this.ctx = e
        }
    };

    function as(e, t) {
        if (!e) return e;
        if ((e = new String(e).toString()).startsWith("about:blank")) return location.origin + this.ctx.config.prefix + e;
        if (!e.match(this.ctx.regex.ProtocolRegex) && e.match(/^([a-zA-Z0-9\-]+)\:\/\//g) || e.startsWith("chrome-extension://")) return e;
        if (e.startsWith("javascript:") && !e.startsWith("javascript:__dynamic$eval")) {
            let t = new URL(e);
            return `javascript:__dynamic$eval(${JSON.stringify(t.pathname)})`
        }
        e.match(this.ctx.regex.WeirdRegex) && ((i = this.ctx.regex.WeirdRegex.exec(e)) && (e = i[2]));
        if (e.startsWith(location.origin + this.ctx.config.prefix) || e.startsWith(this.ctx.config.prefix) || e.startsWith(location.origin + this.ctx.config.assets.prefix + "dynamic.") || e.match(this.ctx.regex.BypassRegex)) return e;
        if (e.match(this.ctx.regex.DataRegex)) {
            try {
                var i;
                if (i = this.ctx.regex.DataRegex.exec(e)) {
                    var [s, r, n, a, o] = i;
                    o = "base64" == a ? this.ctx.modules.base64.atob(decodeURIComponent(o)) : decodeURIComponent(o), r && ("text/html" == r ? o = this.ctx.rewrite.html.rewrite(o, t, this.ctx.rewrite.html.generateHead(location.origin + "/assets/history/client.js?v=2025-04-15", location.origin + "/assets/history/config.js?v=2025-04-15", "", `window.__dynamic$url = "${t.href}"; window.__dynamic$parentURL = "${location.href}";`)) : "text/css" == r ? o = this.ctx.rewrite.css.rewrite(o, t) : ("text/javascript" == r || "application/javascript" == r) && (o = this.ctx.rewrite.js.rewrite(o, t))), o = "base64" == a ? this.ctx.modules.base64.btoa(o) : encodeURIComponent(o), e = n ? a ? `data:${r};${n};${a},${o}` : `data:${r};${n},${o}` : a ? `data:${r};${a},${o}` : `data:${r},${o}`
                }
            } catch {}
            return e
        }
        return e = new String(e).toString(), t.href.match(this.ctx.regex.BypassRegex) && (e = new URL(e, new URL((this.ctx.parent.__dynamic || this.ctx).meta.href)).href), e = new URL(e, t.href), (this.ctx._location ? .origin || ("null" == location.origin ? location.ancestorOrigins[0] : location.origin)) + this.ctx.config.prefix + (this.ctx.encoding.encode(e.origin + e.pathname) + e.search + e.hash)
    }

    function os(e) {
        if (!e || (e = new String(e).toString()).match(this.ctx.regex.BypassRegex)) return e;
        var t = e.indexOf(this.ctx.config.prefix);
        if (-1 == t) return e;
        try {
            if (t = (e = new URL(e, new URL(self.location.origin)).href).indexOf(this.ctx.config.prefix), "about:blank" == e.slice(t + this.ctx.config.prefix.length).trim()) return "about:blank";
            var i = new URL(e).search + new URL(e).hash || "",
                s = new URL(this.ctx.encoding.decode(e.slice(t + this.ctx.config.prefix.length).replace("https://", "https:/").replace("https:/", "https://").split("?")[0]))
        } catch {
            return e
        }
        return e = s.origin + s.pathname + i + (new URL(e).search ? s.search.replace("?", "&") : s.search)
    }
    var cs = class {
        constructor(e) {
            this.encode = as, this.decode = os, this.ctx = e
        }
    };

    function hs(e) {
        for (var t in e = new URL(e.href)) this.ctx.meta[t] = e[t];
        return !0
    }
    var ls = class {
            constructor() {}
        },
        ps = class extends ls {
            constructor(e) {
                super(), this.load = hs, this.ctx = e
            }
        },
        us = class {
            constructor(e = "", t = new Request("")) {
                this.headers = new Headers({}), this.redirect = "manual", this.body = null, this.method = "GET", t.headers && (this.headers = t.headers), t.redirect && (this.redirect = t.redirect), t.body && (this.body = t.body), this.method = t.method || "GET", this.url = new String(e)
            }
            get init() {
                return {
                    headers: this.headers || new Headers({}),
                    redirect: this.redirect || "manual",
                    body: this.body || null,
                    method: this.method || "GET"
                }
            }
        },
        ds = class extends Response {
            constructor(e = "", t = new Response("")) {
                super(e, t), this.status = 200, this.statusText = "OK", this.headers = new Headers({}), this.body = e, t.status && (this.status = t.status), t.statusText && (this.statusText = t.statusText), t.headers && (this.headers = t.headers)
            }
            get init() {
                return {
                    headers: this.headers || new Headers({}),
                    statusText: this.statusText || 200,
                    body: this.body || new Blob([]),
                    status: this.statusText || "OK"
                }
            }
        },
        fs = class {
            constructor(e) {
                this.Request = us, this.Response = ds, this.ctx = e
            }
        },
        ms = /^(#|about:|mailto:|blob:|javascript:)/g,
        gs = /^data:([a-z\/A-Z0-9\-\+]+);?(charset\=[\-A-Za-z0-9]+)?;?(base64)?[;,]*(.*)/g,
        xs = /^([\/A-Za-z0-9\-%]+)(http[s]?:\/\/.*)/g,
        ys = class {
            constructor(e) {
                this.BypassRegex = ms, this.DataRegex = gs, this.WeirdRegex = xs, this.ctx = e
            }
        },
        vs = class {
            constructor(e) {
                this.ctx = e
            }
        };

    function ws(e, t = "") {
        return "text/css" === (this.ctx.modules.mime.contentType(t || e.pathname) || "text/css").split(";")[0]
    }

    function bs(e, t = "", i = "") {
        let s;
        return t || this.ctx.modules.mime.contentType(e.pathname) != e.pathname ? "text/html" === (this.ctx.modules.mime.contentType(t || e.pathname) || "text/html").split(";")[0] || i.trim().match(/\<\!(doctype|DOCTYPE) html\>/g) : i.trim().match(/<(html|script|body)[^>]*>/g) && (s = i.trim().indexOf((i.trim().match(/<(html|script|body)[^>]*>/g) || [])[0]), s > -1 && s < 100)
    }

    function _s(e, t = "") {
        if (e.pathname.endsWith(".js") && "text/plain" == t) return !0;
        var i = (this.ctx.modules.mime.contentType(t || e.pathname) || "application/javascript").split(";")[0];
        return "text/javascript" == i || "application/javascript" == i || "application/x-javascript" == i
    }
    var ks = class {
        constructor(e) {
            this.html = bs, this.js = _s, this.css = ws, this.ctx = e
        }
    };
    var Cs = {
            open: async () => M("__dynamic$cookies", 1, {
                async upgrade(e) {
                    await e.createObjectStore("__dynamic$cookies")
                }
            }),
            set: async (e, t, i) => {
                if ((t.domain && (e = t.domain), e.startsWith(".") && (e = e.slice(1)), t.expires) && new Date(t.expires) < new Date) return Cs.remove(e, t, i);
                return await (await i).put("__dynamic$cookies", function(e, t) {
                    return e || (e = []), e.find((e => e.name == t.name)) ? e[e.findIndex((e => e.name == t.name))] = {
                        name: t.name,
                        value: t.value,
                        expires: t.expires
                    } : e.push({
                        name: t.name,
                        value: t.value,
                        expires: t.expires
                    }), e
                }(await (await i).get("__dynamic$cookies", e), t), e), !0
            },
            get: async (e, t) => {
                var i = e.replace(/^(.*\.)?([^.]*\..*)$/g, "$2"),
                    s = await (await t).get("__dynamic$cookies", e) || [];
                if (e !== i && e !== "." + i) {
                    var r = await (await t).get("__dynamic$cookies", i);
                    if (r)
                        for (var {
                                name: n,
                                value: a,
                                expires: o
                            } of r) {
                            if (o)
                                if (new Date(o) <= new Date) {
                                    Cs.remove(e, r.find((e => e.name == n && e.value == a && e.expires == o)), t);
                                    continue
                                }
                            s.find((e => e.name == n && e.value == a)) || s.push({
                                name: n,
                                value: a,
                                expires: o || new Date(1e13)
                            })
                        }
                }
                return s
            },
            remove: async (e, t, i) => {
                t.domain && (e = t.domain), e.startsWith(".") && (e = e.slice(1));
                var s = await (await i).get("__dynamic$cookies", e);
                return !!s && (s = s.filter((e => e.name !== t.name)), await (await i).put("__dynamic$cookies", s, e), !0)
            },
            update: async (e, t) => {
                var i = e.replace(/^(.*\.)?([^.]*\..*)$/g, "$2"),
                    s = await (await t).get("__dynamic$cookies", i);
                if (s)
                    for (var {
                            name: r,
                            value: n,
                            expires: a
                        } of s)
                        if (a) {
                            if (new Date(a) <= new Date) {
                                Cs.remove(e, {
                                    name: r,
                                    value: n,
                                    expires: a
                                }, t);
                                continue
                            }
                        }
                return s
            }
        },
        Es = class {
            constructor(e) {
                this.db = Cs, this.ctx = e
            }
            async get(e) {
                return this._db || (this._db = this.db.open()), ((e = []) => e.map((e => `${e.name}=${e.value}`)).join("; "))(await Cs.get(e, this._db))
            }
            async set(e, t = "") {
                return t = this.ctx.modules.setCookieParser.parse(t, {
                    decodeValues: !1
                })[0], this._db || (this._db = this.db.open()), await Cs.set(e, t, this._db)
            }
            async open() {
                await Cs.open()
            }
            async update(e) {
                return this._db || (this._db = this.db.open()), await Cs.update(e, this._db)
            }
        },
        Ss = {
            csp: ["cross-origin-embedder-policy", "cross-origin-opener-policy", "cross-origin-resource-policy", "content-security-policy", "content-security-policy-report-only", "expect-ct", "feature-policy", "origin-isolation", "strict-transport-security", "upgrade-insecure-requests", "x-content-type-options", "x-frame-options", "x-permitted-cross-domain-policies", "x-xss-protection"],
            status: {
                empty: [204, 101, 205, 304]
            },
            method: {
                body: ["GET", "HEAD"]
            }
        },
        Is = {};
    l(Is, {
        aes: () => cr,
        base64: () => lr,
        none: () => hr,
        plain: () => or,
        xor: () => ar
    });
    var As = 14,
        Ps = !1,
        Ns = function(e) {
            var t, i, s = [];
            for (e.length < 16 && (s = [t = 16 - e.length, t, t, t, t, t, t, t, t, t, t, t, t, t, t, t]), i = 0; i < e.length; i++) s[i] = e[i];
            return s
        },
        Ls = function(e, t) {
            var i, s, r = "";
            if (t) {
                if ((i = e[15]) > 16) throw "Decryption error: Maybe bad key";
                if (16 === i) return "";
                for (s = 0; s < 16 - i; s++) r += String.fromCharCode(e[s])
            } else
                for (s = 0; s < 16; s++) r += String.fromCharCode(e[s]);
            return r
        },
        Ts = function(e, t) {
            var i, s = [];
            for (t || (e = function(e) {
                    try {
                        return unescape(encodeURIComponent(e))
                    } catch {
                        throw "Error on UTF-8 encode"
                    }
                }(e)), i = 0; i < e.length; i++) s[i] = e.charCodeAt(i);
            return s
        },
        Rs = function(e, t) {
            var i, s = [],
                r = [],
                n = e.concat(t);
            for (s[0] = rr(n), r = s[0], i = 1; i < 3; i++) s[i] = rr(s[i - 1].concat(n)), r = r.concat(s[i]);
            return {
                key: r.slice(0, 32),
                iv: r.slice(32, 48)
            }
        },
        Vs = function(e, t, i, s) {
            t = Fs(t);
            var r, n = e.length / 16,
                a = [],
                o = [],
                c = "";
            for (r = 0; r < n; r++) a.push(e.slice(16 * r, 16 * (r + 1)));
            for (r = a.length - 1; r >= 0; r--) o[r] = Ds(a[r], t), o[r] = $s(o[r], 0 === r ? i : a[r - 1]);
            for (r = 0; r < n - 1; r++) c += Ls(o[r], !1);
            return c += Ls(o[r], !0), s ? c : function(e) {
                try {
                    return decodeURIComponent(escape(e))
                } catch {
                    throw "Bad Key"
                }
            }(c)
        },
        Os = function(e, t) {
            Ps = !1;
            var i, s = Us(e, t, 0);
            for (i = 1; i < 15; i++) s = js(s), s = Ms(s), i < As && (s = Bs(s)), s = Us(s, t, i);
            return s
        },
        Ds = function(e, t) {
            Ps = !0;
            var i, s = Us(e, t, As);
            for (i = 13; i > -1; i--) s = Ms(s), s = js(s), s = Us(s, t, i), i > 0 && (s = Bs(s));
            return s
        },
        js = function(e) {
            var t, i = Ps ? Qs : Ks,
                s = [];
            for (t = 0; t < 16; t++) s[t] = i[e[t]];
            return s
        },
        Ms = function(e) {
            var t, i = [],
                s = Ps ? [0, 13, 10, 7, 4, 1, 14, 11, 8, 5, 2, 15, 12, 9, 6, 3] : [0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11];
            for (t = 0; t < 16; t++) i[t] = e[s[t]];
            return i
        },
        Bs = function(e) {
            var t, i = [];
            if (Ps)
                for (t = 0; t < 4; t++) i[4 * t] = ir[e[4 * t]] ^ er[e[1 + 4 * t]] ^ tr[e[2 + 4 * t]] ^ Xs[e[3 + 4 * t]], i[1 + 4 * t] = Xs[e[4 * t]] ^ ir[e[1 + 4 * t]] ^ er[e[2 + 4 * t]] ^ tr[e[3 + 4 * t]], i[2 + 4 * t] = tr[e[4 * t]] ^ Xs[e[1 + 4 * t]] ^ ir[e[2 + 4 * t]] ^ er[e[3 + 4 * t]], i[3 + 4 * t] = er[e[4 * t]] ^ tr[e[1 + 4 * t]] ^ Xs[e[2 + 4 * t]] ^ ir[e[3 + 4 * t]];
            else
                for (t = 0; t < 4; t++) i[4 * t] = Js[e[4 * t]] ^ Zs[e[1 + 4 * t]] ^ e[2 + 4 * t] ^ e[3 + 4 * t], i[1 + 4 * t] = e[4 * t] ^ Js[e[1 + 4 * t]] ^ Zs[e[2 + 4 * t]] ^ e[3 + 4 * t], i[2 + 4 * t] = e[4 * t] ^ e[1 + 4 * t] ^ Js[e[2 + 4 * t]] ^ Zs[e[3 + 4 * t]], i[3 + 4 * t] = Zs[e[4 * t]] ^ e[1 + 4 * t] ^ e[2 + 4 * t] ^ Js[e[3 + 4 * t]];
            return i
        },
        Us = function(e, t, i) {
            var s, r = [];
            for (s = 0; s < 16; s++) r[s] = e[s] ^ t[i][s];
            return r
        },
        $s = function(e, t) {
            var i, s = [];
            for (i = 0; i < 16; i++) s[i] = e[i] ^ t[i];
            return s
        },
        Fs = function(e) {
            var t, i, s, r, n = [],
                a = [],
                o = [];
            for (t = 0; t < 8; t++) i = [e[4 * t], e[4 * t + 1], e[4 * t + 2], e[4 * t + 3]], n[t] = i;
            for (t = 8; t < 60; t++) {
                for (n[t] = [], s = 0; s < 4; s++) a[s] = n[t - 1][s];
                for (t % 8 == 0 ? (a = Hs(Ws(a)))[0] ^= Ys[t / 8 - 1] : t % 8 == 4 && (a = Hs(a)), s = 0; s < 4; s++) n[t][s] = n[t - 8][s] ^ a[s]
            }
            for (t = 0; t < 15; t++)
                for (o[t] = [], r = 0; r < 4; r++) o[t].push(n[4 * t + r][0], n[4 * t + r][1], n[4 * t + r][2], n[4 * t + r][3]);
            return o
        },
        Hs = function(e) {
            for (var t = 0; t < 4; t++) e[t] = Ks[e[t]];
            return e
        },
        Ws = function(e) {
            var t, i = e[0];
            for (t = 0; t < 3; t++) e[t] = e[t + 1];
            return e[3] = i, e
        },
        qs = function(e, t) {
            var i, s = [];
            for (i = 0; i < e.length; i += t) s[i / t] = parseInt(e.substr(i, t), 16);
            return s
        },
        Gs = function(e, t) {
            var i, s;
            for (s = 0, i = 0; i < 8; i++) s = 1 == (1 & t) ? s ^ e : s, e = e > 127 ? 283 ^ e << 1 : e << 1, t >>>= 1;
            return s
        },
        zs = function(e) {
            var t, i = [];
            for (t = 0; t < 256; t++) i[t] = Gs(e, t);
            return i
        },
        Ks = qs("637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b27509832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cfd0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdbe0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9ee1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16", 2),
        Qs = function(e) {
            var t, i = [];
            for (t = 0; t < e.length; t++) i[e[t]] = t;
            return i
        }(Ks),
        Ys = qs("01020408102040801b366cd8ab4d9a2f5ebc63c697356ad4b37dfaefc591", 2),
        Js = zs(2),
        Zs = zs(3),
        Xs = zs(9),
        er = zs(11),
        tr = zs(13),
        ir = zs(14),
        sr = function(e, t, i) {
            var s, r = function(e) {
                    var t, i = [];
                    for (t = 0; t < e; t++) i = i.concat(Math.floor(256 * Math.random()));
                    return i
                }(8),
                n = Rs(Ts(t, i), r),
                a = n.key,
                o = n.iv,
                c = [
                    [83, 97, 108, 116, 101, 100, 95, 95].concat(r)
                ];
            return s = function(e, t, i) {
                t = Fs(t);
                var s, r = Math.ceil(e.length / 16),
                    n = [],
                    a = [];
                for (s = 0; s < r; s++) n[s] = Ns(e.slice(16 * s, 16 * s + 16));
                for (e.length % 16 == 0 && (n.push([16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16]), r++), s = 0; s < n.length; s++) n[s] = $s(n[s], 0 === s ? i : a[s - 1]), a[s] = Os(n[s], t);
                return a
            }(e = Ts(e, i), a, o), s = c.concat(s), nr.encode(s)
        },
        rr = function(e) {
            function t(e, t) {
                return e << t | e >>> 32 - t
            }

            function i(e, t) {
                var i, s, r, n, a;
                return r = 2147483648 & e, n = 2147483648 & t, a = (1073741823 & e) + (1073741823 & t), (i = 1073741824 & e) & (s = 1073741824 & t) ? 2147483648 ^ a ^ r ^ n : i | s ? 1073741824 & a ? 3221225472 ^ a ^ r ^ n : 1073741824 ^ a ^ r ^ n : a ^ r ^ n
            }

            function s(e, s, r, n, a, o, c) {
                return e = i(e, i(i(function(e, t, i) {
                    return e & t | ~e & i
                }(s, r, n), a), c)), i(t(e, o), s)
            }

            function r(e, s, r, n, a, o, c) {
                return e = i(e, i(i(function(e, t, i) {
                    return e & i | t & ~i
                }(s, r, n), a), c)), i(t(e, o), s)
            }

            function n(e, s, r, n, a, o, c) {
                return e = i(e, i(i(function(e, t, i) {
                    return e ^ t ^ i
                }(s, r, n), a), c)), i(t(e, o), s)
            }

            function a(e, s, r, n, a, o, c) {
                return e = i(e, i(i(function(e, t, i) {
                    return t ^ (e | ~i)
                }(s, r, n), a), c)), i(t(e, o), s)
            }

            function o(e) {
                var t, i, s = [];
                for (i = 0; i <= 3; i++) t = e >>> 8 * i & 255, s = s.concat(t);
                return s
            }
            var c, h, l, p, u, d, f, m, g, x, y = qs("67452301efcdab8998badcfe10325476d76aa478e8c7b756242070dbc1bdceeef57c0faf4787c62aa8304613fd469501698098d88b44f7afffff5bb1895cd7be6b901122fd987193a679438e49b40821f61e2562c040b340265e5a51e9b6c7aad62f105d02441453d8a1e681e7d3fbc821e1cde6c33707d6f4d50d87455a14eda9e3e905fcefa3f8676f02d98d2a4c8afffa39428771f6816d9d6122fde5380ca4beea444bdecfa9f6bb4b60bebfbc70289b7ec6eaa127fad4ef308504881d05d9d4d039e6db99e51fa27cf8c4ac5665f4292244432aff97ab9423a7fc93a039655b59c38f0ccc92ffeff47d85845dd16fa87e4ffe2ce6e0a30143144e0811a1f7537e82bd3af2352ad7d2bbeb86d391", 8);
            for (c = function(e) {
                    for (var t, i = e.length, s = i + 8, r = 16 * ((s - s % 64) / 64 + 1), n = [], a = 0, o = 0; o < i;) a = o % 4 * 8, n[t = (o - o % 4) / 4] = n[t] | e[o] << a, o++;
                    return a = o % 4 * 8, n[t = (o - o % 4) / 4] = n[t] | 128 << a, n[r - 2] = i << 3, n[r - 1] = i >>> 29, n
                }(e), f = y[0], m = y[1], g = y[2], x = y[3], h = 0; h < c.length; h += 16) l = f, p = m, u = g, d = x, f = s(f, m, g, x, c[h + 0], 7, y[4]), x = s(x, f, m, g, c[h + 1], 12, y[5]), g = s(g, x, f, m, c[h + 2], 17, y[6]), m = s(m, g, x, f, c[h + 3], 22, y[7]), f = s(f, m, g, x, c[h + 4], 7, y[8]), x = s(x, f, m, g, c[h + 5], 12, y[9]), g = s(g, x, f, m, c[h + 6], 17, y[10]), m = s(m, g, x, f, c[h + 7], 22, y[11]), f = s(f, m, g, x, c[h + 8], 7, y[12]), x = s(x, f, m, g, c[h + 9], 12, y[13]), g = s(g, x, f, m, c[h + 10], 17, y[14]), m = s(m, g, x, f, c[h + 11], 22, y[15]), f = s(f, m, g, x, c[h + 12], 7, y[16]), x = s(x, f, m, g, c[h + 13], 12, y[17]), g = s(g, x, f, m, c[h + 14], 17, y[18]), f = r(f, m = s(m, g, x, f, c[h + 15], 22, y[19]), g, x, c[h + 1], 5, y[20]), x = r(x, f, m, g, c[h + 6], 9, y[21]), g = r(g, x, f, m, c[h + 11], 14, y[22]), m = r(m, g, x, f, c[h + 0], 20, y[23]), f = r(f, m, g, x, c[h + 5], 5, y[24]), x = r(x, f, m, g, c[h + 10], 9, y[25]), g = r(g, x, f, m, c[h + 15], 14, y[26]), m = r(m, g, x, f, c[h + 4], 20, y[27]), f = r(f, m, g, x, c[h + 9], 5, y[28]), x = r(x, f, m, g, c[h + 14], 9, y[29]), g = r(g, x, f, m, c[h + 3], 14, y[30]), m = r(m, g, x, f, c[h + 8], 20, y[31]), f = r(f, m, g, x, c[h + 13], 5, y[32]), x = r(x, f, m, g, c[h + 2], 9, y[33]), g = r(g, x, f, m, c[h + 7], 14, y[34]), f = n(f, m = r(m, g, x, f, c[h + 12], 20, y[35]), g, x, c[h + 5], 4, y[36]), x = n(x, f, m, g, c[h + 8], 11, y[37]), g = n(g, x, f, m, c[h + 11], 16, y[38]), m = n(m, g, x, f, c[h + 14], 23, y[39]), f = n(f, m, g, x, c[h + 1], 4, y[40]), x = n(x, f, m, g, c[h + 4], 11, y[41]), g = n(g, x, f, m, c[h + 7], 16, y[42]), m = n(m, g, x, f, c[h + 10], 23, y[43]), f = n(f, m, g, x, c[h + 13], 4, y[44]), x = n(x, f, m, g, c[h + 0], 11, y[45]), g = n(g, x, f, m, c[h + 3], 16, y[46]), m = n(m, g, x, f, c[h + 6], 23, y[47]), f = n(f, m, g, x, c[h + 9], 4, y[48]), x = n(x, f, m, g, c[h + 12], 11, y[49]), g = n(g, x, f, m, c[h + 15], 16, y[50]), f = a(f, m = n(m, g, x, f, c[h + 2], 23, y[51]), g, x, c[h + 0], 6, y[52]), x = a(x, f, m, g, c[h + 7], 10, y[53]), g = a(g, x, f, m, c[h + 14], 15, y[54]), m = a(m, g, x, f, c[h + 5], 21, y[55]), f = a(f, m, g, x, c[h + 12], 6, y[56]), x = a(x, f, m, g, c[h + 3], 10, y[57]), g = a(g, x, f, m, c[h + 10], 15, y[58]), m = a(m, g, x, f, c[h + 1], 21, y[59]), f = a(f, m, g, x, c[h + 8], 6, y[60]), x = a(x, f, m, g, c[h + 15], 10, y[61]), g = a(g, x, f, m, c[h + 6], 15, y[62]), m = a(m, g, x, f, c[h + 13], 21, y[63]), f = a(f, m, g, x, c[h + 4], 6, y[64]), x = a(x, f, m, g, c[h + 11], 10, y[65]), g = a(g, x, f, m, c[h + 2], 15, y[66]), m = a(m, g, x, f, c[h + 9], 21, y[67]), f = i(f, l), m = i(m, p), g = i(g, u), x = i(x, d);
            return o(f).concat(o(m), o(g), o(x))
        },
        nr = function() {
            var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                t = e.split("");
            return "function" == typeof Array.indexOf && (e = t), {
                encode: function(e, i) {
                    var s, r, n = [],
                        a = "";
                    Math.floor(16 * e.length / 3);
                    for (s = 0; s < 16 * e.length; s++) n.push(e[Math.floor(s / 16)][s % 16]);
                    for (s = 0; s < n.length; s += 3) a += t[n[s] >> 2], a += t[(3 & n[s]) << 4 | n[s + 1] >> 4], void 0 !== n[s + 1] ? a += t[(15 & n[s + 1]) << 2 | n[s + 2] >> 6] : a += "=", void 0 !== n[s + 2] ? a += t[63 & n[s + 2]] : a += "=";
                    for (r = a.slice(0, 64) + "\n", s = 1; s < Math.ceil(a.length / 64); s++) r += a.slice(64 * s, 64 * s + 64) + (Math.ceil(a.length / 64) === s + 1 ? "" : "\n");
                    return r
                },
                decode: function(t) {
                    t = t.replace(/\n/g, "");
                    var i, s = [],
                        r = [],
                        n = [];
                    for (i = 0; i < t.length; i += 4) r[0] = e.indexOf(t.charAt(i)), r[1] = e.indexOf(t.charAt(i + 1)), r[2] = e.indexOf(t.charAt(i + 2)), r[3] = e.indexOf(t.charAt(i + 3)), n[0] = r[0] << 2 | r[1] >> 4, n[1] = (15 & r[1]) << 4 | r[2] >> 2, n[2] = (3 & r[2]) << 6 | r[3], s.push(n[0], n[1], n[2]);
                    return s = s.slice(0, s.length - s.length % 16)
                }
            }
        }(),
        ar = {
            encode: (e, t = 2) => e && encodeURIComponent(e.split("").map(((e, i) => i % t ? String.fromCharCode(e.charCodeAt(0) ^ t) : e)).join("")),
            decode: (e, t = 2) => e && decodeURIComponent(e).split("").map(((e, i) => i % t ? String.fromCharCode(e.charCodeAt(0) ^ t) : e)).join("")
        },
        or = {
            encode: e => e && encodeURIComponent(e),
            decode: e => e && decodeURIComponent(e)
        },
        cr = {
            encode: e => e && encodeURIComponent(sr(e, "dynamic").substring(10)),
            decode: e => e && function(e, t, i) {
                var s = nr.decode(e),
                    r = s.slice(8, 16),
                    n = Rs(Ts(t, i), r),
                    a = n.key,
                    o = n.iv;
                return s = s.slice(16, s.length), Vs(s, a, o, i)
            }("U2FsdGVkX1" + decodeURIComponent(e), "dynamic")
        },
        hr = {
            encode: e => e,
            decode: e => e
        },
        lr = {
            encode: e => e && decodeURIComponent(btoa(e)),
            decode: e => e && atob(e)
        },
        pr = class {
            constructor(e) {
                this.listeners = [], this.modules = new Ri(this), this.util = new ns(this), this.http = new fs(this), this.meta = new ps(this), this.rewrite = new qi(this), this.url = new cs(this), this.is = new ks(this), this.cookies = new Es(this), this.regex = new ys(this), this.headers = Ss, this.encoding = Is, this.middleware = new vs(this), e && !this.config && (this.config = e), e && this.util.encode(self)
            }
            on(e, t) {
                this.listeners.push({
                    event: e,
                    cb: t
                })
            }
            fire(e, t) {
                for (let i of this.listeners)
                    if (i.event === e) return t = i.cb(...t);
                return null
            }
        };
    ! function(e) {
        e.skipWaiting(), e.addEventListener("install", (async (t, i) => {
            let s = e.__dynamic$config.logLevel || 0;
            if (s > 1 && console["development" == e.__dynamic$config.mode ? "group" : "groupCollapsed"]("Dynamic Install Sequence:"), "object" == typeof e.ORIGINS)
                if (e.ORIGINS.length)
                    if ("*" == e.ORIGINS[0]) console.log("Wildcard Origin Accepted");
                    else {
                        if (!e.ORIGINS.includes(location.origin)) return console.error("Illegal Origin: " + location.origin), console.log("Status: Aborting Install"), console.groupEnd(), await e.registration.unregister();
                        s > 1 && console.log("Origin Verified: " + location.origin)
                    }
            else console.warn("Warning: No Origins Specified");
            else "string" == typeof e.ORIGINS ? "*" == e.ORIGINS && s > 1 && console.log("Wildcard Origin Accepted") : s > 0 && console.warn("Warning: No Origins Specified");
            for await (var r of (s > 1 && console.log("ServiceWorker Installed:", t), s > 1 && console.log("Configuration Loaded:", e.__dynamic$config), await e.skipWaiting(), s > 1 && console.groupCollapsed("Loading Dynamic Modules:"), [
                ["html", "html.js?v=12"]
            ])) {
                var [n, a] = r;
                a = new URL(a, new URL(location.origin + e.__dynamic$config.assets.prefix + "worker.js")).href, e[n] = fetch(a).then((t => (s > 1 && console.log("Loaded Dynamic Module: " + n, t), e[n] = t.text()))).then((e => (0, eval)(e))), s > 1 && console.log("Loading: " + n, a)
            }
            if (console.groupEnd(), "development" == e.__dynamic$config.mode) return console.groupEnd();
            let o = await caches.open("__dynamic$files");
            for await (var r of (s > 1 && console.groupCollapsed("Dynamic File Cache:"), Object.values(e.__dynamic$config.assets.files))) {
                if (!r) continue;
                var a = r;
                a = new URL(a, new URL(location.origin + e.__dynamic$config.assets.prefix + "worker.js")).href;
                let t = await fetch(a);
                await o.put(a, t), s > 1 && console.log("Cache Installed: " + a.split("/").pop(), t)
            }
            console.groupEnd(), console.groupEnd()
        })), e.addEventListener("activate", (t => {
            e.skipWaiting(), t.waitUntil(e.clients.claim())
        })), e.addEventListener("message", (async i => {
            let {
                data: s
            } = i;
            if ("createBlobHandler" == s.type) {
                var r = new Response(s.blob, {
                        headers: {
                            "Content-Type": "text/html",
                            "Content-Length": s.blob.size,
                            "x-dynamic-location": s.location
                        }
                    }),
                    n = await caches.open("__dynamic$blob"),
                    a = t.config.prefix + "caches/" + s.url;
                await n.put(a, r), e.clients.matchAll().then((e => {
                    e.forEach((e => {
                        e.postMessage({
                            url: a
                        })
                    }))
                }))
            }
        })), e.__dynamic$config || importScripts("/assets/history/config.js?v=2025-04-15");
        let t = new pr(e.__dynamic$config),
            i = e.__dynamic$config.block || [];
        t.config = e.__dynamic$config, t.config.bare.path = "string" == typeof t.config.bare.path ? new URL(t.config.bare.path, e.location) : t.config.bare.path.map((t => new URL(t, e.location))), t.encoding = { ...t.encoding,
            ...t.encoding[t.config.encoding || "none"]
        }, e.__dynamic = t, e.Object.defineProperty(e.WindowClient.prototype, "__dynamic$location", {
            get() {
                return new URL(t.url.decode(this.url))
            }
        }), e.Dynamic = class {
            constructor(i = e.__dynamic$config) {
                this.listeners = [], this.middleware = t.middleware, this.on = e.__dynamic.on, this.fire = e.__dynamic.fire, t.bare = t.modules.bare.createBareClient(t.config.bare.path), e.__dynamic$config = i
            }
            async route(i) {
                let {
                    request: s
                } = i;
                return !s.url.startsWith(t.config.bare.path.toString()) && (!!s.url.startsWith(location.origin + e.__dynamic$config.prefix) || ("navigate" !== s.mode && (s.client = (await e.clients.matchAll()).find((e => e.id == i.clientId))), s.url.startsWith(location.origin + e.__dynamic$config.prefix) ? void 0 : !!s.client && !!s.client.url.startsWith(location.origin + e.__dynamic$config.prefix)))
            }
            async fetch(s) {
                let {
                    request: r
                } = s;
                try {
                    if ("navigate" !== r.mode && (r.client = (await e.clients.matchAll()).find((e => e.id == s.clientId))), t.util.file(r)) return await t.util.edit(r);
                    if (r.url.startsWith(e.__dynamic$config.bare.path.toString())) return await fetch(r);
                    if (t.util.path(r)) {
                        if (!r.client || !r.url.startsWith("http")) return await fetch(r);
                        Object.defineProperty(r, "url", {
                            value: t.util.rewritePath(r, r.client, new URL(e.__dynamic.url.decode(new URL(r.url))))
                        })
                    }
                    if (!t.util.routePath(r)) return await t.util.route(r);
                    await t.bare.working;
                    let c = new pr(t.config);
                    c.encoding = { ...c.encoding,
                        ...c.encoding[t.config.encoding || "none"]
                    }, c.on = (t, i) => e.__dynamic.on(t, i), c.fire = (t, ...i) => e.__dynamic.fire(t, i);
                    let h = c.fire("request", [r]);
                    if (h) return h;
                    if (r.url.startsWith(location.origin + t.config.prefix + "caches/")) {
                        let t = await (await caches.open("__dynamic")).match(new URL(r.url).pathname);
                        if (!t) return new Response(null, {
                            status: 201
                        });
                        var n;
                        let i = await t.blob(),
                            s = await i.text(),
                            a = c.rewrite.html.generateHead(location.origin + e.__dynamic$config.assets.prefix + e.__dynamic$config.assets.files.client, location.origin + e.__dynamic$config.assets.prefix + e.__dynamic$config.assets.files.config, location.origin + e.__dynamic$config.assets.prefix + e.__dynamic$config.assets.files.config, "", `window.__dynamic$url = "${t.headers.get("x-dynamic-location")}"`);
                        return c.meta.load(new URL(t.headers.get("x-dynamic-location"))), n = c.is.html(c.meta, t.headers.get("content-type"), s) ? new Blob([c.rewrite.html.rewrite(s, c.meta, a)]) : i, new Response(n, {
                            status: t.status,
                            statusText: t.statusText,
                            headers: t.headers
                        })
                    }
                    if (c.meta.load(new URL(c.url.decode(new URL(r.url)))), -1 !== i.indexOf(c.meta.host) || i.find((e => e instanceof RegExp && e.test(c.meta.host)))) return this.fire("blocked", [c.meta, r]) || new Response(null, {
                        status: 403,
                        statusText: "Forbidden"
                    });
                    let l = c.cookies;
                    await l.open(), await l.update(c.meta.host);
                    let p, u = Object.fromEntries(r.headers.entries()),
                        d = t.util.reqHeader(u, c.meta, r, await l.get(r.client ? r.client.__dynamic$location.host : c.meta.host)),
                        f = new t.http.Request(c.meta.href, {
                            headers: d,
                            redirect: r.redirect || "manual",
                            method: r.method,
                            credentials: r.credentials,
                            body: null,
                            cache: r.cache
                        }); - 1 == t.headers.method.body.indexOf(r.method.toUpperCase()) && (f.body = await r.blob()), p = "about:" !== c.meta.protocol ? await (await t.bare).fetch(c.meta.href, f.init) : new t.util.about(new Blob(["<html><head></head><body></body></html>"]));
                    let m = this.fire("fetched", [c.meta, p, r]);
                    if (m) return m;
                    let g = await c.util.resHeader(p.rawHeaders, c.meta, l);
                    var a = await e.clients.matchAll();
                    for await (var o of a) o.postMessage({
                        type: "cookies",
                        host: c.meta.host,
                        cookies: await l.get(c.meta.host)
                    });
                    let x = !1;
                    switch (r.destination) {
                        case "document":
                            let i = await p.blob(),
                                s = await i.text(),
                                n = c.rewrite.html.generateHead(location.origin + e.__dynamic$config.assets.prefix + e.__dynamic$config.assets.files.client, location.origin + e.__dynamic$config.assets.prefix + e.__dynamic$config.assets.files.config, location.origin + e.__dynamic$config.assets.prefix + e.__dynamic$config.assets.files.client, await l.get(c.meta.host), "", !1, "self.__dynamic$bare = JSON.parse('" + JSON.stringify((await t.bare).manifest) + "');");
                            x = c.is.html(c.meta, p.headers.get("content-type"), s) ? new Blob([c.rewrite.html.rewrite(s, c.meta, n)], {
                                type: p.headers.get("content-type") || "text/html; charset=utf-8"
                            }) : i;
                            break;
                        case "iframe":
                            {
                                let i = await p.blob(),
                                    s = await i.text();
                                if (c.is.html(c.meta, p.headers.get("content-type"), s)) {
                                    try {
                                        let i = c.rewrite.html.generateHead(location.origin + e.__dynamic$config.assets.prefix + e.__dynamic$config.assets.files.client, location.origin + e.__dynamic$config.assets.prefix + e.__dynamic$config.assets.files.config, location.origin + e.__dynamic$config.assets.prefix + e.__dynamic$config.assets.files.client, await l.get(c.meta.host), "", !0, "self.__dynamic$bare = JSON.parse('" + JSON.stringify((await t.bare).manifest) + "');");
                                        x = new Blob([new(await e.html)({
                                            ctx: c
                                        }).rewrite(s, c.meta, i)], {
                                            type: p.headers.get("content-type") || "text/html; charset=utf-8"
                                        })
                                    } catch {
                                        x = i
                                    }
                                    break
                                }
                                x = i;
                                break
                            }
                        case "worker":
                        case "script":
                            c.is.js(c.meta, p.headers.get("content-type")) && (x = new Blob([c.rewrite.js.rewrite(await p.text(), r, !0, c)], {
                                type: p.headers.get("content-type") || "application/javascript"
                            }));
                            break;
                        case "style":
                            c.is.css(c.meta, p.headers.get("content-type")) && (x = new Blob([c.rewrite.css.rewrite(await p.text(), c.meta)], {
                                type: p.headers.get("content-type") || "text/css"
                            }));
                            break;
                        case "manifest":
                            x = new Blob([c.rewrite.man.rewrite(await p.text(), c.meta)], {
                                type: p.headers.get("content-type") || "application/json"
                            });
                            break;
                        default:
                            {
                                let t = await p.blob(),
                                    i = await t.text();
                                if (c.is.html(c.meta, p.headers.get("content-type"), i)) {
                                    try {
                                        x = new Blob([new(await e.html)({
                                            ctx: c
                                        }).rewrite(i, c.meta, [])], {
                                            type: p.headers.get("content-type") || "text/html; charset=utf-8"
                                        })
                                    } catch {
                                        x = t
                                    }
                                    break
                                }
                                x = t;
                                break
                            }
                    }
                    return 0 == x && (x = await p.blob()), -1 !== t.headers.status.empty.indexOf(p.status) && (x = null), "text/event-stream" === d.get("accept") && g.set("content-type", "text/event-stream"), x && g.set("content-length", x.size), this.fire("response", [c.meta, p, r, g, x]) || new Response(x, {
                        status: p.status,
                        statusText: p.statusText,
                        headers: g
                    })
                } catch (t) {
                    return e.__dynamic$config.logLevel >= 1 && console.error(t), new Response(t, {
                        status: 500,
                        statusText: "error",
                        headers: new Headers({})
                    })
                }
            }
        }
    }(self)
})();
/*! Bundled license information:

cookie/index.js:
  (*!
   * cookie
   * Copyright(c) 2012-2014 Roman Shtylman
   * Copyright(c) 2015 Douglas Christopher Wilson
   * MIT Licensed
   *)
*/